# MADS — Multi-Domain Design and Optimisation Platform  <img src="Tools/MultiADS/docs/images/Logo_MADS.jpg" alt="MADS Logo" align="right" width="250">

**MADS** is a modular multi-disciplinary framework targeting **multi-disciplinary trade-offs and optimisation for Aircraft systems**. It provides an integrated environment to support decision making and design feasibility studies, supporting uncertainty quantification and multi-fidelity applications.

---

## Table of Contents
- [Overview](#overview)
- [Functional Architecture](#functional-architecture)
- [Workflow Summary](#workflow-summary)
- [Advanced Capabilities](#advanced-capabilities)
- [Authors](#authors)

---

## Overview

The framework integrates aircraft systems ontology and dedicated multi-physics solver interfaces to ensure:

1. **MDAO problem formulation** – structured definition of the MDA process.
2. **Flexible Parametrization** – ensure consistent definition of the parameter space.
3. **System Architecture realization** – direct definition of aircraft architecture into MDAO workflow.
4. **Feature Selection** – Design of Experiment, Optimisation, parameter space definition.
5. **MDAO Architecture** – Dedicated formulation for the optimisation can be selected.
6. **Surrogate acceleration** – possibility to replace full-order models with specific surrogates.
7. **Multi-disciplinary analysis logging** – Full-history of the MDAO problem during runtime.
8. **Export and Visualization capabilities** – Efficient export to databases including metadata.

<div align="center">
  <img src="Tools/MultiADS/docs/images/MADS_pipeline_overview.png" alt="MADS Data Flow" width="90%">
  <p><em>Figure 1 — MADS Main Functionalities</em></p>
</div>

---

## Functional Architecture

MADS is implemented as an integrated monolithic solution. The workflows are specified in plain **Python**, forming a reproducible workflow.

| Stage | Operation | Description |
|:--|:--|:--|
| 1 | `Define Variables` | Defines variables to be included in the workflow. |
| 2 | `Define Design Variables` | Declares which variables are part of the design space. |
| 3 | `Define Components` | Defines the components to be included in the study. |
| 4 | `Associate Variables to components` | Associate the variables to the `logical architecture`. |
| 5 | `Define Solvers` | Selects the solvers to be used for the study. |
| 6 | `Define Disciplines and associate Solver` | Associate the solver to the dedicated disciplines. |
| 7 | `Define MDAO scenario` | Define the Multi-Disciplinary Analysis Optimisation Scenario. |
| 8 | `Include Observable` | Include any variables that are not in the design space. |
| 9 | `Define export` | Define the process on how to save data. |

<div align="center">
  <img src="Tools/MultiADS/docs/images/MADS_architecture.png" alt="Functional Architecture" width="80%">
  <p><em>Figure 2 — Functional Architecture of MADS</em></p>
</div>

---

## Workflow Summary

1. **Input:** System architecture and Parameter space.
2. **Processing:** MDAO Problem Formulation including Variables, Components, Solver, Disciplines, Mission Segments.
3. **Output:**
   - Optimisation history
   - Correlation and Sensitivities
   - Feasible Design and Pareto Front
4. **Storage & Data Persistence:** database and .txt export.

<div align="center">
  <img src="Tools/MultiADS/docs/images/MADS_workflow.png" alt="Workflow Overview" width="600">
  <p><em>Figure 3 — Workflow Summary.</em></p>
</div>

---

## Advanced Capabilities

- Integration with Deep Learning modelling approach to speed-up trade-offs
- Multi-fidelity analysis including different solvers
- Uncertainty Quantification and Propagation in the trade-off studies
- Time domain behavioural simulations

<div align="center">
  <img src="Tools/MultiADS/docs/images/MADS_advance.png" alt="Advanced MADS" width="40%">
  <p><em>Figure 4 — Advanced MADS Capabilities.</em></p>
</div>

---

## Authors

- **Simone Mancini**
- **Andres Mateo Gabin**

Flight Physics – Technology and Capabilities
Airbus Defence and Space
