LIBS=~/Software/hdf5-hdf5-1_10_5/dist/gnu/lib
LIBS=~/Software/CGNS-3.4.0/dist/gnu/lib:$LIBS
LIBS=/opt_cluster/gcc/gcc-6.3.0/lib:$LIBS
export LD_LIBRARY_PATH=$LIBS:$LD_LIBRARY_PATH
