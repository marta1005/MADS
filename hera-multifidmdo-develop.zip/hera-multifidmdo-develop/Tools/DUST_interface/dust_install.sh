#!/usr/bin/env bash

SRC_DIR=~/Software/dust-daer
BUILD_DIR=$SRC_DIR/build/gnu
DIST_DIR=$SRC_DIR/dist/gnu

HDF5_PATH=~/Software/hdf5-hdf5-1_10_5/dist/gnu
CGNS_PATH=~/Software/CGNS-3.4.0/dist/gnu

export CXX=/opt_cluster/gcc/gcc-6.3.0/bin/c++
export FC=/opt_cluster/gcc/gcc-6.3.0/bin/gfortran

#####################

mkdir -p $BUILD_DIR
cd $BUILD_DIR

cmake -DDUST_MKL=ON \
      -DCGNS_INC=$CGNS_PATH/include \
      -DCGNS_LIB=$CGNS_PATH/lib \
      -DCMAKE_PREFIX_PATH=$HDF5_PATH \
      -DCMAKE_INSTALL_PREFIX=$DIST_DIR \
      $SRC_DIR
make
make install

#####################

rm ~/.local/bin/dust
ln -s $DIST_DIR/bin/dust ~/.local/bin

rm ~/.local/bin/dust_pre
ln -s $DIST_DIR/bin/dust_pre ~/.local/bin

rm ~/.local/bin/dust_post
ln -s $DIST_DIR/bin/dust_post ~/.local/bin
