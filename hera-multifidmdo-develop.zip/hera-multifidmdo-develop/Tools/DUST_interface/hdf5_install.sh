#!/usr/bin/env bash

SRC_DIR=~/Software/hdf5-hdf5-1_10_5
BUILD_DIR=~/Software/hdf5-hdf5-1_10_5/build/gnu
DIST_DIR=~/Software/hdf5-hdf5-1_10_5/dist/gnu

export CC=/opt_cluster/gcc/gcc-6.3.0/bin/gcc
export FC=/opt_cluster/gcc/gcc-6.3.0/bin/gfortran

#####################

mkdir -p $BUILD_DIR
cd $BUILD_DIR

#cmake -DCMAKE_BUILD_TYPE=Release \
#      -DBUILD_SHARED_LIBS=ON \
#      -DHDF5_BUILD_FORTRAN=ON \
#      -DHDF5_BUILD_HL_LIB=ON \
#      -DHDF5_BUILD_TOOLS=ON \
#      -DCMAKE_INSTALL_PREFIX=$DIST_DIR \
#      $SRC_DIR
$SRC_DIR/configure --prefix=$DIST_DIR \
                   --enable-build-mode=production \
                   --enable-fortran \
                   --enable-fortran2003 \
                   --enable-hl
make -j4
make install
