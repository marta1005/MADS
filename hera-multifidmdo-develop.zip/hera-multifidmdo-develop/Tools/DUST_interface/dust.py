import subprocess as sp
import numpy as np
import os


class Section:
    def __init__(self, file, twist, roR, coR, soR, doR, ref=0.25):
        self.file = file
        self.twist = twist
        self.roR = roR
        self.coR = coR
        self.soR = soR - coR * (0.25 - ref) * np.cos(twist)  # Pos. of 0.25*c
        self.doR = doR + coR * (0.25 - ref) * np.sin(twist)  # Pos. of 0.25*c


class Propeller:
    def __init__(
        self,
        sections,
        rtip,
        n_blades,
        pos=[0.0, 0.0, 0.0],
        alpha=0.0,
        beta=0.0,
    ):
        self.sections = sections
        self.rtip = rtip
        self.n_blades = n_blades
        self.pos = pos
        self.alpha = alpha
        self.beta = beta
        self.pitch = 0.0
        self.rpm = 0.0
        self.reverse = False
        self.n_panels = 20  # Only a hint
        self.J = 0 # added param

    def write_file(self, blade_file):
        # Write blade file
        with open(blade_file, "w") as f:
            # Header
            f.write(
                "mesh_file_type = parametric\n" +
                "el_type = l\n" +
                "\n" +
                "scaling_factor = {}\n".format(self.rtip) +
                "offset = (/ {:.6f}, 0.0, 0.0 /)\n".format(self.sections[0].coR / 2)
            )

            # First section
            f.write(
                "\n" +
                "chord = {:.6f}\n".format(self.sections[0].coR) +
                "twist = {:.2f}\n".format(self.sections[0].twist) +
                "airfoil_table = {}\n".format(self.sections[0].file)
            )

            # Spans and sections
            for i in range(1, len(self.sections)):
                # Number of panels
                span = self.sections[i].roR - self.sections[i - 1].roR
                weight = span / (self.sections[-1].roR - self.sections[0].roR)
                n_panels = round(weight * self.n_panels)

                # Add more panels near the tip
                if i == len(self.sections) - 1:
                    n_panels += 2

                # Sweep and dihedral
                sweep = np.arctan2(self.sections[i].soR - self.sections[i - 1].soR, span)
                dihed = np.arctan2(self.sections[i].doR - self.sections[i - 1].doR, span)

                # Write span and section
                f.write(
                    "\n" +
                    "span = {:.6f}\n".format(span) +
                    "sweep = {:.2f}\n".format(sweep) +
                    "dihed = {:.2f}\n".format(dihed) +
                    "nelem_span = {}\n".format(n_panels) +
                    "type_span = uniform\n" + 
                    "\n" +
                    "chord = {:.6f}\n".format(self.sections[i].coR) +
                    "twist = {:.2f}\n".format(self.sections[i].twist) +
                    "airfoil_table = {}\n".format(self.sections[i].file)
                )


class Atmosphere:
    def __init__(self, density, pressure, sound, viscosity, velocity):
        self.density = density
        self.pressure = pressure
        self.sound = sound
        self.viscosity = viscosity
        self.Mach = np.asarray(velocity)/self.sound
        self.Mach_x = self.Mach[0]
        self.Mach_y = self.Mach[1]
        self.Mach_z = self.Mach[2]
        self.velocity = self.Mach*self.sound


class DUSToptions:
    def __init__(self):
        self.name = "dust_sim"
        # DUST commands
        self.dust_pre = "dust_pre"
        self.dust = "dust"
        self.dust_post = "dust_post"
        # Paths (relative)
        self.output_path = "output"
        self.post_path = "post"
        # Solver options
        self.t_start = 0.0
        self.n_turns = 4
        self.steps_per_turn = 40
        self.n_wake_particles = 10000
        self.particles_box_min = [0.0, 0.0, 0.0]
        self.particles_box_max = [1.0, 1.0, 1.0]
        self.penetration_avoidance = False
        self.fmm = True
        self.box_length = 1.0
        self.n_box = [1, 1, 1]
        self.octree_origin = [0.0, 0.0, 0.0]
        self.n_octree_levels = 5
        self.min_octree_part = 5
        self.multipole_degree = 5
        self.max_iter = 100
        self.tol = 1e-6


class DUSTpost_loads:
    def __init__(self):
        self.name = "loads"
        self.start_res = 1
        self.end_res = 2
        self.step_res = 1
        self.average = False
        self.components = ["all"]
        self.t = []
        self.f = []
        self.m = []

    def clear(self):
        self.t = []
        self.f = []
        self.m = []

    def get_dust_string(self):
        # Parameters of the analysis
        string = ("analysis = {\n" +
                  "    type = integral_loads\n" +
                  "    name = {}\n".format(self.name) +
                  "    start_res = {}\n".format(self.start_res) +
                  "    end_res = {}\n".format(self.end_res) +
                  "    step_res = {}\n".format(self.step_res) +
                  "    format = dat\n" +
                  "    average = {}\n".format("T" if self.average else "F") +
                  "    reference_tag = 0\n")

        # Add list of components
        for comp in self.components:
            string += "    component = {}\n".format(comp)

        # Close the block
        return string + "}\n"

    def parse_file(self, file_name):
        with open(file_name, "r") as f:
            # Skip header
            for _ in range(4):
                f.readline()

            # Average case only has one line
            if self.average:
                line = f.readline().split()
                self.t.append(0.0)
                self.f.append([float(x) for x in line[0:3]])
                self.m.append([float(x) for x in line[3:6]])

            # Read tabulated data otherwise
            else:
                data = f.readlines()
                for _line in data:
                    # Parse line and skip if empty
                    line = _line.strip().split()
                    if not line:
                        continue
                    # Store data
                    self.t.append(float(line[0]))
                    self.f.append([float(x) for x in line[1:4]])
                    self.m.append([float(x) for x in line[4:7]])


class DUSTdriver:
    def __init__(
        self,
        atmosphere,
        propellers=[],
        wings=[],
        options=DUSToptions(),
    ):
        self.propellers = propellers
        self.wings = wings
        self.atmosphere = atmosphere
        self.opts = options

    def run(self):
        print('running DUST')
        # Create preprocess files
        for i, prop in enumerate(self.propellers):
            file_name = "blade_{}.in".format(i)
            prop.write_file(file_name)

        for i, wing in enumerate(self.wings):
            file_name = "wing_{}.in".format(i)
            wing.write_file(file_name)

        self.write_dust_pre()

        # Run `dust_pre`
        sp.run(self.opts.dust_pre)

        # Create simulationfiles
        self.write_references()
        self.write_dust()

        # Run `dust`
        sp.run(self.opts.dust)

    def postprocess(self, analyses=[]):

        # Create postprocess file
        self.write_dust_post(analyses)

        # Run `dust_post`
        sp.run(self.opts.dust_post)

        # Parse postprocessing files
        self.parse_dust_post(analyses)

    def cleanup(self):
        # Delete blade and wing files
        for i in range(len(self.propellers)):
            os.remove("blade_{}.in".format(i))
        for i in range(len(self.wings)):
            os.remove("wing_{}.in".format(i))

        # Delete DUST files
        os.remove("dust_pre.in")
        os.remove("dust.in")
        os.remove("dust_post.in")

        # Delete extra files
        os.remove("geo_input.h5")
        os.remove("references.in")

    def write_dust_pre(self):
        # Write `dust_pre.in` file
        with open("dust_pre.in", "w") as f:
            # Connect components, files and tags for each propeller and wing
            for i in range(len(self.propellers)):
                f.write(
                    "comp_name = Prop_{}\n".format(i) +
                    "geo_file = blade_{}.in\n".format(i) +
                    "ref_tag = Pref_{}\n".format(i) +
                    "\n"
                )

            for i in range(len(self.wings)):
                f.write(
                    "comp_name = Wing_{}\n".format(i) +
                    "geo_file = wing_{}.in\n".format(i) +
                    "ref_tag = Wref_{}\n".format(i) +
                    "\n"
                )

            # Set output name
            f.write("file_name = geo_input.h5\n")

    def write_references(self):
        # Write `references.in` file
        with open("references.in", "w") as f:
            for i, prop in enumerate(self.propellers):
                f.write(
                    "reference_tag = Pref_{}\n".format(i) +
                    "parent_tag = 0\n" +
                    "origin = (/ {:6f}, {:6f}, {:6f} /)\n".format(*prop.pos) +
                    "orientation = (/ {}, {}, {}, {}, {}, {}, {}, {}, {} /)\n".format(
                        # -- X
                        -np.cos(prop.beta) * np.cos(prop.alpha),
                        -np.sin(prop.beta) * np.cos(prop.alpha),
                        np.sin(prop.alpha),
                        # -- Y
                        np.sin(prop.beta),
                        -np.cos(prop.beta),
                        0.0,
                        # -- Z
                        np.cos(prop.beta) * np.sin(prop.alpha),
                        np.sin(prop.beta) * np.sin(prop.alpha),
                        np.cos(prop.alpha),
                    ) +
                    "multiple = T\n" +
                    "moving = F\n" +
                    "\n" +
                    "multiplicity = {\n" +
                    "    mult_type = rotor\n" +
                    "    n_blades = {}\n".format(prop.n_blades) +
                    "    rot_axis = (/ {:.1f}, 0.0, 0.0 /)\n".format(-1.0 if prop.reverse else 1.0) +
                    "    rot_rate = {:.6f}\n".format(prop.rpm / 60.0 * 2*np.pi) +
                    "    psi_0 = 0.0\n" +
                    "    hub_offset = {:.6f}\n".format(prop.rtip * prop.sections[0].roR) +
                    "    n_dofs = 1\n" +
                    "    dof = {\n" +
                    "        hinge_type = Pitch\n" +
                    "        hinge_offset = (/ 0.0, 0.0, 0.0 /)\n" +
                    "        collective = {:.6f}\n".format(prop.pitch) +
                    "    }\n" +
                    "}\n" +
                    "\n"
                )

    def write_dust(self):
        # Compute final time and time step
        max_rpm = max(prop.rpm for prop in self.propellers)
        dt_per_turn = 60.0 / max_rpm
        tend = self.opts.n_turns * dt_per_turn
        dt = dt_per_turn / self.opts.steps_per_turn

        # Write `dust.in` file
        with open("dust.in", "w") as f:
            f.write(
                "basename = {}\n".format(os.path.join(self.opts.output_path, self.opts.name)) +
                "\n" +
                "debug_level = 0\n" +
                "\n" +
                "u_inf = (/ {}, {}, {} /)\n".format(*self.atmosphere.velocity) +
                "rho_inf = {}\n".format(self.atmosphere.density) +
                "a_inf = {}\n".format(self.atmosphere.sound) +
                "p_inf = {}\n".format(self.atmosphere.pressure) +
                "mu_inf = {}\n".format(self.atmosphere.viscosity) +
                "\n" +
                "t_start = {}\n".format(self.opts.t_start) +
                "tend = {:.6f}\n".format(tend) +
                "dt = {:.6e}\n".format(dt) +
                "dt_out = {:.6e}\n".format(dt) +
                "output_start = F\n" +
                "\n" +
                "geometry_file = geo_input.h5\n" +
                "\n" +
                "reference_file = references.in\n" +
                "\n" +
                "n_wake_panels = 1\n" +
                "n_wake_particles = {}\n".format(self.opts.n_wake_particles) +
                "particles_box_min = (/ {}, {}, {} /)\n".format(*self.opts.particles_box_min) +
                "particles_box_max = (/ {}, {}, {} /)\n".format(*self.opts.particles_box_max) +
                "\n" +
                "penetration_avoidance = {}\n".format("T" if self.opts.penetration_avoidance else "F") +
                "\n" +
                "fmm = {}\n".format("T" if self.opts.fmm else "F") +
                "box_length = {}\n".format(self.opts.box_length) +
                "n_box = (/ {}, {}, {} /)\n".format(*self.opts.n_box) +
                "octree_origin = (/ {}, {}, {} /)\n".format(*self.opts.octree_origin) +
                "n_octree_levels = {}\n".format(self.opts.n_octree_levels) +
                "min_octree_part = {}\n".format(self.opts.min_octree_part) +
                "multipole_degree = {}\n".format(self.opts.multipole_degree) +
                "\n" +
                "ll_max_iter = {}\n".format(self.opts.max_iter) +
                "ll_tol = {:.6e}\n".format(self.opts.tol) +
                "vl_maxiter = {}\n".format(self.opts.max_iter) +
                "vl_tol = {:.6e}\n".format(self.opts.tol)
            )

    def write_dust_post(self, analyses):
        # Write `dust_post.in` file
        with open("dust_post.in", "w") as f:
            # Header
            f.write(
                "data_basename = {}\n".format(
                    os.path.join(self.opts.output_path, self.opts.name)) +
                "basename = {}\n".format(
                    os.path.join(self.opts.post_path, self.opts.name)
                )
            )

            # Write analyses
            for analysis in analyses:
                f.write(
                    "\n" +
                    analysis.get_dust_string()
                )

    def parse_dust_post(self, analyses):
        for analysis in analyses:
            file = os.path.join(
                self.opts.post_path, "{}_{}.dat".format(
                    self.opts.name, analysis.name))
            analysis.parse_file(file)


def plot_loads(loads, loads_avg, start_res, end_res):
    # Execute post-process
    loads = DUSTpost_loads()
    loads.name = "loads"
    loads.end_res = 120

    loads_avg = DUSTpost_loads()
    loads_avg.name = "loads_avg"
    loads_avg.start_res = 81
    loads_avg.end_res = 120
    loads_avg.average = True

    dust.postprocess([loads, loads_avg])

    # Plot results
    from matplotlib import pyplot as plt

    rho = dust.atmosphere.density
    n = dust.propellers[0].rpm / 60.0
    D = 2.0 * dust.propellers[0].rtip

    t = loads.t
    Ct = [-f[0] / (rho * n**2 * D**4) for f in loads.f]
    Cq = [ m[0] / (rho * n**2 * D**5) for m in loads.m]

    Ct_avg = -loads_avg.f[0][0] / (rho * n**2 * D**4)
    Cq_avg =  loads_avg.m[0][0] / (rho * n**2 * D**5)

    fix, ax1 = plt.subplots()
    ax2 = ax1.twinx()

    ax1.plot(t, Ct, color="red",  label="CT")
    ax2.plot(t, Cq, color="blue", label="CQ")
    ax1.axhline(y=Ct_avg, color="black", linestyle="dotted")
    ax2.axhline(y=Cq_avg, color="black", linestyle="dotted")

    ax1.set_title("$C_T = {:.4f}$, $C_Q = {:.4f}$".format(Ct_avg, Cq_avg))
    ax1.set_xlabel("$Time$")
    ax1.set_ylabel("$C_T$")
    ax2.set_ylabel("$C_Q$")

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    plt.legend(h1 + h2, l1 + l2)
    plt.show()
