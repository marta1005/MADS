#!/usr/bin/env bash

SRC_DIR=~/Software/CGNS-3.4.0
BUILD_DIR=~/Software/CGNS-3.4.0/build/gnu
DIST_DIR=~/Software/CGNS-3.4.0/dist/gnu

export CC=/opt_cluster/gcc/gcc-6.3.0/bin/gcc
export FC=/opt_cluster/gcc/gcc-6.3.0/bin/gfortran

#####################

mkdir -p $BUILD_DIR
cd $BUILD_DIR

cmake -DCGNS_ENABLE_FORTRAN=ON \
      -DCMAKE_INSTALL_PREFIX=$DIST_DIR \
      $SRC_DIR
make -j4
make install

