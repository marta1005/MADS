"""
Demo: Generate aircraft geometry from CPACS using build123d backend.

Reads a CPACS file via CPACSImporter, generates 3D geometry
using Build123DGenerator, and exports to STEP format.

Usage:
    python examples/demo_geo_build123.py
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from multiads.solvers.synthesis.build123d_generator import Build123DGenerator
from multiads.design_space import CPACSImporter


def main():
    """Main demo function."""
    # 1. Define paths
    base_dir = Path(__file__).parent.parent
    cpacs_file = base_dir / "tests" / "test_design_space" / "test_aircraft_full.xml"
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    print("=" * 60)
    print("MultiADS Geometry Generation Demo (build123d backend)")
    print("=" * 60)
    print(f"CPACS file: {cpacs_file}")
    print(f"Output directory: {output_dir}\n")

    # ============================================
    # Method 1: Using Build123DGenerator directly
    # ============================================
    print("=" * 60)
    print("Method 1: Build123DGenerator - Complete Aircraft")
    print("=" * 60)

    try:
        generator = Build123DGenerator()
        generator.load_cpacs(cpacs_file)

        # Generate complete aircraft with stabilizers
        print("Generating complete aircraft geometry...")
        aircraft_solid = generator.generate_aircraft(
            symmetry=True,
            fillet_radius=0.1,  # Smaller fillet radius for test geometry
            auto_detect_stabilizers=True,
        )

        if aircraft_solid:
            step_path = output_dir / "aircraft_complete.step"
            generator.export_step(aircraft_solid, step_path)
            print(f"✓ Exported complete aircraft to: {step_path}")

            # Get geometry metrics
            metrics = generator.get_geometry_metrics(aircraft_solid)
            print(f"\nGeometry metrics:")
            print(f"  Volume: {metrics.get('volume', 'N/A'):.4f} m³")
            print(f"  Surface area: {metrics.get('surface_area', 'N/A'):.4f} m²")
        else:
            print("✗ Failed to generate aircraft geometry")

    except Exception as e:
        print(f"✗ Build123DGenerator failed: {e}")
        import traceback
        traceback.print_exc()

    # ============================================
    # Method 2: Generate individual components
    # ============================================
    print("\n" + "=" * 60)
    print("Method 2: Individual Component Generation")
    print("=" * 60)

    try:
        generator2 = Build123DGenerator()
        generator2.load_cpacs(cpacs_file)

        # Generate wing
        print("\nGenerating wing (MainWing)...")
        wing_solid = generator2.generate_wing_from_cpacs("MainWing")
        if wing_solid:
            wing_step = output_dir / "wing.step"
            generator2.export_step(wing_solid, wing_step)
            print(f"✓ Exported wing to: {wing_step}")

        # Generate fuselage
        print("\nGenerating fuselage (SimpleFuselage)...")
        fuselage_solid = generator2.generate_fuselage_from_cpacs("SimpleFuselage")
        if fuselage_solid:
            fuselage_step = output_dir / "fuselage.step"
            generator2.export_step(fuselage_solid, fuselage_step)
            print(f"✓ Exported fuselage to: {fuselage_step}")

        # Generate horizontal stabilizer
        print("\nGenerating horizontal stabilizer...")
        hstab_solid = generator2.generate_wing_from_cpacs("HorizontalStabilizer")
        if hstab_solid:
            hstab_step = output_dir / "horizontal_stabilizer.step"
            generator2.export_step(hstab_solid, hstab_step)
            print(f"✓ Exported horizontal stabilizer to: {hstab_step}")

        # Generate vertical stabilizer
        print("\nGenerating vertical stabilizer...")
        vstab_solid = generator2.generate_wing_from_cpacs("VerticalStabilizer")
        if vstab_solid:
            vstab_step = output_dir / "vertical_stabilizer.step"
            generator2.export_step(vstab_solid, vstab_step)
            print(f"✓ Exported vertical stabilizer to: {vstab_step}")

    except Exception as e:
        print(f"✗ Component generation failed: {e}")
        import traceback
        traceback.print_exc()

    # ============================================
    # Method 3: Using CPACSImporter for analysis
    # ============================================
    print("\n" + "=" * 60)
    print("Method 3: CPACSImporter - Aircraft Analysis")
    print("=" * 60)

    try:
        importer = CPACSImporter(str(cpacs_file), validate=False)

        # Load aircraft components
        print("\nLoading aircraft components...")
        aircraft = importer.load_aircraft(
            "aircraftModel",
            load_wings=True,
            load_fuselages=True,
            load_nacelles=False,
            load_engines=False,
        )

        print(f"\nAircraft: {aircraft.name}")
        print(f"  Reference area: {aircraft.s_ref} m²")
        print(f"  Reference length: {aircraft.l_ref} m")

        # Analyze wing
        print("\nWing analysis:")
        wing = importer.load_wing("MainWing")
        print(f"  Name: {wing.name}")
        print(f"  Sections: {len(wing.sections)}")
        print(f"  Spans: {len(wing.spans)}")
        print(f"  Symmetry: {wing.symmetry}")
        print(f"  Aspect ratio: {wing.aspect_ratio:.2f}")
        print(f"  Span: {wing.span:.2f} m")
        print(f"  MAC: {wing.mac:.2f} m")
        print(f"  Area: {wing.area:.2f} m²")

        # List all variables created
        print(f"\nVariables created: {len(importer.variables)}")
        for name, var in list(importer.variables.items())[:5]:
            print(f"  - {name}: {var.value}")

    except Exception as e:
        print(f"✗ CPACSImporter analysis failed: {e}")
        import traceback
        traceback.print_exc()

    # ============================================
    # Summary
    # ============================================
    print("\n" + "=" * 60)
    print("Demo Complete!")
    print("=" * 60)
    print(f"\nOutput files in: {output_dir}")
    for f in sorted(output_dir.iterdir()):
        if f.is_file():
            size_kb = f.stat().st_size / 1024
            print(f"  - {f.name} ({size_kb:.1f} KB)")

    print("\nYou can open the STEP files in any CAD software:")
    print("  - FreeCAD (free)")
    print("  - Blender (free, with STEP addon)")
    print("  - SolidWorks, CATIA, etc.")


if __name__ == "__main__":
    main()
