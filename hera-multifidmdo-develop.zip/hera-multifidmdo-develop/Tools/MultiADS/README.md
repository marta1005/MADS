# MADS
## (Multidisplinary Analysis Design and Simulation) 

<img src="Tools/MultiADS/docs/images/Logo_MADS.jpg" alt="MADS Logo" align="right" width="250">

## Getting started

This project is a shared environment focusing on MDO for Flight Physics applications

## Support

Contact us to get your DEVELOPERS rights or to access the libraries

- Simone Mancini (simone.mancini@airbus.com)
- Andres Mateo (andres.mateo@airbus.com)

Contributors:
- Tim Klaproth (tim.klaproth@airbus.com)

## Develop

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin <address>
git branch -M main
git push -uf origin main
```

## Project status
v 0.00.3 - conceptual library

## Examples

<details>
<summary>see dedicate example</summary>

```diff
+ ./example folder
+ ./test folder

```

## Roadmap

v 0.0.4 - complete refactoring inner variables
v 0.1   - release of integrated environment


### Integrate with your tools

- [ ] [Set up project integrations](<address>)

### Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Automatically merge when pipeline succeeds](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/index.html)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing(SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

## Development Notes

- need to relink "xrotor" in /solvers/propulsion/__init__.py when you would like to use the library in Linux [in windows is not possible]
