.. MADS documentation master file, created by
   sphinx-quickstart on Tue Jul 23 13:28:16 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. image:: images/Logo_MADS.jpg
   :width: 200
   :align: center
   :alt: MADS Logo

Welcome to MADS's documentation!
=====================================

MADS (Multi-Disciplinary Analysis and Design System) is a Python-based 
framework for multidisciplinary optimization problems. It integrates various 
physics domains including aerodynamics, propulsion, and radar systems.

Key Features
------------

* **Propulsion Solver**: Low-fidelity propeller and thermal engine models with custom Jacobian support
* **Aerodynamics Solver**: DUST-based aerodynamic computations
* **Radar Solver**: Radar cross-section and absorption analysis using SILENCE
* **GEMSEO Integration**: Seamless integration with GEMSEO for optimization
* **Custom Jacobians**: Analytical sensitivity computation for faster optimization

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
