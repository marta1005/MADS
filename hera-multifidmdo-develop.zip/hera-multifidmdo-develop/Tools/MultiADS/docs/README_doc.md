# Building the Documentation

This document explains how to build the MADS documentation.

## Prerequisites

Install the required packages:

```bash
pip install sphinx sphinx-rtd-theme
```

## Building the Documentation

### Using Make (recommended)

```bash
cd docs
make html
```

The generated HTML files will be in `docs/_build/html/`.

### Using Sphinx directly

```bash
cd docs
sphinx-build -b html src _build/html
```

## Viewing the Documentation

Open the generated HTML files in a web browser:

```bash
# On Linux/Mac
open _build/html/index.html

# On Windows
start _build/html/index.html
```

## Cleaning the Build

To remove the generated files:

```bash
cd docs
make clean
```

Or manually:

```bash
rm -rf docs/_build/
```

## Documentation Structure

```
docs/
├── conf.py              # Sphinx configuration
├── index.rst            # Main documentation page
├── src.rst              # Package overview
├── src.solvers.rst      # Solvers package
├── src.solvers.aerodynamics.rst
├── src.solvers.propulsion.rst
├── src.data_persistence.rst
├── src.disciplines.rst
├── src.objectives.rst
├── images/              # Documentation images
│   └── Logo_MADS.jpg
├── Makefile             # Build automation
└── _build/             # Generated output (after building)
```

## Adding New Modules to Documentation

When adding new modules to the codebase, create corresponding `.rst` files in the `docs/` folder:

1. Create `docs/src.solvers.newmodule.rst` with:

```rst
src.solvers.newmodule package
=============================

Module contents
--------------

.. automodule:: src.solvers.newmodule
   :members:
   :undoc-members:
   :show-inheritance:
```

2. Add to `docs/src.solvers.rst`:

```rst
src.solvers package
===================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.solvers.aerodynamics
   src.solvers.propulsion
   src.solvers.newmodule    # Add this line
```

3. Rebuild the documentation with `make html`.
