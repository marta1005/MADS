from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

import multiads.solvers.stability_control.dust_snc_lib as dl
from multiads.assembly import (
    Aircraft,
    Environment,
    Fuselage,
    MADSComponent,
    Propeller,
    Wing,
    copy_components,
    flatten_components,
)
from multiads.scenario.aero_derivatives import AeroDerivativesVariable
from multiads.scenario.variables import (
    BaseVariable,
    InnerVariableFloat,
)
from multiads.solvers import BaseSolver
from multiads.solvers.aerodynamics import dust_lib as aerodust_lib

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from numpy.typing import NDArray


class DUST_SNC(BaseSolver):
    def __init__(self, options: dl.Options) -> None:
        super().__init__()
        self.options: dl.Options = options
        self.driver: dl.DUSTAeroDerivatives | None = None
        self.environment: Environment | None = None
        self.aircraft: Aircraft | None = None
        self.wings: Sequence[aerodust_lib.Wing] | None = None
        self.propellers: Sequence[aerodust_lib.Propeller] | None = None
        self.fuselages: Sequence[aerodust_lib.Fuselage] | None = None
        self.run_directory: Path | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv: Any,  # noqa: ANN401, ARG002
    ) -> Sequence[MADSComponent]:
        # Initialize components
        self.environment, aircraft, wings, propellers, fuselages = (
            self._initialize_components(
                components,
            )
        )
        self.aircraft = aircraft
        self.wings, self.propellers, self.fuselages = self._remap_components(
            wings,
            propellers,
            fuselages,
        )

        # Inputs - create AeroDerivativesVariable for GLOBAL frame
        inputs: list[BaseVariable] = []
        if self.aircraft:
            prefix = self.aircraft.name
            aero_var = AeroDerivativesVariable.from_global(f"{prefix}.aero_derivatives")
            inputs.append(aero_var)

        self.inputs = inputs
        self.inputs_map = {v.name: v for v in self.inputs}

        # Outputs
        if self.wings is not None:
            self.outputs = self._create_output_variables(self.wings)
            self.outputs_map = {v.name: v for v in self.outputs}

        result: list[MADSComponent] = [self.environment]
        if self.aircraft is not None:
            result.append(self.aircraft)
        result.extend(wings)
        result.extend(propellers)
        result.extend(fuselages)
        return result

    def _initialize_components(
        self,
        components: Sequence[MADSComponent],
    ) -> tuple[
        Environment,
        Aircraft | None,
        Sequence[Wing],
        Sequence[Propeller],
        Sequence[Fuselage],
    ]:
        _components = copy_components(components)
        comp_flat = flatten_components(_components)

        wings = [c for c in comp_flat if type(c) is Wing]
        propellers = [c for c in comp_flat if type(c) is Propeller]
        fuselages = [c for c in comp_flat if type(c) is Fuselage]

        try:
            environment = next(c for c in comp_flat if type(c) is Environment)
        except StopIteration:
            msg = f"An environment must be provided to solver '{type(self).__name__}'."
            raise ValueError(msg) from None

        aircraft = next((c for c in comp_flat if type(c) is Aircraft), None)

        return environment, aircraft, wings, propellers, fuselages

    def _remap_components(
        self,
        wings: Sequence[Wing],
        propellers: Sequence[Propeller],
        fuselages: Sequence[Fuselage],
    ) -> tuple[
        list[aerodust_lib.Wing],
        list[aerodust_lib.Propeller],
        list[aerodust_lib.Fuselage],
    ]:
        wings_mapped = [aerodust_lib.Wing.from_component(w) for w in wings]
        propellers_mapped = [
            aerodust_lib.Propeller.from_component(p) for p in propellers
        ]
        fuselages_mapped = [aerodust_lib.Fuselage.from_component(f) for f in fuselages]
        return wings_mapped, propellers_mapped, fuselages_mapped

    def _create_output_variables(
        self,
        wings: Sequence[aerodust_lib.Wing],
    ) -> Sequence[InnerVariableFloat]:
        outputs: list[InnerVariableFloat] = []

        for wing in wings:
            outputs.extend(
                [
                    InnerVariableFloat(f"{wing.name}.dCx", 0.0),
                    InnerVariableFloat(f"{wing.name}.dCy", 0.0),
                    InnerVariableFloat(f"{wing.name}.dCz", 0.0),
                    InnerVariableFloat(f"{wing.name}.dCl", 0.0),
                    InnerVariableFloat(f"{wing.name}.dCm", 0.0),
                    InnerVariableFloat(f"{wing.name}.dCn", 0.0),
                    InnerVariableFloat(f"{wing.name}.NP", 0.0),
                ]
            )

        return outputs

    def _run(self) -> None:
        if (
            self.environment is None
            or self.wings is None
            or self.propellers is None
            or self.fuselages is None
            or self.run_directory is None
        ):
            msg = f"The solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        # Change to local directory and run
        main_dir = Path.cwd()
        os.chdir(self.run_directory)

        self.driver = dl.DUSTAeroDerivatives(
            environment=self.environment,
            options=self.options,
            wings=self.wings,
            propellers=self.propellers,
            fuselages=self.fuselages,
        )

        self.driver.execute()

        # Back to main directory
        os.chdir(main_dir)

    def compute_output(self) -> None:
        if (
            self.environment is None
            or self.wings is None
            or self.propellers is None
            or self.fuselages is None
        ):
            msg = f"Components of solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        if self.outputs is None or self.outputs_map is None:
            msg = f"The interface of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.driver is None or self.run_directory is None:
            msg = f"The solver '{type(self).__name__}' has not run yet."
            raise RuntimeError(msg)

        if self.inputs_map is not None and self.aircraft is not None:
            prefix = self.aircraft.name
            aero_var_name = f"{prefix}.aero_derivatives"
            if aero_var_name in self.inputs_map:
                aero_var = self.inputs_map[aero_var_name]
                if isinstance(aero_var, AeroDerivativesVariable):
                    self._compute_aero_derivatives(aero_var)

    def _compute_aero_derivatives(self, aero_var: AeroDerivativesVariable) -> None:
        """Compute and store aerodynamic derivatives in the AeroDerivativesVariable.

        Fills the matrix with derivatives from each analysis type.
        Rows:
            0 - Alpha derivatives (dCx, dCy, dCz, dCl, dCm, dCn)
            1 - Beta derivatives
            2 - p (roll rate) derivatives
            3 - q (pitch rate) derivatives
            4 - r (yaw rate) derivatives
            5 - Alpha dot derivatives
            6 - Beta dot derivatives
            7 - Pitching moment derivatives
            8 - Yawing moment derivatives
            9 - Delta aileron derivatives
            10 - Delta elevator derivatives
            11 - Delta rudder derivatives
        """
        if self.wings is None or len(self.wings) == 0:
            return

        l_ref = self.aircraft.l_ref if self.aircraft else 1.0

        for w in self.wings:
            dCx = dl.dCx(w.name, self.driver, A_ref=1.0, l_ref=l_ref)
            dCy = dl.dCy(w.name, self.driver, A_ref=1.0, l_ref=l_ref)
            dCz = dl.dCz(w.name, self.driver, A_ref=1.0, l_ref=l_ref)
            dCl = dl.dCl(w.name, self.driver, A_ref=1.0, l_ref=l_ref)
            dCm = dl.dCm(w.name, self.driver, A_ref=1.0, l_ref=l_ref)
            dCn = dl.dCn(w.name, self.driver, A_ref=1.0, l_ref=l_ref)

            derivatives = np.concatenate([dCx, dCy, dCz, dCl, dCm, dCn])

            if self.options.analysis_type == dl.SnCAnalysisType.STATIC:
                if self.options.derivative_type == dl.SnCDerivativeType.ALPHA:
                    aero_var.matrix[0, :] = derivatives
                elif self.options.derivative_type == dl.SnCDerivativeType.BETA:
                    aero_var.matrix[1, :] = derivatives

            elif self.options.analysis_type == dl.SnCAnalysisType.CONTROL:
                aero_var.matrix[9, :] = derivatives

            elif self.options.analysis_type == dl.SnCAnalysisType.ZERO_ATTITUDE:
                aero_var.matrix[0, :] = derivatives

    def compute_sensitivities(
        self,
        input_names: Sequence[str],  # noqa: ARG002
        inputs: Sequence[BaseVariable],  # noqa: ARG002
        output_names: Sequence[str],  # noqa: ARG002
        outputs: Sequence[BaseVariable],  # noqa: ARG002
    ) -> Mapping[str, NDArray]:
        return {}


class AeroDerivatives:
    implemented_outputs = {
        "dCx": dl.dCx,
        "dCy": dl.dCy,
        "dCz": dl.dCz,
        "dCl": dl.dCl,
        "dCm": dl.dCm,
        "dCn": dl.dCn,
        #       "AeroDerivatives": dl.aero_derivatives,
        "NP": dl.NP,
    }
