from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from multiads import assembly
from multiads.solvers import SolverOptions
from multiads.solvers.aerodynamics import dust_lib
from multiads.solvers.aerodynamics.dust_lib import (
    Driver as DustDriver,
    Options as DustOptions,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class SnCAnalysisType(Enum):
    STATIC = "static"
    DYNAMIC = "dynamic"
    CONTROL = "control"
    ZERO_ATTITUDE = "zero_attitude"


class SnCDerivativeType(Enum):
    ALPHA = "alpha"
    BETA = "beta"
    ROLL = "roll"
    PITCH = "pitch"
    YAW = "yaw"
    PLUNGE = "plunge"
    LATERAL = "lateral"
    PHUGOID = "phugoid"
    LATERAL_PHUGOID = "lateral_phugoid"


class Options(DustOptions):
    def __init__(
        self,
        *,
        analysis_type: SnCAnalysisType | None = None,
        derivative_type: SnCDerivativeType | None = None,
        d_aoa: float = 0.0,
        d_aob: float = 0.0,
        derivative_ampl: float = 0.0,
        derivative_omega: float = 0.0,
        derivative_n_periods: int = 1,
        derivative_n_start: int = 1,
        jac_approx_type: str = "finite_differences",
        jac_approx_step: float = 1e-03,
        jac_approx_n_processes: int = 1,
        jac_approx_use_threading: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.analysis_type = analysis_type or SnCAnalysisType.STATIC
        self.derivative_type = derivative_type or SnCDerivativeType.ALPHA
        self.d_aoa = d_aoa
        self.d_aob = d_aob
        self.derivative_ampl = derivative_ampl
        self.derivative_omega = derivative_omega
        self.derivative_n_periods = derivative_n_periods
        self.derivative_n_start = derivative_n_start
        self.jac_approx_type = jac_approx_type
        self.jac_approx_step = jac_approx_step
        self.jac_approx_n_processes = jac_approx_n_processes
        self.jac_approx_use_threading = jac_approx_use_threading


class DUSTAeroDerivatives:
    """Extract aerodynamic derivatives for S&C.

    Perform differential or oscillatory simulations needed to extract the values of the
    aerodynamic stability and control derivatives.
    """

    def __init__(
        self,
        environment: assembly.Environment,
        options: Options,
        wings: Sequence[dust_lib.Wing] | None = None,
        propellers: Sequence[dust_lib.Propeller] | None = None,
        fuselages: Sequence[dust_lib.Fuselage] | None = None,
    ) -> None:
        self.environment = environment
        self.options = options
        self.wings = wings or []
        self.propellers = propellers or []
        self.fuselages = fuselages or []
        self.driver: dust_lib.Driver | None = None

    def preprocess(self) -> None:
        if self.driver is None:
            self._create_driver()
        self.driver.preprocess()

    def run(self) -> None:
        if self.driver is None:
            self._create_driver()
        self.driver.run()

    def postprocess(self, forces: Any) -> None:
        if self.driver is None:
            self._create_driver()
        self.driver.postprocess(forces)

    def _create_driver(self) -> None:
        self.driver = DustDriver(
            environment=self.environment,
            wings=self.wings,
            propellers=self.propellers,
            fuselages=self.fuselages,
            options=self.options,
        )

    def compute_dust(self) -> None:
        self.preprocess()
        self.run()

    def execute(self) -> None:
        """Execute the stability and control analysis."""
        analysis_type = self.options.analysis_type

        if analysis_type == SnCAnalysisType.STATIC:
            self._run_static()
        elif analysis_type == SnCAnalysisType.CONTROL:
            self._run_control()
        elif analysis_type == SnCAnalysisType.DYNAMIC:
            self._run_dynamic()
        elif analysis_type == SnCAnalysisType.ZERO_ATTITUDE:
            self._run_zero_attitude()
        else:
            msg = "SnC analysis not specified for stability computation."
            raise ValueError(msg)

    def _run_static(self) -> None:
        self._create_driver()
        self.options.output_dir = (
            self.options.work_dir / self.options.output_dir / "output_1"
        )
        self.compute_dust()

        d_aoa = 0.0
        d_aob = 0.0

        if self.options.derivative_type == SnCDerivativeType.ALPHA:
            d_aoa = self.options.d_aoa
            self.environment.alpha += d_aoa
        elif self.options.derivative_type == SnCDerivativeType.BETA:
            d_aob = self.options.d_aob
            self.environment.beta += d_aob

        self.options.output_dir = (
            self.options.work_dir / self.options.output_dir / "output_2"
        )
        self.compute_dust()

        if self.options.derivative_type == SnCDerivativeType.ALPHA:
            self.environment.alpha -= d_aoa
        elif self.options.derivative_type == SnCDerivativeType.BETA:
            self.environment.beta -= d_aob

    def _run_control(self) -> None:
        self._create_driver()
        self.options.output_dir = (
            self.options.work_dir / self.options.output_dir / "output_1"
        )
        self.compute_dust()

        for wing in self.wings:
            wing_name = wing.name
            movable_surfaces = wing.movable_surfaces

            for i, h in enumerate(movable_surfaces):
                if h.derivative:
                    d_delta = h.d_delta
                    movable_surfaces[i].ampl += d_delta

                    self.options.output_dir = (
                        self.options.work_dir
                        / self.options.output_dir
                        / f"output_2_{wing_name}_movable_surface{i}"
                    )
                    self.compute_dust()

                    movable_surfaces[i].ampl -= d_delta

    def _run_dynamic(self) -> None:
        self._create_driver()
        self.compute_dust()

    def _run_zero_attitude(self) -> None:
        self._create_driver()
        self.environment.alpha = 0
        self.environment.beta = 0
        self.compute_dust()


def compute_derivative(name, driver, **kwargs) -> NDArray[np.float64]:
    """Compute aerodynamic force and moment derivatives as a 6-component vector."""
    if (
        driver.options.analysis_type == SnCAnalysisType.STATIC
        or driver.options.analysis_type == SnCAnalysisType.CONTROL
    ):
        A_ref = kwargs.get("A_ref", 1.0)
        l_ref = kwargs.get("l_ref", 1.0)
        wing_name = kwargs.get("wing_name", 1.0)
        movable_surface_index = kwargs.get("movable_surface_index", 1)
        exclude_keys = {"A_ref", "l_ref", "wing_name", "movable_surface_index"}
        filtered_kwargs = {k: v for k, v in kwargs.items() if k not in exclude_keys}

        ext_output_dir = driver.options.output_dir

        driver.options.output_dir = (
            driver.options.work_dir / ext_output_dir / "output_1"
        )
        forces_1 = DUSTpost_loads(name, average=True, **filtered_kwargs)
        driver.postprocess([forces_1])
        m1, f1 = forces_1.m[-1], forces_1.f[-1]

        delta = 0.0
        output_2 = "output_2"

        if driver.options.analysis_type == SnCAnalysisType.STATIC:
            if driver.options.derivative_type == SnCDerivativeType.ALPHA:
                delta = driver.options.d_aoa
            elif driver.options.derivative_type == SnCDerivativeType.BETA:
                delta = driver.options.d_aob
        elif driver.options.analysis_type == SnCAnalysisType.CONTROL:
            wing = next((w for w in driver.wings if w.name == wing_name), None)

            if wing is None:
                raise ValueError(f"Wing '{wing_name}' not found in driver.wings")

            delta = wing.movable_surfaces[movable_surface_index].dDelta
            output_2 = f"output_2_{wing_name}_movable_surface{movable_surface_index}"

        driver.options.output_dir = driver.options.work_dir / ext_output_dir / output_2
        forces_2 = DUSTpost_loads(name, average=True, **filtered_kwargs)
        driver.postprocess([forces_2])
        m2, f2 = forces_2.m[-1], forces_2.f[-1]

        driver.options.output_dir = ext_output_dir

        df = (np.asarray(f2) - np.asarray(f1)) / (delta * np.pi / 180)
        dm = (np.asarray(m2) - np.asarray(m1)) / (delta * np.pi / 180)

        q = (
            0.5
            * driver.environment.density
            * (np.linalg.norm(driver.environment.velocity)) ** 2
        )
        f_denominator = q * A_ref
        m_denominator = q * A_ref * l_ref

        f_derivatives = df / f_denominator
        m_derivatives = dm / m_denominator

    elif driver.options.analysis_type == SnCAnalysisType.DYNAMIC:
        A_ref = kwargs.get("A_ref", 1.0)
        l_ref = kwargs.get("l_ref", 1.0)
        exclude_keys = {"A_ref", "l_ref", "wing_name", "movable_surface_index"}
        filtered_kwargs = {k: v for k, v in kwargs.items() if k not in exclude_keys}

        omega = driver.options.derivative_omega
        A = driver.options.derivative_ampl
        f = omega / (2 * np.pi)
        k = l_ref * omega / np.linalg.norm(driver.environment.velocity)
        T = 1 / f
        N_start = driver.options.derivative_n_start
        N_per = driver.options.derivative_n_periods
        dt = driver.options.dt

        forces = DUSTpost_loads(name, average=False, **filtered_kwargs)
        driver.postprocess([forces])
        t, f, m = forces.t, forces.f, forces.m

        q = (
            0.5
            * driver.environment.density
            * (np.linalg.norm(driver.environment.velocity)) ** 2
        )
        f_denominator = q * A_ref
        m_denominator = q * A_ref * l_ref

        f_coefficient = f / f_denominator
        m_coefficient = m / m_denominator

        i_start = int(np.ceil(N_start * (T / dt)) - 1)
        i_end = int(np.ceil(N_start * (T / dt)) + int(np.ceil(N_per * (T / dt))))
        t = np.array(t)
        t = t[i_start:i_end]
        f_coefficient = f_coefficient[i_start:i_end]
        m_coefficient = m_coefficient[i_start:i_end]

        f_derivatives = (
            f_coefficient[-1] - f_coefficient[int(np.ceil(T / dt) // 2)]
        ) / (2 * k * A)
        m_derivatives = (
            m_coefficient[-1] - m_coefficient[int(np.ceil(T / dt) // 2)]
        ) / (2 * k * A)

        if (
            driver.options.derivative_type == SnCDerivativeType.PLUNGE
            or driver.options.derivative_type == SnCDerivativeType.LATERAL
            or driver.options.derivative_type == SnCDerivativeType.PHUGOID
            or driver.options.derivative_type == SnCDerivativeType.LATERAL_PHUGOID
        ):
            f_derivatives = (
                f_derivatives * (np.linalg.norm(driver.environment.velocity)) / omega
            )
            m_derivatives = (
                m_derivatives * (np.linalg.norm(driver.environment.velocity)) / omega
            )

    elif driver.options.analysis_type == SnCAnalysisType.ZERO_ATTITUDE:
        A_ref = kwargs.get("A_ref", 1.0)
        l_ref = kwargs.get("l_ref", 1.0)
        exclude_keys = {"A_ref", "l_ref", "wing_name", "movable_surface_index"}
        filtered_kwargs = {k: v for k, v in kwargs.items() if k not in exclude_keys}

        forces = DUSTpost_loads(name, average=True, **filtered_kwargs)
        driver.postprocess([forces])
        m, f = forces.m[-1], forces.f[-1]

        q = (
            0.5
            * driver.environment.density
            * (np.linalg.norm(driver.environment.velocity)) ** 2
        )
        f_denominator = q * A_ref
        m_denominator = q * A_ref * l_ref

        f_derivatives = f / f_denominator
        m_derivatives = m / m_denominator
    else:
        f_derivatives = np.zeros(3)
        m_derivatives = np.zeros(3)

    return np.concatenate((f_derivatives, m_derivatives))


def DUSTpost_loads(name, average=False, **kwargs):
    """Wrapper for DUST postprocess loads function."""
    from multiads.solvers.aerodynamics.dust_lib import PostLoads
    return PostLoads(name=name, average=average, **kwargs)


def dCx(name, driver, **kwargs):
    return np.array([compute_derivative(name, driver, **kwargs)[0]])


def dCy(name, driver, **kwargs):
    return np.array([compute_derivative(name, driver, **kwargs)[1]])


def dCz(name, driver, **kwargs):
    return np.array([compute_derivative(name, driver, **kwargs)[2]])


def dCl(name, driver, **kwargs):
    return np.array([compute_derivative(name, driver, **kwargs)[3]])


def dCm(name, driver, **kwargs):
    return np.array([compute_derivative(name, driver, **kwargs)[4]])


def dCn(name, driver, **kwargs):
    return np.array([compute_derivative(name, driver, **kwargs)[5]])


def aero_derivatives(name, driver, **kwargs):
    return np.concatenate(
        [
            dCx(name, driver, **kwargs),
            dCy(name, driver, **kwargs),
            dCz(name, driver, **kwargs),
            dCl(name, driver, **kwargs),
            dCm(name, driver, **kwargs),
            dCn(name, driver, **kwargs),
        ],
    )


def NP(name, driver, **kwargs) -> NDArray[np.float64]:
    if (
        driver.options.analysis_type == SnCAnalysisType.STATIC
        and driver.options.derivative_type == SnCDerivativeType.ALPHA
    ):
        l_ref = kwargs.get("l_ref", 1.0)
        neutral_point = -(l_ref * dCm(name, driver, **kwargs)) / dCz(
            name,
            driver,
            **kwargs,
        )

        return neutral_point

    return np.array([0.0])
