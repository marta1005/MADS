## Mission module :: descent
# Constant_Ma_Constant_AoA.py
# 
# Created:  
# Modified: 
#         

# ----------------------------------------------------------------------
#  Imports
# ----------------------------------------------------------------------

import numpy as np

class ConstMaConstAlt:
# -------------------------------------------------------------------------------------
#  Initialize Conditions
# --------------------------------------------------------------------------------------
    def __init__(self,segment,environment,massproperties,stability_control_properties):
        """Sets the specified conditions which are given for the segment type.

        Assumptions:
        Constant Mach number, with a constant angle of descent

        Source:
        N/A

        Inputs:
        segment.mach                                        [Unitless]
        segment.altitude_start                              [meters]
        segment.altitude_end                                [meters]
        segment.state.numerics.dimensionless.control_points [Unitless]
        conditions.freestream.density                       [kilograms/meter^3]

        Outputs:
        conditions.frames.inertial.velocity_vector  [meters/second]
        conditions.frames.inertial.position_vector  [meters]
        conditions.freestream.altitude              [meters]

        Properties Used:
        N/A
        """       
        # unpack user inputs
        self.mach_number   = (segment.airspeed_start+segment.airspeed_end)/2.0/environment.sound_speed 
        self.alt0        = segment.altitude_start 
        self.altf        = segment.altitude_end
        self.time_dim    = segment.duration # segment.state.numerics.dimensionless.control_points
        self.conditions  = environment      # segment.state.conditions 
        self.massproperties = massproperties
        self.stability_control_properties = stability_control_properties
        # gravitational constant
        self.g = 9.81

        # unpack unknowns
        #throttle = segment.state.unknowns.throttle
        #theta    = segment.state.unknowns.body_angle
        #alts     = segment.state.unknowns.altitudes   

        # check for initial altitude
        if self.alt0 is None:
            if not segment.state.initials: raise AttributeError('initial altitude not set')
            self.alt0 = 0.0 # -1.0 * segment.state.initials.conditions.frames.inertial.position_vector[-1,2]

        # pack conditions   
        # conditions.freestream.altitude[:,0]             =  alts[:,0] # positive altitude in this context

        # Update freestream to get speed of sound
        # SUAVE.Methods.Missions.Segments.Common.Aerodynamics.update_atmosphere(segment)
        a = environment.sound_speed # conditions.freestream.speed_of_sound    

        # process velocity vector
        self.v_mag = self.mach_number * a
        self.v_x   = self.v_mag 
        self.v_z   = 0.0

        # pack conditions    
        #self.velocity_vector = v_x[:,0] # conditions.velocity_vector[:,0] = v_x[:,0]
        #conditions.frames.inertial.velocity_vector[:,2] = v_z[:,0]
        #conditions.frames.inertial.position_vector[:,2] = -alts[:,0] # z points down
        #segment.state.conditions.propulsion.throttle[:,0]            = throttle[:,0]
        #segment.state.conditions.frames.body.inertial_rotations[:,1] = theta[:,0]
        # initialise output
        self.forces = np.zeros(3)
        self.res_forces = np.zeros(3)
        self.delta_energy = 0.0
        self.load_factor = 0.0
    
    def run(self):
        
        #compute forces
        self.compute_total_forces()
        # compute energy consumption
        self.compute_energy()
        
        
    
    def compute_total_forces(self):
        
        #  T - D = W sin (gamma) :: dynmics along :: Fx
        self.forces[0] = self.stability_control_properties.drag
               
        # L = W :: dynamics along Y :: Fy 
        self.forces[2] = self.massproperties.mass * self.g
        
        # load factor L/W
        self.load_factor = 1.0
    
        return  self.forces
    
        # mission residuals == 0
    def compute_mission_residuals(self):
        
        # Res(Fx)
        self.res_forces[0] = self.forces[0] -  self.stability_control_properties.drag + self.massproperties.mass * self.g
        
        # Res(Fz)
        self.res_forces[2] = self.forces[2] - self.massproperties.mass * self.g
        
        # Res(Fy) :: 0 because symmetruc
        self.res_forces[1] = 0
        
        return self.res_forces

    
    def compute_energy(self):
        
        # sum of potential, kinetic and viscous effects
        RoC = 0.0            # [m/s] # Rate of climb
        Dt = self.time_dim   # [s] duration of the maneuver
        self.delta_energy = self.massproperties.mass * self.g * self.conditions.velocity * Dt / (self.stability_control_properties.lift/self.stability_control_properties.drag) + self.massproperties.mass * self.conditions.velocity**2 /2 + self.massproperties.mass * self.g *RoC * Dt
        
        return self.delta_energy
    
    def compute_load_factor(self):
        
        # load factor L/W
        self.load_factor = 1.0
    
        return  self.load_factor
        
        