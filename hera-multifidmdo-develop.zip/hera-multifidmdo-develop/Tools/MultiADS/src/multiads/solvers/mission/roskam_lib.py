from __future__ import annotations

import math
from typing import Any, Sequence

import numpy as np
from multiads.ambiance import Atmosphere
from numpy.typing import NDArray

from multiads.assembly import (
    Configuration as Base_Configuration,
    PropulsionSystem as Base_PropulsionSystem,
    Wing as Base_Wing,
)
from multiads.assembly.envelope import Segment
from multiads.solvers import SolverOptions
from multiads.scenario.polars import PolarVariable
from multiads import assembly



class PolarData:
    """Adapter for different polar data formats.

    Supports:
    - AerodynamicPolarData (legacy: alpha, lift_coefficient, drag_coefficient arrays)
    - PolarVariable (from neuralfoil/dust: mach, reynolds, aoa, cl, cd, cm)
    - Dict format (from other solvers)
    """

    def __init__(self, polar_data) -> None:
        self._source = polar_data
        self._source_type = self._detect_type(polar_data)

    def _detect_type(self, data):
        if isinstance(data, PolarVariable):
            return "polar_variable"
        elif hasattr(data, "alpha") and hasattr(data, "lift_coefficient"):
            return "aerodynamic_polar_data"
        elif isinstance(data, dict):
            return "dict"
        raise ValueError(f"Unsupported polar data type: {type(data)}")

    @property
    def alpha(self) -> NDArray[np.float64]:
        if self._source_type == "polar_variable":
            return np.array(self._source.aoa).flatten()
        elif self._source_type == "aerodynamic_polar_data":
            return np.array(self._source.alpha).flatten()
        elif self._source_type == "dict":
            return np.array(self._source.get("alpha", [])).flatten()
        return np.array([])

    @property
    def lift_coefficient(self) -> NDArray[np.float64]:
        if self._source_type == "polar_variable":
            return np.array(self._source.cl).flatten()
        elif self._source_type == "aerodynamic_polar_data":
            return np.array(self._source.lift_coefficient).flatten()
        elif self._source_type == "dict":
            return np.array(self._source.get("cl", [])).flatten()
        return np.array([])

    @property
    def drag_coefficient(self) -> NDArray[np.float64]:
        if self._source_type == "polar_variable":
            return np.array(self._source.cd).flatten()
        elif self._source_type == "aerodynamic_polar_data":
            return np.array(self._source.drag_coefficient).flatten()
        elif self._source_type == "dict":
            return np.array(self._source.get("cd", [])).flatten()
        return np.array([])


# Breguet
def calculate_fuel_fraction_endurance_maneuvering_fuelcell(
    m_start,
    t,
    T_max,
    V,
    eta_prop,
    eta_fc,
    U_thermo,
    mue,
    retainH2O,
):
    """Parameters
    m_start    start mass of flight phase                 [kg]    [double]    [1 x n] or [n x 1]
    t          flight endurance                           [s]     [double]    [1 x n] or [n x 1]
    T_max      maximum thrust                             [N]     [double]    [1 x n] or [n x 1]
    V          flight speed                               [m/s]   [double]    [1 x n] or [n x 1]
    eta_prop   efficiency of powertrain until fuelcell    [-]     [double]    [1 x n] or [n x 1]
    eta_fc     efficiency of fuelcell (U_cell/U_thermo)   [-]     [double]    [1 x n] or [n x 1]
    U_thermo   theoretical voltage of fuelcell            [V]     [double]    [1 x n] or [n x 1]
    mue		   factor to account for BoP power            [-]     [double]    [1 x n] or [n x 1]
    retainH2O  flag if water produced is stored on board  [-]     [logical]   [1 x n] or [n x 1]

    Returns
    -------
    f_H2       hydrogen fraction of fuel cell aircraft    [-]     [double]    [1 x n] or [n x 1]
    f_H2O      water fraction of fuel cell aircraft       [-]     [double]    [1 x n] or [n x 1]

    Description: This function calculates the flight endurance of a fuel cell
                 aircraft for the maneuvering phase.

    Limitations: -

    Assumptions: Fuel utilization coefficient of 0.95 (Larminie & Dicks,
                 Fuel Cell Systems Explained, 2nd Ed., 2003, p.35)
                 Maximum thrust

    Example: f_H2 = calculate_fuel_fraction_endurance_maneuvering_fuelcell(70000, 8565, 120000, 250, 0.8, 0.6, 1.2, 0.3, false)
             f_H2, f_H2O = calculate_fuel_fraction_endurance_maneuvering_fuelcell(70000, 8565, 135000, 250, 0.85, 0.65, 1.1, 0.4, true)

    """
    # Calculation
    K = (
        -1.05 * 10**-8 / 0.95
    )  # from Larminie & Dicks, Fuel Cell Systems Explained, 2nd Ed., 2003, App. 2.4
    f_H2 = (
        m_start + ((K * (1 + mue) * V * T_max * t) / (eta_prop * eta_fc * U_thermo))
    ) / m_start

    if retainH2O:
        K = (
            9.34 * 10**-8
        )  # from Larminie & Dicks, Fuel Cell Systems Explained, 2nd Ed., 2003, App. 2.5
        f_H2O = (
            m_start + ((K * (1 + mue) * V * T_max * t) / (eta_prop * eta_fc * U_thermo))
        ) / m_start
    else:
        f_H2O = 1

    return (f_H2, f_H2O)


def calculate_fuel_fraction_range_breguet_fc1(
    R,
    SFC,
    c_L,
    c_D,
    V,
    n_v,
):  # input: (range,specific fuel consumption,lift coefficient,drag coefficient,airspeed,power dependency regarding airspeed)
    """Parameters
    R           flight range                        [m]     [double]    [1 x n] or [n x 1]
    SFC         specific fuel consumption           [kg/Ns] [double]    [1 x n] or [n x 1]
                or     							    [kg/Ws] [double]    [1 x n] or [n x 1]
    c_L         lift coefficient                    [-]     [double]    [1 x n] or [n x 1]
    c_D         drag coefficient                    [-]     [double]    [1 x n] or [n x 1]
    V           airspeed                            [m/s]   [double]    [1 x n] or [n x 1]
    n_v         power dependency regarding airspeed [-]     [double]    [1 x n] or [n x 1]

    Returns
    -------
    ff         fuel fraction of ESM                 [-]     [double]    [1 x n] or [n x 1]
    Description:  This function calculates the fuel fraction defined by
                flight range according to Breguet Flight Condition 1.
    Limitations:  -
    Assumptions:  -
    Example:      ff = calculate_fuel_fraction_range_breguet_fc1(1000000,1.2*10^-5,0.6,0.15,90,0)

    """
    # DEFINES
    g = 9.81  # earth gravity [m/s^2]

    # Calculation
    ff = math.exp((-1 * R) / ((V ** (n_v + 1) / (SFC * g)) * (c_L / c_D)))

    return ff


def calculate_fuel_fraction_endurance_maneuvering(
    m_start,
    t,
    SFC,
    T_max,
    V,
    n_v,
):  # input: (start mass,time,specific fuel consumption,maximum thrust,airspeed,power dependency regarding airspeed)
    """Parameters
    m_start     start mass of maneuvering           [kg]    [double]    [1 x n] or [n x 1]
    t           flight endurance                    [s]     [double]    [1 x n] or [n x 1]
    SFC         specific fuel consumption           [kg/Ns] [double]    [1 x n] or [n x 1]
                or     							   [kg/Ws] [double]    [1 x n] or [n x 1]
    T_max       maximum thrust                      [N]     [double]    [1 x n] or [n x 1]
    V           airspeed                            [m/s]   [double]    [1 x n] or [n x 1]
    n_v         power dependency regarding airspeed [-]     [double]    [1 x n] or [n x 1]

    Returns
    -------
    ff         fuel fraction                       [-]     [double]    [1 x n] or [n x 1]

    Description:  This function calculates the fuel fraction defined by
                flight endurance of a maneuvering/combat phase.

    Limitations:  -

    Assumptions:  -

    Example:    ff = calculate_fuel_fraction_endurance_maneuvering(8000,1200,1.2*10^-5,15000,100,0)
                ff = calculate_fuel_fraction_endurance_maneuvering(8000,1200,1.1*10^-7,15000,100,-1)

    """
    # Calculation
    ff = (-1 * SFC * T_max * t * V**-n_v + m_start) / m_start

    return ff


def calculate_fuel_fraction_endurance_breguet_fc1_fuelcell(
    t,
    c_L,
    c_D,
    V,
    eta_prop,
    eta_fc,
    U_thermo,
    mue,
    retainH2O,
):
    """Parameters
    t           flight endurance							[s]     [double]    [1 x n] or [n x 1]
    c_L         lift coefficient							[-]     [double]    [1 x n] or [n x 1]
    c_D         drag coefficient							[-]     [double]    [1 x n] or [n x 1]
    V           flight speed								[m/s]   [double]    [1 x n] or [n x 1]
    eta_prop    efficiency of powertrain until fuelcell   [-]     [double]    [1 x n] or [n x 1]
    eta_fc      efficiency of fuelcell (U_cell/U_thermo)  [-]     [double]    [1 x n] or [n x 1]
    U_thermo    theoretical voltage of fuelcell			[V]     [double]    [1 x n] or [n x 1]
    mue		  factor to account for BoP power			[-]     [double]    [1 x n] or [n x 1]
    retainH2O   flag if water produced is stored on board	[-]     [logical]   [1 x n] or [n x 1]

    Returns
    -------
    f_H2       hydrogen fraction of fuel cell aircraft  	[-]     [double]    [1 x n] or [n x 1]
    f_H2O      water fraction of fuel cell aircraft     	[-]     [double]    [1 x n] or [n x 1]

    Description:  This function calculates the hydrogen fraction defined by
                flight endurance of a fuel cell aircraft according to Breguet
                    Flight Condition 1.

    Limitations:  -

    Assumptions:  Fuel utilization coefficient of 0.95 (Larminie & Dicks,
                    Fuel Cell Systems Explained, 2nd Ed., 2003, p.35)

    Example:      [f_H2,f_H2O] = calculate_fuel_fraction_endurance_breguet_fc1_fuelcell(8695,0.6,0.018,230,0.85,0.65,1.1,0.4,true)
                    f_H2 = calculate_fuel_fraction_endurance_breguet_fc1_fuelcell(8695,0.6,0.018,230,0.85,0.65,1.1,0.4,false)

    """
    # DEFINES
    g = 9.81  # earth gravity [m/s^2]

    K = (
        -1.05 * 10**-8 / 0.95
    )  # from Larminie & Dicks, Fuel Cell Systems Explained, 2nd Ed., 2003, App. 2.4

    # Calculation
    f_H2 = math.exp(
        (t * V * K * (1 + mue) * g) / (eta_prop * eta_fc * U_thermo * c_L / c_D),
    )

    if retainH2O:
        K = (
            9.34 * 10**-8
        )  # from Larminie & Dicks, Fuel Cell Systems Explained, 2nd Ed., 2003, App. 2.5
        f_H2O = math.exp(
            (t * V * K * (1 + mue) * g) / (eta_prop * eta_fc * U_thermo * c_L / c_D),
        )
    else:
        f_H2O = 1

    return (f_H2, f_H2O)


def calculate_fuel_fraction_endurance_breguet_fc1(
    t,
    SFC,
    c_L,
    c_D,
    V,
    n_v,
):  # (endurance,specific fuel consumption,lift coefficient,drag coefficient,airspeed,power dependency regarding airspeed)
    """Parameters
    t           flight endurance                    [s]     [double]    [1 x n] or [n x 1]
    SFC         specific fuel consumption           [kg/Ns] [double]    [1 x n] or [n x 1]
                or     							  [kg/Ws] [double]    [1 x n] or [n x 1]
    c_L         lift coefficient                    [-]     [double]    [1 x n] or [n x 1]
    c_D         drag coefficient                    [-]     [double]    [1 x n] or [n x 1]
    V           airspeed                            [m/s]   [double]    [1 x n] or [n x 1]
    n_v         power dependency regarding airspeed [-]     [double]    [1 x n] or [n x 1]

    Returns
    -------
    ff         fuel fraction of ESM                [-]     [double]    [1 x n] or [n x 1]

    Description:  This function calculates the fuel fraction defined by
                flight endurance according to Breguet Flight Condition 1.

    Limitations:  -

    Assumptions:  -

    Example:    ff = calculate_fuel_fraction_endurance_breguet_fc1(3600,1.2*10^-5,0.6,0.15,90,0)
                ff = calculate_fuel_fraction_endurance_breguet_fc1(3600,1.1*10^-7,0.6,0.15,90,-1)

    """
    # DEFINES
    g = 9.81  # earth gravity [m/s^2]
    # Calculation
    ff = math.exp((-1 * t) / ((V**n_v / (SFC * g)) * (c_L / c_D)))

    return ff


def calculate_battery_mass_range(
    m_TOM,
    R,
    Easterisk,
    eta,
    c_L,
    c_D,
):  # input: (take-off mass,range,specific energy,overall efficiency,lift coefficient,drag coefficient)
    """Parameters
    m_TOM       take-off mass                       [kg]    [double]    [1 x n] or [n x 1]
    R           flight range                        [m]     [double]    [1 x n] or [n x 1]
    Easterisk   specific energy of battery          [Ws/kg] [double]    [1 x n] or [n x 1]
    eta         overall efficiency of the electric
                        powertrain						  [-]     [double]    [1 x n] or [n x 1]
    c_L         lift coefficient                    [-]     [double]    [1 x n] or [n x 1]
    c_D         drag coefficient                    [-]     [double]    [1 x n] or [n x 1]

    Returns
    -------
    m_bat      battery mass                        [kg]    [double]    [1 x n] or [n x 1]

    Description:  This function calculates the battery mass according to a
                defined fight range for an electric cruise flight according to
                Hepperle.

    Limitations:  -

    Assumptions:  -

    Example:      m_bat = calculate_battery_mass_range(16200,100000,720000,0.7,16)
                m_bat = calculate_battery_mass_range(16200,100000,720000,0.7,0.8,0.05)

    """
    # DEFINES
    g = 9.81  # earth gravity [m/s^2]
    # Calculation
    c_L_c_D = c_L / c_D  # lift-to-drag ratio
    m_bat = R * (1 / c_L_c_D) * ((m_TOM * g) / (Easterisk * eta))  # battery mass

    return m_bat


def calculate_battery_mass_endurance(
    m_TOM,
    t,
    V,
    Easterisk,
    eta,
    c_L,
    c_D,
):  # input: (take-off mass,endurance,airspeed,specific energy,overall efficiency,lift coefficient,drag coefficient)
    """Parameters
    m_TOM       take-off mass                       [kg]    [double]    [1 x n] or [n x 1]
    t           flight endurance                    [s]     [double]    [1 x n] or [n x 1]
    V           airspeed                            [m/s]   [double]    [1 x n] or [n x 1]
    Easterisk   specific energy of battery          [Ws/kg] [double]    [1 x n] or [n x 1]
    eta         overall efficiency of the electric
                powertrain						  [-]     [double]    [1 x n] or [n x 1]
    c_L         lift coefficient                [-]     [double]    [1 x n] or [n x 1]
    c_D         drag coefficient                    [-]     [double]    [1 x n] or [n x 1]

    Returns
    -------
    m_Bat      battery mass                        [kg]    [double]    [1 x n] or [n x 1]

    Description:  This function calculates the battery mass according to a
                defined fight endurance for an electric cruise flight
                according to Hepperle.

    Limitations:  -

    Assumptions:  -

    Example:    m_Bat = calculate_battery_mass_endurance(16200,3600,90,720000,0.7,16)
                m_Bat = calculate_battery_mass_endurance(16200,3600,90,720000,0.7,0.8,0.05)

    """
    # DEFINES
    g = 9.81  # earth gravity [m/s^2]
    # Calculation
    c_L_c_D = c_L / c_D  # lift-to-drag ratio

    m_Bat = t * V * (1 / c_L_c_D) * ((m_TOM * g) / (Easterisk * eta))  # battery mass

    return m_Bat


def calculate_fuel_fraction_range_breguet_fc1_fuelcell(
    R,
    c_L,
    c_D,
    eta_prop,
    eta_fc,
    U_thermo,
    mue,
    retainH2O,
):
    """Parameters
        R           flight range								[m]     [double]    [1 x n] or [n x 1]
        c_L         lift coefficient							[-]     [double]    [1 x n] or [n x 1]
        c_D         drag coefficient							[-]     [double]    [1 x n] or [n x 1]
        eta_prop    efficiency of powertrain until fuelcell   [-]     [double]    [1 x n] or [n x 1]
        eta_fc      efficiency of fuelcell (U_cell/U_thermo)  [-]     [double]    [1 x n] or [n x 1]
        U_thermo    theoretical voltage of fuelcell			[V]     [double]    [1 x n] or [n x 1]
        mue		  factor to account for BoP power			[-]     [double]    [1 x n] or [n x 1]
        retainH2O   flag if water produced is stored on board	[-]     [logical]   [1 x n] or [n x 1]

    Returns
    -------
        f_H2       hydrogen fraction of fuel cell aircraft  	[-]     [double]    [1 x n] or [n x 1]
        f_H2O      water fraction of fuel cell aircraft     	[-]     [double]    [1 x n] or [n x 1]

        Description:  This function calculates the hydrogen fraction defined by
                                flight range of a fuel cell aircraft according to Breguet
                                        Flight Condition 1.

        Limitations:  -

        Assumptions:  Fuel utilization coefficient of 0.95 (Larminie & Dicks,
                                        Fuel Cell Systems Explained, 2nd Ed., 2003, p.35)

        Example:      [f_H2,f_H2O] = calculate_fuel_fraction_range_breguet_fc1_fuelcell(2*10^6,0.6,0.018,0.85,0.65,1.1,0.4,true)
                                        f_H2 = calculate_fuel_fraction_range_breguet_fc1_fuelcell(2*10^6,0.6,0.018,0.85,0.65,1.1,0.4,false)

    """
    # DEFINES
    g = 9.81  # earth gravity [m/s^2]

    K = (
        -1.05 * 10**-8 / 0.95
    )  # from Larminie & Dicks, Fuel Cell Systems Explained, 2nd Ed., 2003, App. 2.4

    # Calculation
    f_H2 = math.exp(
        (R * K * (1 + mue) * g) / (eta_prop * eta_fc * U_thermo * c_L / c_D),
    )

    if retainH2O:
        K = (
            9.34 * 10**-8
        )  # from Larminie & Dicks, Fuel Cell Systems Explained, 2nd Ed., 2003, App. 2.5
        f_H2O = math.exp(
            (R * K * (1 + mue) * g) / (eta_prop * eta_fc * U_thermo * c_L / c_D),
        )
    else:
        f_H2O = 1
    return (f_H2, f_H2O)


# VTOL
def calculate_fuel_mass_hover_endurance(
    mass,
    thrustSafetyFactor,
    density,
    rotorRadius,
    powerTrainEfficiency,
    requiredTime,
    SFC_hover,
):
    ########################## LIMITATION ##################################################################
    # Only for short hover times since no mass change due to fuel consumption is taken into account!
    # Equal distribution of the thrust among all rotors is assumed during the hover!
    ########################################################################################################

    # Compute required thrust
    totalThrust = 9.81 * mass  # [N]

    # Apply safety factor
    totalThrust = thrustSafetyFactor * totalThrust

    # Compute thrust per rotor
    thrustPerRotor = totalThrust / len(rotorRadius)  # [N]

    # Compute induced velocity per rotor
    inducedVelocityPerRotor = np.sqrt(
        thrustPerRotor / (2 * density * np.pi * rotorRadius**2),
    )  # [m/s]

    # Compute ideal power per rotor
    idealPowerPerRotor = thrustPerRotor * inducedVelocityPerRotor  # [W]

    # Compute required fuel consumption
    requiredFuelMass = (
        sum(idealPowerPerRotor) / powerTrainEfficiency * SFC_hover * requiredTime
    )  # [kg]

    return requiredFuelMass


def calculate_battery_mass_hover(
    mass,
    thrustSafetyFactor,
    density,
    rotorRadius,
    powerTrainEfficiency,
    requiredTime,
    Easterisk,
):
    ########################## LIMITATION ##################################################################
    # Only for short hover times since no mass change due to fuel consumption is taken into account!
    # Equal distribution of the thrust among all rotors is assumed during the hover!
    ########################################################################################################

    # Compute required thrust
    totalThrust = 9.81 * mass  # [N]

    # Apply safety factor
    totalThrust = thrustSafetyFactor * totalThrust

    # Compute thrust per rotor
    thrustPerRotor = totalThrust / len(rotorRadius)  # [N]

    # Compute induced velocity per rotor
    inducedVelocityPerRotor = np.sqrt(
        thrustPerRotor / (2 * density * np.pi * rotorRadius**2),
    )  # [m/s]

    # Compute ideal power per rotor
    idealPowerPerRotor = thrustPerRotor * inducedVelocityPerRotor  # [W]

    # Compute required battery power
    requiredBatteryPower = sum(idealPowerPerRotor) / powerTrainEfficiency  # [W]

    requiredBatteryEnergy = requiredBatteryPower * requiredTime  # [J], required energy

    requiredBatteryMass = requiredBatteryEnergy / Easterisk  # [kg]

    return requiredBatteryMass


# Roskam
def calculate_mission_roskam_customized(
    mission,
    energy_fraction,
    propellant_type,
    S_ref,
    n_v,
    c_L_array,
    c_D_array,
    alpha_array,
    fuelReserve,
    batteryReserve,
    **kwargs,
):
    """Parameters
    mission               mission containing all mission segments [-]         [cell]      [n x 1]
    energy_fraction       dictionary containing energy fractions according to Roskam with 6 keys:
                                            engineStart,taxi,takeOff,climb, descent, landing		[-]         [struct]    [1 x 1]
    S_ref                 reference area for the configuration aerodynamics      [m^2]       [double]    [1 x 1]
    n_v                   power dependency regarding airspeed                     [-]         [double]    [1 x 1]
    c_L_array                   lift coefficient array								   	[-]         [double]    [n x 1]
    c_D_array                   drag coefficient array								   	[-]         [double]    [n x 1]
    alpha_array         range of angles of attack assoicated with c_L_array and c_D_array [deg]
    SFC_cruise		    cruise specific fuel consumption						[kg/Ns]     [double]    [1 x 1]
                                                                                                                                           or      	[kg/Ws]     [double]    [1 x 1]
    SFC_hover		    hover specific fuel consumption						[kg/Ns]     [double]    [1 x 1]
                                                                                                                                           or      	[kg/Ws]     [double]    [1 x 1]
    SFC_loiter		    loiter specific fuel consumption						[kg/Ns]     [double]    [1 x 1]
                                                                                                                                           or      	[kg/Ws]     [double]    [1 x 1]
    SFC_maneuvering       maneuvering specific fuel consumption                   [kg/Ns]     [double]    [1 x 1]
                                                                                                                                           or      	[kg/Ws]     [double]    [1 x 1]
    T_maneuvering         max available thrust for maneuvering                    [N]         [double]    [1 x 1]
    eta_prop1_cruise      overall efficiency of powertrain 1					   	[-]         [double]    [1 x 1]
    Easterisk             specific energy of battery (optional)                   [Ws/kg]     [double]    [1 x 1]
    eta_prop2_cruise      overall efficiency of powertrain 2 during
                                            cruise (optional)									   	[-]         [double]    [1 x 1]
    eta_prop2_loiter      overall efficiency of powertrain 2 during
                                            loiter (optional)									   	[-]         [double]    [1 x 1]
    eta_prop2_maneuvering overall efficiency of powertrain 2 during
                                            maneuvering (optional)								   	[-]         [double]    [1 x 1]
    eta_fuelcell_voltage  efficiency of fuelcell (U_cell/U_thermo)				[-]         [double]    [1 x 1]
    eta_fuelcell_LHV      efficiency of fuelcell (P_out/(LHV*m_dot_H2))			[-]         [double]    [1 x 1]
    U_thermo			    theoretical voltage of fuelcell						   	[V]         [double]    [1 x 1]
    mue				    factor to account for BoP power						   	[-]         [double]    [1 x 1]
    retainH2O			    flag if produced H2O of fuel cell is retained on board 	[-]         [logical]   [1 x 1]

    Returns
    -------
    energy1MassTotal     mass of energy 1 (e.g. kerosene) of complete mission	[kg]        [double]    [1 x 1]
    energy2MassTotal     mass of energy 2 (e.g. battery) of complete mission		[kg]        [double]    [1 x 1]
    mission              mission containing all mission segments [-]         [cell]      [n x 1]
    fuelReserve          fuel reserve as a portion of the trip fuel            [double]    [1 x 1]     [%]
    batteryReserve       battery reserve as a portion of the total battery mass            [double]    [1 x 1]     [%]

    Description:  This function calculates the mass fraction and also battery
                  weight for a defined mission using a previoulsy calculated
                                 aerodynamic polar. The mission segments can be
                  calculated separately according to a defined degree of
                  energy hybridization (electric energy divided by total energy).
                  This can range from:
                  DoH = 0:        fuel burn (0% electric energy)
                  0 <= DoH <= 1:  hybrid
                  DoH = 1:        fully electric (100% electric energy)
                  The mission segments have to be according to the definitions
                  of Roskam.
                                 This function has a different eta for cruise, loiter and maneuvering.

    Limitations:  Valid for missions defined according to Roskam and calculated
                  with Breguet flight condition 1 (constant airspeed and lift
                                 coefficient).
                  ########################## LIMITATION ##################################################################
                  # If hover with kerosene is used: only suited for short hover times since no mass change due to fuel consumption is taken into account!
                  ########################################################################################################

    """
    # Analyze Input Data
    mission_segments = mission.mission_segments
    n_segment = len(mission_segments)  # number of mission segments

    # Process segments - set defaults for missing attributes
    for seg in mission_segments:
        if not hasattr(seg, "hybridization") or seg.hybridization is None:
            seg.hybridization = kwargs.get("hybridization_default", 0.0)
        if not hasattr(seg, "duration") or seg.duration == 0.0:
            if seg.airspeed_start > 0 and hasattr(seg, "range"):
                seg.duration = seg.range / seg.airspeed_start
        if not hasattr(seg, "endurance") or seg.endurance == 0.0:
            if seg.airspeed_start > 0 and hasattr(seg, "range"):
                seg.endurance = seg.range / seg.airspeed_start

        # Set default attributes that Roskam expects but Segment doesn't have
        if not hasattr(seg, "usedFuel"):
            seg.usedFuel = 0.0
        if not hasattr(seg, "usedBatteryEnergy"):
            seg.usedBatteryEnergy = 0.0
        if not hasattr(seg, "fuel_used"):
            seg.fuel_used = 0.0
        if not hasattr(seg, "battery_mass_used"):
            seg.battery_mass_used = 0.0
        if not hasattr(seg, "lift_coefficient"):
            seg.lift_coefficient = 0.0
        if not hasattr(seg, "lift_drag_ratio"):
            seg.lift_drag_ratio = 0.0

    if "thrustSafetyFactor" in kwargs:
        thrustSafetyFactor = kwargs["thrustSafetyFactor"]
    if "rotorRadius" in kwargs:
        rotorRadius = kwargs["rotorRadius"]
    if "eta_prop1_hover" in kwargs:
        eta_prop1_hover = kwargs["eta_prop1_hover"]
    if "eta_prop2_hover" in kwargs:
        eta_prop2_hover = kwargs["eta_prop2_hover"]
    if "SFC_hover" in kwargs:
        SFC_hover = kwargs["SFC_hover"]
    if "SFC_cruise" in kwargs:
        SFC_cruise = kwargs["SFC_cruise"]
    if "SFC_loiter" in kwargs:
        SFC_loiter = kwargs["SFC_loiter"]
    if "SFC_maneuvering" in kwargs:
        SFC_maneuvering = kwargs["SFC_maneuvering"]
    if "T_maneuvering" in kwargs:
        T_maneuvering = kwargs["T_maneuvering"]
    if "eta_prop1_cruise" in kwargs:
        eta_prop1_cruise = kwargs["eta_prop1_cruise"]
    if "Easterisk" in kwargs:
        Easterisk = kwargs["Easterisk"]
    if "eta_prop2_cruise" in kwargs:
        eta_prop2_cruise = kwargs["eta_prop2_cruise"]
    if "eta_prop2_loiter" in kwargs:
        eta_prop2_loiter = kwargs["eta_prop2_loiter"]
    if "eta_prop2_maneuvering" in kwargs:
        eta_prop2_maneuvering = kwargs["eta_prop2_maneuvering"]
    if "fuelcell" in propellant_type:
        eta_fuelcell_voltage = kwargs["eta_fuelcell_voltage"]
        eta_fuelcell_LHV = kwargs["eta_fuelcell_LHV"]
        U_thermo = kwargs["U_thermo"]
        mue = kwargs["mue"]
        retainH2O = kwargs["retainH2O"]

    # DEFAULTS - Initialize variables to prevent UnboundLocalError
    g = 9.81  # earth gravity [m/s^2]
    SFC_cruise = 0.00001667  # Default for kerosene (kg/Ns)
    SFC_hover = 0.00001667
    SFC_loiter = 0.00001667
    SFC_maneuvering = 0.00001667
    eta_prop1_cruise = 0.3
    eta_prop2_cruise = 0.3
    eta_prop2_loiter = 0.3
    eta_prop2_maneuvering = 0.3
    Easterisk = 1.0
    eta_fuelcell_voltage = 0.6
    eta_fuelcell_LHV = 1.0
    U_thermo = 1.0
    mue = 1.0
    retainH2O = False
    thrustSafetyFactor = 1.0
    rotorRadius = 1.0
    eta_prop1_hover = 0.3
    eta_prop2_hover = 0.3
    T_maneuvering = 1000.0

    LHV_kerosene = 43.1 * 10**6  # [Ws/kg] lower heating value kerosene
    LHV_hydrogen = 120 * 10**6  # [Ws/kg] lower heating value hydrogen
    eta_kerosene = 0.3  # [-] approximate overall efficiency of engines with EIS 1980 (about state of technology on which Roskams Fuel Fractions are based)

    if propellant_type == "kerosene":
        LHV1 = LHV_kerosene
        mass_change_type1 = 1  # change (lighter)
        LHV2 = 1
        mass_change_type2 = 0  # same
    elif propellant_type == "hydrogen":
        LHV1 = LHV_hydrogen
        mass_change_type1 = 1  # change (lighter)
        LHV2 = 1
        mass_change_type2 = 0  # same
    elif propellant_type == "battery":
        LHV1 = Easterisk
        mass_change_type1 = 0  # same
        LHV2 = 1
        mass_change_type2 = 0  # same
    elif propellant_type == "fuelcell":
        LHV1 = LHV_hydrogen
        mass_change_type1 = 1  # change
        LHV2 = 1
        mass_change_type2 = 0  # same
    elif propellant_type == "kerosene-hydrogen":
        LHV1 = LHV_kerosene
        mass_change_type1 = 1  # change (lighter)
        LHV2 = LHV_hydrogen
        mass_change_type2 = 1  # change (lighter)
    elif propellant_type == "kerosene-battery":
        LHV1 = LHV_kerosene
        mass_change_type1 = 1  # change (lighter)
        LHV2 = Easterisk
        mass_change_type2 = 0  # same
    elif propellant_type == "kerosene-fuelcell":
        LHV1 = LHV_kerosene
        mass_change_type1 = 1  # change (lighter)
        LHV2 = LHV_hydrogen
        mass_change_type2 = 1  # change
    elif propellant_type == "hydrogen-battery":
        LHV1 = LHV_hydrogen
        mass_change_type1 = 1  # change (lighter)
        LHV2 = Easterisk
        mass_change_type2 = 0  # same
    elif propellant_type == "hydrogen-fuelcell":
        LHV1 = LHV_hydrogen
        mass_change_type1 = 1  # change (lighter)
        LHV2 = LHV_hydrogen
        mass_change_type2 = 1  # change
    elif propellant_type == "fuelcell-battery":
        LHV1 = LHV_hydrogen
        mass_change_type1 = 1  # change
        LHV2 = Easterisk
        mass_change_type2 = 0  # same

    # Mission calculation
    # Initialize energy fraction arrays
    energy_fraction1 = np.ones(n_segment)
    energy_fraction2 = np.ones(n_segment)
    energy_mass1_mission_segment = np.zeros(n_segment)
    energy_mass2_mission_segment = np.zeros(n_segment)

    for ii in range(n_segment):
        segment_type = mission_segments[ii].type
        if segment_type in [
            "engineStart",
            "taxi",
            "takeOff",
            "climb",
            "descent",
            "landing",
        ]:
            if ii != 0:
                mass_start = mission_segments[ii - 1].mass_end
            else:
                mass_start = mission_segments[ii].mass_start

            mission_segments[ii].mass_start = mass_start
            energy_fraction1[ii] = 1 - (
                (1 - energy_fraction[segment_type])
                * (LHV_kerosene * eta_kerosene)
                / (LHV1 * eta_prop1_cruise)
                * (1 - mission_segments[ii].hybridization)
            )
            energy_fraction2[ii] = 1 - (
                (1 - energy_fraction[segment_type])
                * (LHV_kerosene * eta_kerosene)
                / (LHV1 * eta_prop1_cruise)
                * (LHV1 * eta_prop1_cruise)
                / (LHV2 * eta_prop2_cruise)
                * mission_segments[ii].hybridization
            )
            mass_energy1 = mass_start * (1 - energy_fraction1[ii])
            mass_energy2 = mass_start * (1 - energy_fraction2[ii])
            energy_mass1_mission_segment[ii] = mass_energy1
            energy_mass2_mission_segment[ii] = mass_energy2
            mission_segments[ii].usedFuel = mass_energy1
            mission_segments[ii].usedBatteryEnergy = mass_energy2

            if "fuelcell" in propellant_type:
                if retainH2O and propellant_type.startswith("fuelcell"):
                    mass_H2O = (
                        8.45 * mass_energy1
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                elif retainH2O and propellant_type.endswith("fuelcell"):
                    mass_H2O = (
                        8.45 * mass_energy2
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O = 0
            else:
                mass_H2O = 0

            mass_end = (
                mass_start
                - mass_energy1 * mass_change_type1
                - mass_energy2 * mass_change_type2
                + mass_H2O
            )
            mission_segments[ii].mass_end = mass_end
            if ii != 0:
                mission_segments[ii].altitude_start = mission_segments[
                    ii - 1
                ].altitude_end

        elif segment_type == "hover":
            # Only kerosene and battery are supported for this mission segment
            if (
                propellant_type.endswith("kerosene") == False
                and propellant_type.endswith("battery") == False
            ):
                raise ValueError(
                    "So far, only kerosene and battery are supported for this mission segment",
                )

            if ii != 0:
                mass_start = mission_segments[ii - 1].mass_end
            else:
                mass_start = mission_segments[ii].mass_start

            endurance_energy1 = mission_segments[ii].endurance * (
                1 - mission_segments[ii].hybridization
            )
            endurance_energy2 = (
                mission_segments[ii].endurance * mission_segments[ii].hybridization
            )

            altitude_start = mission_segments[ii].altitude_start

            # Compute density in current altitude
            atmosphere = Atmosphere(altitude_start)
            rho_start = atmosphere.density

            # Energy1
            if propellant_type.startswith("kerosene"):
                energy_mass1_mission_segment[ii] = calculate_fuel_mass_hover_endurance(
                    mass_start,
                    thrustSafetyFactor,
                    rho_start,
                    rotorRadius,
                    eta_prop1_hover,
                    endurance_energy1,
                    SFC_hover,
                )
                mass_energy1 = energy_mass1_mission_segment[ii]
            elif propellant_type.startswith(
                "battery",
            ):  # battery is only first, if it's battery-only, so battery mass can be calculated with massStart only as the mass wouldn't change
                energy_mass1_mission_segment[ii] = calculate_battery_mass_hover(
                    mass_start,
                    thrustSafetyFactor,
                    rho_start,
                    rotorRadius,
                    eta_prop1_hover,
                    endurance_energy1,
                    Easterisk,
                )
                mass_energy1 = energy_mass1_mission_segment[ii]
                energy_fraction1[ii] = 1 - mass_energy1 / mass_start

            mass_end1 = mass_start - mass_energy1 * mass_change_type1

            # Energy2
            # in case no hybrid aircraft is calculated, energyFraction2 will return 1, because rangeEnergy2 = 0. However, calculation still needed to proceed with script
            if propellant_type.endswith("kerosene"):
                energy_mass2_mission_segment[ii] = calculate_fuel_mass_hover_endurance(
                    mass_start,
                    thrustSafetyFactor,
                    rho_start,
                    rotorRadius,
                    eta_prop2_hover,
                    endurance_energy2,
                    SFC_hover,
                )
                mass_energy2 = energy_mass2_mission_segment[ii]
            elif propellant_type.endswith("battery"):
                energy_mass2_mission_segment[ii] = calculate_battery_mass_hover(
                    mass_start,
                    thrustSafetyFactor,
                    rho_start,
                    rotorRadius,
                    eta_prop2_hover,
                    endurance_energy2,
                    Easterisk,
                )
                mass_energy2 = energy_mass2_mission_segment[ii]
                energy_fraction2[ii] = 1 - mass_energy2 / ((mass_start + mass_end1) / 2)

            mass_end = (
                mass_start
                - mass_energy1 * mass_change_type1
                - mass_energy2 * mass_change_type2
            )

            # Save results
            mission_segments[ii].lift_coefficient = 0
            mission_segments[ii].lift_drag_ratio = 0
            mission_segments[ii].mass_start = mass_start  # [kg]
            mission_segments[ii].mass_end = mass_end  # [kg]
            mission_segments[ii].fuel_used = mass_energy1  # [kg]
            mission_segments[ii].battery_mass_used = mass_energy2  # [kg]
            mission_segments[ii].airspeed_end = mission_segments[
                ii
            ].airspeed_start  # no airspeed change during hover
            mission_segments[
                ii
            ].altitude_end = altitude_start  # [m] no altitude change during hover
            mission_segments[ii].range = (
                mission_segments[ii].endurance * mission_segments[ii].airspeed_start
            )  # [m]
            mission_segments[ii].angle_of_attack = 0

        elif segment_type == "cruise":
            if ii != 0:
                mass_start = mission_segments[ii - 1].mass_end
            else:
                mass_start = mission_segments[ii].mass_start

            range_energy1 = mission_segments[ii].range * (
                1 - mission_segments[ii].hybridization
            )
            range_energy2 = (
                mission_segments[ii].range * mission_segments[ii].hybridization
            )

            altitude_start = mission_segments[ii].altitude_start  # [m]

            # Compute density in current altitude
            atmosphere = Atmosphere(altitude_start)
            rho_start = atmosphere.density

            c_L_cruise = (2 * mass_start * g) / (
                rho_start * mission_segments[ii].airspeed_start ** 2 * S_ref
            )  # Breguet FC1 = constant cL
            # if c_L_cruise > max(c_L_array) or np.isnan(c_L_cruise):
            #
            #    # in case the lift coefficient is higher than possible, do not fix to a value but keep some dependency to
            #    # enable gradient computation
            #    lift_to_drag_ratio_all_mission_segments = {"lift_to_drag_ratio_" + segment.name + "_segment_" + str(index): 0.1 for index,segment in enumerate(mission_segments, start=1)}
            #    angle_of_attack_all_mission_segments = {"angle_of_attack_" + segment.name + "_segment_" + str(index): c_L_cruise + 10 for index,segment in enumerate(mission_segments, start=1)}
            #
            #    return mass_start,mass_start,lift_to_drag_ratio_all_mission_segments,angle_of_attack_all_mission_segments
            #
            #    #raise ValueError('the available lift is not sufficient to lift the configuration!')
            # else:
            c_D_cruise = np.interp(
                c_L_cruise,
                c_L_array,
                c_D_array,
            )  # careful! constant extrapolation if out of range! Check c_L afterwards!
            alpha_cruise = np.interp(
                c_L_cruise,
                c_L_array,
                alpha_array,
            )  # careful! constant extrapolation if out of range! Check alpha afterwards!

            # Energy1
            if propellant_type.startswith("kerosene") or propellant_type.startswith(
                "hydrogen",
            ):
                energy_fraction1[ii] = calculate_fuel_fraction_range_breguet_fc1(
                    range_energy1,
                    SFC_cruise,
                    c_L_cruise,
                    c_D_cruise,
                    mission_segments[ii].airspeed_start,
                    n_v,
                )
                mass_energy1 = mass_start * (1 - energy_fraction1[ii])
                energy_mass1_mission_segment[ii] = mass_energy1
                mass_H2O_1 = 0
            elif propellant_type.startswith("fuelcell"):
                eta_prop = eta_prop1_cruise / eta_fuelcell_LHV
                energy_fraction1[ii] = (
                    calculate_fuel_fraction_range_breguet_fc1_fuelcell(
                        range_energy1,
                        c_L_cruise,
                        c_D_cruise,
                        eta_prop,
                        eta_fuelcell_voltage,
                        U_thermo,
                        mue,
                        retainH2O,
                    )
                )
                mass_energy1 = mass_start * (1 - energy_fraction1[ii])
                energy_mass1_mission_segment[ii] = mass_energy1
                if retainH2O:
                    mass_H2O_1 = (
                        8.45 * mass_energy1
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O_1 = 0
            elif propellant_type.startswith(
                "battery",
            ):  # battery is only first, if it's battery-only, so battery mass can be calculated with massStart only as the mass wouldn't change
                energy_mass1_mission_segment[ii] = calculate_battery_mass_range(
                    mass_start,
                    range_energy1,
                    Easterisk,
                    eta_prop1_cruise,
                    c_L_cruise,
                    c_D_cruise,
                )
                mass_energy1 = energy_mass1_mission_segment[ii]
                energy_fraction1[ii] = 1 - mass_energy1 / mass_start
                mass_H2O_1 = 0

            mass_end1 = mass_start - mass_energy1 * mass_change_type1 + mass_H2O_1

            # Energy2
            # in case no hybrid aircraft is calculated, energyFraction2 will return 1, because rangeEnergy2 = 0. However, calculation still needed to proceed with script
            if propellant_type.endswith("kerosene") or propellant_type.endswith(
                "hydrogen",
            ):
                energy_fraction2[ii] = calculate_fuel_fraction_range_breguet_fc1(
                    range_energy2,
                    SFC_cruise,
                    c_L_cruise,
                    c_D_cruise,
                    mission_segments[ii].airspeed_start,
                    n_v,
                )
                mass_energy2 = mass_start * (1 - energy_fraction2[ii])
                energy_mass2_mission_segment[ii] = mass_energy2
                mass_H2O_2 = 0
            elif propellant_type.endswith("fuelcell"):
                eta_prop = eta_prop2_cruise / eta_fuelcell_LHV
                energy_fraction2[ii] = (
                    calculate_fuel_fraction_range_breguet_fc1_fuelcell(
                        range_energy2,
                        c_L_cruise,
                        c_D_cruise,
                        eta_prop,
                        eta_fuelcell_voltage,
                        U_thermo,
                        mue,
                        retainH2O,
                    )
                )
                mass_energy2 = mass_start * (1 - energy_fraction2[ii])
                energy_mass2_mission_segment[ii] = mass_energy2
                if retainH2O:
                    mass_H2O_2 = (
                        8.45 * mass_energy2
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O_2 = 0

            elif propellant_type.endswith("battery"):
                energy_mass2_mission_segment[ii] = calculate_battery_mass_range(
                    (mass_start + mass_end1) / 2,
                    range_energy2,
                    Easterisk,
                    eta_prop2_cruise,
                    c_L_cruise,
                    c_D_cruise,
                )
                mass_energy2 = energy_mass2_mission_segment[ii]
                energy_fraction2[ii] = 1 - mass_energy2 / ((mass_start + mass_end1) / 2)
                mass_H2O_2 = 0

            mass_end = (
                mass_start
                - mass_energy1 * mass_change_type1
                - mass_energy2 * mass_change_type2
                + mass_H2O_1
                + mass_H2O_2
            )
            rho_end = (2 * mass_end * g) / (
                c_L_cruise * mission_segments[ii].airspeed_start ** 2 * S_ref
            )

            # Calculate altitude at the end of the segment (changes according to breguet flight condition 1)
            altitude_end = Atmosphere.from_density(rho_end).h

            # Save results
            mission_segments[ii].lift_coefficient = c_L_cruise
            mission_segments[ii].lift_drag_ratio = c_L_cruise / c_D_cruise
            mission_segments[ii].mass_start = mass_start  # [kg]
            mission_segments[ii].mass_end = mass_end  # [kg]
            mission_segments[ii].fuel_used = mass_energy1  # [kg]
            mission_segments[ii].battery_mass_used = mass_energy2  # [kg]
            mission_segments[ii].airspeed_end = mission_segments[
                ii
            ].airspeed_start  # Breguet FC1 = constant velocity
            mission_segments[ii].altitude_end = float(altitude_end)  # [m]
            mission_segments[ii].endurance = (
                mission_segments[ii].range / mission_segments[ii].airspeed_start
            )  # [s]
            mission_segments[ii].angle_of_attack = alpha_cruise

        elif segment_type == "maneuvering":
            if ii != 0:
                mass_start = mission_segments[ii - 1].mass_end
            else:
                mass_start = mission_segments[ii].mass_start

            endurance_energy1 = mission_segments[ii].endurance * (
                1 - mission_segments[ii].hybridization
            )
            endurance_energy2 = (
                mission_segments[ii].endurance * mission_segments[ii].hybridization
            )

            altitude_start = mission_segments[ii].altitude_start

            # Compute density in current altitude
            atmosphere = Atmosphere(altitude_start)
            rho_start = atmosphere.density

            c_L_maneuvering = (2 * mass_start * g) / (
                rho_start * mission_segments[ii].airspeed_start ** 2 * S_ref
            )  # Breguet FC1 = constant cL
            # if c_L_maneuvering > max(c_L_array):
            #    raise ValueError('the available lift is not sufficient to lift the configuration!')
            # else:
            c_D_maneuvering = np.interp(
                c_L_maneuvering,
                c_L_array,
                c_D_array,
            )  # careful! constant extrapolation if out of range! Check c_L afterwards!
            alpha_maneuvering = np.interp(
                c_L_maneuvering,
                c_L_array,
                alpha_array,
            )  # careful! constant extrapolation if out of range! Check alpha afterwards!

            # Energy1
            if propellant_type.startswith("kerosene") or propellant_type.startswith(
                "hydrogen",
            ):
                energy_fraction1[ii] = calculate_fuel_fraction_endurance_maneuvering(
                    mass_start,
                    endurance_energy1,
                    SFC_maneuvering,
                    T_maneuvering,
                    mission_segments[ii].airspeed_start,
                )
                mass_energy1 = mass_start * (1 - energy_fraction1[ii])
                energy_mass1_mission_segment[ii] = mass_energy1
                mass_H2O_1 = 0
            elif propellant_type.startswith("fuelcell"):
                eta_prop = eta_prop1_cruise / eta_fuelcell_LHV
                energy_fraction1[ii] = (
                    calculate_fuel_fraction_endurance_maneuvering_fuelcell(
                        mass_start,
                        endurance_energy1,
                        T_maneuvering,
                        mission_segments[ii].airspeed_start,
                        eta_prop,
                        eta_fuelcell_voltage,
                        U_thermo,
                        mue,
                        retainH2O,
                    )
                )
                mass_energy1 = mass_start * (1 - energy_fraction1[ii])
                energy_mass1_mission_segment[ii] = mass_energy1
                if retainH2O:
                    mass_H2O_1 = (
                        8.45 * mass_energy1
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O_1 = 0
            elif propellant_type.startswith(
                "battery",
            ):  # battery is only first, if it's battery-only, so battery mass can be calculated with massStart only as the mass wouldn't change
                energy_mass1_mission_segment[ii] = calculate_battery_mass_endurance(
                    mass_start,
                    endurance_energy1,
                    mission_segments[ii].airspeed_start,
                    Easterisk,
                    eta_prop1_cruise,
                    c_L_maneuvering,
                    c_D_maneuvering,
                )
                mass_energy1 = energy_mass1_mission_segment[ii]
                energy_fraction1[ii] = 1 - mass_energy1 / mass_start
                mass_H2O_1 = 0

            mass_end1 = mass_start - mass_energy1 * mass_change_type1 + mass_H2O_1

            # Energy2
            # in case no hybrid aircraft is calculated, energyFraction2 will return 1, because rangeEnergy2 = 0. However, calculation still needed to proceed with script
            if propellant_type.endswith("kerosene") or propellant_type.endswith(
                "hydrogen",
            ):
                energy_fraction2[ii] = calculate_fuel_fraction_endurance_maneuvering(
                    mass_start,
                    endurance_energy2,
                    SFC_maneuvering,
                    T_maneuvering,
                    mission_segments[ii].airspeed_start,
                    n_v,
                )
                mass_energy2 = mass_start * (1 - energy_fraction2[ii])
                energy_mass2_mission_segment[ii] = mass_energy2
                mass_H2O_2 = 0
            elif propellant_type.endswith("fuelcell"):
                eta_prop = eta_prop2_maneuvering / eta_fuelcell_LHV
                energy_fraction2[ii] = (
                    calculate_fuel_fraction_endurance_maneuvering_fuelcell(
                        mass_start,
                        endurance_energy2,
                        T_maneuvering,
                        mission_segments[ii].airspeed_start,
                        eta_prop,
                        eta_fuelcell_voltage,
                        U_thermo,
                        mue,
                        retainH2O,
                    )
                )
                mass_energy2 = mass_start * (1 - energy_fraction2[ii])
                energy_mass2_mission_segment[ii] = mass_energy2
                if retainH2O:
                    mass_H2O_2 = (
                        8.45 * mass_energy2
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O_2 = 0
            elif propellant_type.endswith("battery"):
                energy_mass2_mission_segment[ii] = calculate_battery_mass_endurance(
                    (mass_start + mass_end1) / 2,
                    endurance_energy2,
                    mission_segments[ii],
                    Easterisk,
                    eta_prop2_maneuvering,
                    c_L_maneuvering,
                    c_D_maneuvering,
                )
                mass_energy2 = energy_mass2_mission_segment[ii]
                energy_fraction2[ii] = 1 - mass_energy2 / ((mass_start + mass_end1) / 2)
                mass_H2O_2 = 0

            mass_end = (
                mass_start
                - mass_energy1 * mass_change_type1
                - mass_energy2 * mass_change_type2
                + mass_H2O_1
                + mass_H2O_2
            )

            # Save results
            mission_segments[ii].lift_coefficient = c_L_maneuvering
            mission_segments[ii].lift_drag_ratio = c_L_maneuvering / c_D_maneuvering
            mission_segments[ii].mass_start = mass_start  # [kg]
            mission_segments[ii].mass_end = mass_end  # [kg]
            mission_segments[ii].fuel_used = mass_energy1  # [kg]
            mission_segments[ii].battery_mass_used = mass_energy2  # [kg]
            mission_segments[ii].airspeed_end = mission_segments[
                ii
            ].airspeed_start  # airspeed @ end of maneuvering is constant
            mission_segments[ii].altitude_end = mission_segments[
                ii
            ].altitude_start  # altitude @ end of maneuvering is constant
            mission_segments[ii].angle_of_attack = alpha_maneuvering

        elif segment_type == "loiter":
            if ii != 0:
                mass_start = mission_segments[ii - 1].mass_end
            else:
                mass_start = mission_segments[ii].mass_start

            endurance_energy1 = mission_segments[ii].endurance * (
                1 - mission_segments[ii].hybridization
            )
            endurance_energy2 = (
                mission_segments[ii].endurance * mission_segments[ii].hybridization
            )

            altitude_start = mission_segments[ii].altitude_start

            # Compute density in current altitude
            atmosphere = Atmosphere(altitude_start)
            rho_start = atmosphere.density

            c_L_loiter = (2 * mass_start * g) / (
                rho_start * mission_segments[ii].airspeed_start ** 2 * S_ref
            )  # Breguet FC1 = constant cL
            # if c_L_loiter > max(c_L_array):
            #    raise ValueError('the available lift is not sufficient to lift the configuration!')
            # else:
            c_D_loiter = np.interp(
                c_L_loiter,
                c_L_array,
                c_D_array,
            )  # careful! constant extrapolation if out of range! Check c_L afterwards!
            alpha_loiter = np.interp(
                c_L_loiter,
                c_L_array,
                alpha_array,
            )  # careful! constant extrapolation if out of range! Check alpha afterwards!

            # Energy1
            if propellant_type.startswith("kerosene") or propellant_type.startswith(
                "hydrogen",
            ):
                energy_fraction1[ii] = calculate_fuel_fraction_endurance_breguet_fc1(
                    endurance_energy1,
                    SFC_loiter,
                    c_L_loiter,
                    c_D_loiter,
                    mission_segments[ii].airspeed_start,
                    n_v,
                )
                mass_energy1 = mass_start * (1 - energy_fraction1[ii])
                energy_mass1_mission_segment[ii] = mass_energy1
                mass_H2O_1 = 0
            elif propellant_type.startswith("fuelcell"):
                eta_prop = eta_prop1_cruise / eta_fuelcell_LHV
                energy_fraction1[ii] = (
                    calculate_fuel_fraction_endurance_breguet_fc1_fuelcell(
                        endurance_energy1,
                        c_L_loiter,
                        c_D_loiter,
                        mission_segments[ii].airspeed_start,
                        eta_prop,
                        eta_fuelcell_voltage,
                        U_thermo,
                        mue,
                        retainH2O,
                    )
                )
                mass_energy1 = mass_start * (1 - energy_fraction1[ii])
                energy_mass1_mission_segment[ii] = mass_energy1
                if retainH2O:
                    mass_H2O_1 = (
                        8.45 * mass_energy1
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O_1 = 0
            elif propellant_type.startswith(
                "battery",
            ):  # battery is only first, if it's battery-only, so battery mass can be calculated with massStart only as the mass wouldn't change
                energy_mass1_mission_segment[ii] = calculate_battery_mass_endurance(
                    mass_start,
                    endurance_energy1,
                    mission_segments[ii].airspeed_start,
                    Easterisk,
                    eta_prop1_cruise,
                    c_L_loiter,
                    c_D_loiter,
                )
                mass_energy1 = energy_mass1_mission_segment[ii]
                energy_fraction1[ii] = 1 - mass_energy1 / mass_start
                mass_H2O_1 = 0

            mass_end1 = mass_start - mass_energy1 * mass_change_type1 + mass_H2O_1

            # Energy2
            # in case no hybrid aircraft is calculated, energyFraction2 will return 1, because rangeEnergy2 = 0. However, calculation still needed to proceed with script
            if propellant_type.endswith("kerosene") or propellant_type.endswith(
                "hydrogen",
            ):
                energy_fraction2[ii] = calculate_fuel_fraction_endurance_breguet_fc1(
                    endurance_energy2,
                    SFC_loiter,
                    c_L_loiter,
                    c_D_loiter,
                    mission_segments[ii].airspeed_start,
                    n_v,
                )
                mass_energy2 = mass_start * (1 - energy_fraction2[ii])
                energy_mass2_mission_segment[ii] = mass_energy2
                mass_H2O_2 = 0
            elif propellant_type.endswith("fuelcell"):
                eta_prop = eta_prop2_cruise / eta_fuelcell_LHV
                energy_fraction2[ii] = (
                    calculate_fuel_fraction_endurance_breguet_fc1_fuelcell(
                        endurance_energy2,
                        c_L_loiter,
                        c_D_loiter,
                        mission_segments[ii].airspeed_start,
                        eta_prop,
                        eta_fuelcell_voltage,
                        U_thermo,
                        mue,
                        retainH2O,
                    )
                )
                mass_energy2 = mass_start * (1 - energy_fraction2[ii])
                energy_mass2_mission_segment[ii] = mass_energy2
                if retainH2O:
                    mass_H2O_2 = (
                        8.45 * mass_energy2
                    )  # 8.45 from Larminie & Dicks fraction mH2O/mH2
                else:
                    mass_H2O_2 = 0
            elif propellant_type.endswith("battery"):
                energy_mass2_mission_segment[ii] = calculate_battery_mass_endurance(
                    (mass_start + mass_end1) / 2,
                    endurance_energy2,
                    mission_segments[ii].airspeed_start,
                    Easterisk,
                    eta_prop2_loiter,
                    c_L_loiter,
                    c_D_loiter,
                )
                mass_energy2 = energy_mass2_mission_segment[ii]
                energy_fraction2[ii] = 1 - mass_energy2 / ((mass_start + mass_end1) / 2)
                mass_H2O_2 = 0

            mass_end = (
                mass_start
                - mass_energy1 * mass_change_type1
                - mass_energy2 * mass_change_type2
                + mass_H2O_1
                + mass_H2O_2
            )
            rho_end = (2 * mass_end * g) / (
                c_L_loiter * mission_segments[ii].airspeed_start ** 2 * S_ref
            )

            # Calculate altitude at the end of the segment (changes according to breguet flight condition 1)
            altitude_end = Atmosphere.from_density(rho_end).h

            # Save results
            mission_segments[ii].lift_coefficient = c_L_loiter
            mission_segments[ii].lift_drag_ratio = c_L_loiter / c_D_loiter
            mission_segments[ii].mass_start = mass_start  # [kg]
            mission_segments[ii].mass_end = mass_end  # [kg]
            mission_segments[ii].fuel_used = mass_energy1  # [kg]
            mission_segments[ii].battery_mass_used = mass_energy2  # [kg]
            mission_segments[ii].airspeed_end = mission_segments[
                ii
            ].airspeed_start  # Breguet FC1 = constant velocity
            mission_segments[ii].altitude_end = float(altitude_end)  # [m]
            mission_segments[ii].range = (
                mission_segments[ii].endurance * mission_segments[ii].airspeed_start
            )  # [m]
            mission_segments[ii].angle_of_attack = alpha_loiter

    # initialize fuel_used_total
    fuel_used_total = 0
    for segment in mission_segments:
        fuel_used_total += segment.fuel_used

    fuel_used_total = fuel_used_total * fuelReserve

    # initialize battery_mass_used_total
    battery_mass_used_total = 0
    for segment in mission_segments:
        battery_mass_used_total += segment.battery_mass_used

    battery_mass_used_total = battery_mass_used_total * batteryReserve

    lift_to_drag_ratio_all_mission_segments = {
        segment.name: segment.lift_drag_ratio
        for index, segment in enumerate(mission_segments, start=1)
    }
    angle_of_attack_all_mission_segments = {
        segment.name: segment.angle_of_attack
        for index, segment in enumerate(mission_segments, start=1)
    }
    lift_coefficient_all_mission_segments = {
        segment.name: segment.lift_coefficient
        for index, segment in enumerate(mission_segments, start=1)
    }

    return (
        fuel_used_total,
        battery_mass_used_total,
        lift_to_drag_ratio_all_mission_segments,
        angle_of_attack_all_mission_segments,
        lift_coefficient_all_mission_segments,
    )


###########################################################


class Options(SolverOptions):
    def __init__(
        self,
        *,
        wing_name_serving_for_reference_area: str | None = None,
        fuel_reserve: float = 1.0,
        battery_reserve: float = 1.0,
        compute_lift_drag_ratio: bool = True,
        compute_fuel_used: bool = True,
        compute_battery_mass: bool = True,
        compute_h2o_used: bool = False,
        hybridization_default: float = 0.0,
        sfc_cruise: float = 0.00001667,  # Default for kerosene (kg/Ns)
        sfc_hover: float = 0.00001667,
        sfc_loiter: float = 0.00001667,
        sfc_maneuvering: float = 0.00001667,
        eta_prop1_cruise: float = 0.3,
        eta_prop2_cruise: float = 0.3,
        eta_prop2_loiter: float = 0.3,
        eta_prop2_maneuvering: float = 0.3,
        easterisk: float = 1.0,
        eta_fuelcell_voltage: float = 0.6,
        eta_fuelcell_lhv: float = 1.0,
        u_thermo: float = 1.0,
        mue: float = 1.0,
        retain_h2o: bool = False,
        energy_fraction: dict | None = None,
        n_v: float = 1.0,  # Power dependency regarding airspeed
        jac_approx_type: str = "finite_differences",
        jac_approx_step: float = 1e-03,
        jac_approx_n_processes: int = 1,
        jac_approx_use_threading: bool = False,
        **kwargs: Any,  # noqa: ANN401
    ) -> None:
        super().__init__()
        self.wing_name_serving_for_reference_area = wing_name_serving_for_reference_area
        self.fuel_reserve = fuel_reserve
        self.battery_reserve = battery_reserve
        self.compute_lift_drag_ratio = compute_lift_drag_ratio
        self.compute_fuel_used = compute_fuel_used
        self.compute_battery_mass = compute_battery_mass
        self.compute_h2o_used = compute_h2o_used
        self.hybridization_default = hybridization_default
        self.sfc_cruise = sfc_cruise
        self.sfc_hover = sfc_hover
        self.sfc_loiter = sfc_loiter
        self.sfc_maneuvering = sfc_maneuvering
        self.eta_prop1_cruise = eta_prop1_cruise
        self.eta_prop2_cruise = eta_prop2_cruise
        self.eta_prop2_loiter = eta_prop2_loiter
        self.eta_prop2_maneuvering = eta_prop2_maneuvering
        self.easterisk = easterisk
        self.eta_fuelcell_voltage = eta_fuelcell_voltage
        self.eta_fuelcell_lhv = eta_fuelcell_lhv
        self.u_thermo = u_thermo
        self.mue = mue
        self.retain_h2o = retain_h2o
        self.energy_fraction = (
            energy_fraction
            if energy_fraction is not None
            else {
                "engineStart": 0.0,
                "taxi": 0.0,
                "takeOff": 0.0,
                "climb": 0.0,
                "descent": 0.0,
                "landing": 0.0,
            }
        )
        self.n_v = n_v
        self.kwargs = kwargs
        # jacobian
        self.jac_approx_type = jac_approx_type
        self.jac_approx_step = jac_approx_step
        self.jac_approx_n_processes = jac_approx_n_processes
        self.jac_approx_use_threading = jac_approx_use_threading

class WingOptions(assembly.ComponentOptions):
    def __init__(
        self,
        area: float | None = None,
    ) -> None:
        self.area = area

class Wing:
    def __init__(self, 
                 name: str,
                 area: float | None,
    ) -> None:
                self.name = name
                self.area = area
    
    @classmethod
    def from_component(cls, comp: Base_Wing) -> Self:
        if opts := next((o for o in comp.options if type(o) is WingOptions), None):
            opts.area = opts.area
        else:
            msg = f"No ROSKAM options in component '{comp.name}'."
            raise ValueError(msg)

        return cls(
            comp.name,
            opts.area,
        )

class Configuration:
    def __init__(self, aerodynamic_polar) -> None:
        """Initialize configuration with aerodynamic polar.

        Args:
            aerodynamic_polar: Can be AerodynamicPolarData, PolarVariable, or dict
        """
        self.aerodynamic_polar = PolarData(aerodynamic_polar)

    @classmethod
    def from_component(cls, comp: Base_Configuration) -> Configuration:
        configuration = cls(
            aerodynamic_polar=comp.aerodynamic_polar,
        )
        if hasattr(comp, "options") and isinstance(comp.options, dict):
            for k, v in comp.options.get("roskam", {}).items():
                if k in vars(configuration):
                    setattr(configuration, k, v)
        return configuration

from multiads.assembly.envelope import SegmentEnvelope as Base_MissionAssembly

class MissionAssembly:
    def __init__(
        self,
        name: str | None = None,
        type: str | None = None,
        mission_segments: list[Segment] | None = None,
        fuel_used_total: float | None = None,
        battery_mass_used_total: float | None = None,
        h2o_used_total: float | None = None,
    ) -> None:
        self.name = name
        self.type = type
        self.mission_segments = mission_segments
        self.fuel_used_total = fuel_used_total
        self.battery_mass_used_total = battery_mass_used_total
        self.h2o_used_total = h2o_used_total

    @classmethod
    def from_component(cls, comp: Base_MissionAssembly) -> MissionAssembly:
        mission_assembly = cls(
            name = comp.name,
            type = comp.type,
            mission_segments=comp.mission_segments,
            fuel_used_total=getattr(comp, "fuel_used_total", None),
            battery_mass_used_total=getattr(comp, "battery_mass_used_total", None),
            h2o_used_total=getattr(comp, "h2o_used_total", None),
        )
        if hasattr(comp, "options") and isinstance(comp.options, dict):
            for k, v in comp.options.get("roskam", {}).items():
                if k in vars(mission_assembly):
                    setattr(mission_assembly, k, v)
        return mission_assembly


class PropulsionSystem:
    def __init__(self, type: str) -> None:
        self.type = type

    @classmethod
    def from_component(cls, comp: Base_PropulsionSystem) -> PropulsionSystem:
        propulsion_system = cls(
            type=comp.type,
        )
        if hasattr(comp, "options") and isinstance(comp.options, dict):
            for k, v in comp.options.get("roskam", {}).items():
                if k in vars(propulsion_system):
                    setattr(propulsion_system, k, v)
        return propulsion_system


class Driver:
    def __init__(
        self,
        wings: list[Base_Wing] | None = None,
        mission_assembly: MissionAssembly | None = None,
        configuration: Configuration | None = None,
        propulsion_system: PropulsionSystem | None = None,
        options: Options | None = None,
    ) -> None:
        self.options = options or Options()
        self.wings = wings
        self.mission_assembly = mission_assembly
        self.configuration = configuration
        self.propulsion_system = propulsion_system
        self.fuel_used_total = None
        self.battery_mass_used_total = None
        self.lift_to_drag_ratio_all_mission_segments = (
            {segment.name: 0.0 for segment in mission_assembly.mission_segments}
            if mission_assembly and mission_assembly.mission_segments
            else {}
        )
        self.angle_of_attack_all_mission_segments = (
            {segment.name: 0.0 for segment in mission_assembly.mission_segments}
            if mission_assembly and mission_assembly.mission_segments
            else {}
        )
        self.lift_coefficient_all_mission_segments = (
            {segment.name: 0.0 for segment in mission_assembly.mission_segments}
            if mission_assembly and mission_assembly.mission_segments
            else {}
        )

    def run(self) -> tuple[float, float, dict, dict, dict]:
        # identify wing reference area
        reference_area = 0.0
        for wing in self.wings:
            wing_name = getattr(wing, "name", None)
            if wing_name == self.options.wing_name_serving_for_reference_area:
                reference_area = getattr(wing, "area", 0.0)
                # stop loop once the wing has been identified
                break

        (
            self.fuel_used_total,
            self.battery_mass_used_total,
            self.lift_to_drag_ratio_all_mission_segments,
            self.angle_of_attack_all_mission_segments,
            self.lift_coefficient_all_mission_segments,
        ) = calculate_mission_roskam_customized(
            self.mission_assembly,
            self.options.energy_fraction,
            self.propulsion_system.type,
            reference_area,
            self.options.n_v,
            self.configuration.aerodynamic_polar.lift_coefficient,
            self.configuration.aerodynamic_polar.drag_coefficient,
            self.configuration.aerodynamic_polar.alpha,
            self.options.fuel_reserve,
            self.options.battery_reserve,
            **self.options.kwargs,
        )

        return (
            self.fuel_used_total,
            self.battery_mass_used_total,
            self.lift_to_drag_ratio_all_mission_segments,
            self.angle_of_attack_all_mission_segments,
            self.lift_coefficient_all_mission_segments,
        )

    def retrieve_lift_to_drag_ratio(self, segment_name: list[str]) -> float:
        lift_to_drag_ratio = self.lift_to_drag_ratio_all_mission_segments[segment_name]

        return lift_to_drag_ratio

    def retrieve_angle_of_attack(self, segment_name: list[str]) -> float:
        angle_of_attack = self.angle_of_attack_all_mission_segments[segment_name]

        return angle_of_attack

    def retrieve_lift_coefficient(self, segment_name: list[str]) -> float:
        lift_coefficient = self.lift_coefficient_all_mission_segments[segment_name]

        return lift_coefficient
