from __future__ import annotations

import copy
from typing import TYPE_CHECKING

from multiads.assembly import (
    Configuration,
    MADSComponent,
    PropulsionSystem,
    Wing,
    copy_components,
    flatten_components,
)
from multiads.assembly.envelope import (
    MADSPhase,
    Segment,
    flatten_segments,
)
from multiads.scenario.variables import BaseVariable, InnerVariableFloat
from multiads.solvers import BaseSolver
from multiads.solvers.mission.roskam_lib import (
    Configuration as RoskamConfiguration,
)
from multiads.solvers.mission.roskam_lib import (
    Driver,
    MissionAssembly,
    Options,
)
from multiads.solvers.mission.roskam_lib import (
    PropulsionSystem as RoskamPropulsionSystem,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from numpy.typing import NDArray


class Roskam(BaseSolver):
    def __init__(self, options: Options | None = None) -> None:
        super().__init__()
        self.options: Options = options or Options()
        self.driver: Driver | None = None
        self.configuration: RoskamConfiguration | None = None
        self.propulsion_system: RoskamPropulsionSystem | None = None
        self.segments: Sequence[MADSPhase] | None = None
        self.wings: Sequence[Wing] | None = None
        self.outputs_map: dict[str, InnerVariableFloat] | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        segments: Sequence[MADSPhase],
    ) -> Sequence[MADSComponent]:
        # Filter components
        _components = copy_components(components)
        comp_flat = flatten_components(_components)

        # create segment list - local
        self.segments: list = []
        # filter segments
        _segments = copy.deepcopy(segments)
        segments_flat = flatten_segments(_segments)
        if sg := next((s for s in segments_flat if isinstance(s, Segment)), None):
            # segments as list
            self.segments.append(sg)
            # loop over segment
        if segments:
            self.mission_assembly = MissionAssembly(
                name="mission_assembly",
                type="mission",
                mission_segments=list(segments),
            )
        else:
            self.mission_assembly = None

        try:
            self.configuration = next(c for c in comp_flat if type(c) is Configuration)
        except StopIteration:
            msg = f"A configuration must be provided to solver '{type(self).__name__}'."
            raise ValueError(msg) from None

        try:
            self.propulsion_system = next(
                c for c in comp_flat if type(c) is PropulsionSystem
            )
        except StopIteration:
            msg = f"A propulsion system must be provided to solver '{type(self).__name__}'."
            raise ValueError(msg) from None

        if not self.mission_assembly:
            msg = f"A mission assembly must be provided to solver '{type(self).__name__}'."
            raise ValueError(msg) from None

        self.wings = [c for c in comp_flat if type(c) is Wing]

        inputs: list[BaseVariable] = []

        if self.mission_assembly:
            for segment in self.mission_assembly.mission_segments:
                if v := segment.variables.get("mass_start"):
                    inputs.append(v)
                if v := segment.variables.get("range"):
                    inputs.append(v)
                if v := segment.variables.get("endurance"):
                    inputs.append(v)
                if v := segment.variables.get("airspeed_start"):
                    inputs.append(v)
                if v := segment.variables.get("altitude_start"):
                    inputs.append(v)
                if v := segment.variables.get("hybridization"):
                    inputs.append(v)

        outputs: list[InnerVariableFloat] = []

        outputs.append(InnerVariableFloat("fuel_used_total", 0.0))
        outputs.append(InnerVariableFloat("battery_mass_used_total", 0.0))

        if self.mission_assembly:
            for segment in self.mission_assembly.mission_segments:
                outputs.append(
                    InnerVariableFloat(f"{segment.name}.lift_to_drag_ratio", 0.0),
                )
                outputs.append(
                    InnerVariableFloat(f"{segment.name}.angle_of_attack", 0.0),
                )
                outputs.append(
                    InnerVariableFloat(f"{segment.name}.lift_coefficient", 0.0),
                )

        self.inputs = inputs
        self.outputs = outputs
        self.outputs_map = {v.name: v for v in outputs}

        return [
            *self.wings,
            self.configuration,
            self.propulsion_system,
        ]

    def _run(self) -> None:
        if (
            self.configuration is None
            or self.propulsion_system is None
            or self.mission_assembly is None
            or self.wings is None
        ):
            msg = f"Components in solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        self.driver = Driver(
            configuration=RoskamConfiguration.from_component(self.configuration),
            propulsion_system=RoskamPropulsionSystem.from_component(
                self.propulsion_system,
            ),
            mission_assembly=MissionAssembly.from_component(
                self.mission_assembly,
            ),
            wings=self.wings,
            options=self.options,
        )
        self.driver.run()

    def compute_output(self) -> None:
        if self.driver is None:
            msg = f"The driver of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.outputs is None or self.outputs_map is None:
            msg = f"The outputs of solver '{type(self).__name__}' are not initialized"
            raise RuntimeError(msg)

        self.outputs_map["fuel_used_total"].value = self.driver.fuel_used_total
        self.outputs_map[
            "battery_mass_used_total"
        ].value = self.driver.battery_mass_used_total

        if self.mission_assembly:
            for segment in self.mission_assembly.mission_segments:
                self.outputs_map[
                    f"{segment.name}.lift_to_drag_ratio"
                ].value = self.driver.lift_to_drag_ratio_all_mission_segments.get(
                    segment.name,
                    0.0,
                )
                self.outputs_map[
                    f"{segment.name}.angle_of_attack"
                ].value = self.driver.angle_of_attack_all_mission_segments.get(
                    segment.name,
                    0.0,
                )
                self.outputs_map[
                    f"{segment.name}.lift_coefficient"
                ].value = self.driver.lift_coefficient_all_mission_segments.get(
                    segment.name,
                    0.0,
                )

    def compute_sensitivities(
        self,
        input_names: Sequence[str],  # noqa: ARG002
        inputs: Sequence[BaseVariable],  # noqa: ARG002
        output_names: Sequence[str],  # noqa: ARG002
        outputs: Sequence[BaseVariable],  # noqa: ARG002
    ) -> Mapping[str, NDArray]:
        return {}
