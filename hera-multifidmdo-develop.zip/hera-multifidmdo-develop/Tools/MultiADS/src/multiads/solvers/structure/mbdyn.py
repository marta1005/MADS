"""MBDyn structural solver.

This solver provides structural analysis using MBDyn, either standalone
or coupled with DUST via preCICE for aeroelastic simulations.
"""

from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

import multiads.solvers.structure.mbdyn_lib as mbl
from multiads.assembly import (
    Environment,
    Fuselage,
    MADSComponent,
    Propeller,
    Wing,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import (
    InnerVariable,
    InnerVariableFloat,
    InnerVariableFloatNP,
)
from multiads.solvers import BaseSolver

if TYPE_CHECKING:
    from collections.abc import Sequence


class MBDYN(BaseSolver):
    def __init__(self, options: mbl.DUSTMBDYNOptions) -> None:
        super().__init__()
        self.options: mbl.DUSTMBDYNOptions = options
        self.driver: mbl.DriverDUSTMBDYN | mbl.MBDYNDriver | None = None
        self.environment: Environment | None = None
        self.wings: Sequence[mbl.WingMBDYN] | None = None
        self.propellers: Sequence[Any] | None = None
        self.fuselages: Sequence[Fuselage] | None = None
        self.outputs_map: dict[str, InnerVariable] | None = None
        self.run_directory: Path | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv: Any,
    ) -> Sequence[MADSComponent]:
        _components = copy_components(components)
        comp_flat = flatten_components(_components)

        wings = [c for c in comp_flat if type(c) is Wing]
        propellers = [c for c in comp_flat if type(c) is Propeller]
        fuselages = [c for c in comp_flat if type(c) is Fuselage]

        try:
            environment = next(c for c in comp_flat if type(c) is Environment)
        except StopIteration:
            environment = None

        wings_mapped = [mbl.WingMBDYN.from_component(w) for w in wings]

        self.environment = environment
        self.wings = wings_mapped
        self.propellers = propellers
        self.fuselages = fuselages

        self.outputs = self._create_output_variables(wings_mapped)
        self.outputs_map = {v.name: v for v in self.outputs}

        return (
            [environment, *wings, *propellers, *fuselages]
            if environment
            else [*wings, *propellers, *fuselages]
        )

    def _create_output_variables(
        self,
        wings: Sequence[mbl.WingMBDYN],
    ) -> list[InnerVariable]:
        outputs: list[InnerVariable] = []

        for wing in wings:
            if wing.options.compute_loads:
                outputs.extend(
                    [
                        InnerVariableFloatNP(f"{wing.name}.displ_z", np.zeros(1)),
                        InnerVariableFloat(f"{wing.name}.rot_y", 0.0),
                    ],
                )

        return outputs

    def set_state(self, components: Sequence[MADSComponent]) -> None:
        if self.wings is None:
            msg = f"Components of solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        local_components = list(self.wings)
        for comp in components:
            for l_comp in local_components:
                if comp.name == l_comp.name:
                    l_comp.update(comp)

        self.options.work_dir.mkdir(parents=True, exist_ok=True)
        self.run_directory = Path(
            tempfile.mkdtemp(
                dir=self.options.work_dir,
                prefix=self.options.name,
            ),
        )

    def _run(self) -> None:
        if self.wings is None:
            msg = f"The solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        main_dir = Path.cwd()
        os.chdir(self.run_directory)

        self.driver = mbl.Driver(
            environment=self.environment,
            wings=list(self.wings),
            propellers=list(self.propellers) if self.propellers else None,
            fuselages=list(self.fuselages) if self.fuselages else None,
            options=self.options,
        )

        self.driver.preprocess()
        self.driver.run()
        self.driver.postprocess([mbl.MBDYNPostDeform(wings=list(self.wings))])

        os.chdir(main_dir)

    def compute_output(self) -> None:
        if self.wings is None:
            msg = f"Components of solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        if self.outputs is None or self.outputs_map is None:
            msg = f"The interface of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.driver is None or self.run_directory is None:
            msg = f"Solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        for wing in self.wings:
            if wing.options.compute_loads:
                displ = self.outputs_map.get(f"{wing.name}.displ_z")
                rot = self.outputs_map.get(f"{wing.name}.rot_y")

                if (
                    displ is not None
                    and hasattr(self.driver, "displ")
                    and self.driver.displ is not None
                ):
                    d = self.driver.displ
                    displ.value[0] = d[2, 0] if len(d.shape) > 1 else d[2]

                if (
                    rot is not None
                    and hasattr(self.driver, "rot")
                    and self.driver.rot is not None
                ):
                    r = self.driver.rot
                    rot.value = r[1, 0] if len(r.shape) > 1 else r[1]

        shutil.rmtree(self.run_directory)

    def compute_sensitivities(
        self,
        input_names: Sequence[str],
        inputs: Sequence[Any],
        output_names: Sequence[str],
        outputs: Sequence[Any],
    ) -> dict[str, Any]:
        return {}
