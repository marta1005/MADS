"""Lagrange structural solver library.

This module provides structural analysis capabilities using the Lagrange
structural solver. It includes classes for wings, sections, and other
structural components, as well as the main driver class.
"""

from __future__ import annotations

import logging
import os
import subprocess as sp
from copy import deepcopy
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from multiads import assembly
from multiads.solvers.aerodynamics.dust_lib import (
    Driver as BaseDriver,
    MovableSurface as BaseMovableSurface,
    Options as BaseOptions,
    PostLoads,
    Wing as BaseWing,
    _log_cmd_output,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


def _lagrange_options(comp: assembly.MADSComponent) -> dict[str, Any]:
    """Extract Lagrange-specific options from a component.

    Args:
        comp: The component to extract options from.

    Returns:
        Dictionary of Lagrange options.
    """
    if hasattr(comp, "options") and isinstance(comp.options, dict):
        return deepcopy(comp.options.get("lagrange", {}))
    return {}


def _log_cmd_output(file_name: Path, cmd: Any, name: str, mode: str = "w") -> None:
    """Log command output to a file.

    Args:
        file_name: Path to the log file.
        cmd: Command result with stdout, stderr, and returncode.
        name: Name of the command for error messages.
        mode: File open mode ('w' or 'a').
    """
    with open(file_name, mode) as f:
        for line in cmd.stdout.splitlines():
            f.write(f"INFO: {line}\n")
        for line in cmd.stderr.splitlines():
            f.write(f"ERROR: {line}\n")
        if cmd.returncode != 0:
            raise RuntimeError(f"could not run '{name}'")


class LagrangeMode(Enum):
    """Mode of Lagrange execution."""

    EVALUATION = "evaluation"
    OPTIMIZATION = "optimization"


class LagrangeOptions:
    """Options for the Lagrange solver."""

    def __init__(
        self,
        name: str = "lagrange",
        lagrange_command: str = "lagrange",
        lagrange_input_file: str = "lagrange_input",
        work_dir: Path | str = ".",
        xstruct: dict | None = None,
    ) -> None:
        """Initialize Lagrange options.

        Args:
            name: Solver name.
            lagrange_command: Command to run Lagrange.
            lagrange_input_file: Input file name for Lagrange.
            work_dir: Working directory for solver execution.
            xstruct: Dictionary of structural design variables.
        """
        self.name = name
        self.lagrange_command = lagrange_command
        self.lagrange_input_file = lagrange_input_file
        self.work_dir = Path(work_dir) if isinstance(work_dir, str) else work_dir
        self.xstruct = xstruct


class Section:
    """Airfoil section data for Lagrange."""

    def __init__(
        self,
        airfoil: str | Path,
        chord: float,
        twist: float,
    ) -> None:
        """Initialize Section.

        Args:
            airfoil: Path or name of the airfoil.
            chord: Chord length.
            twist: Twist angle.
        """
        self.airfoil = airfoil
        self.chord = chord
        self.twist = twist
        self.is_polar = False

    @classmethod
    def from_component(cls, comp: assembly.Section) -> Section:
        """Create Section from assembly component.

        Args:
            comp: The assembly Section component.

        Returns:
            Section instance.
        """
        return cls(
            airfoil=comp.airfoil.airfoil_name,
            chord=comp.chord,
            twist=comp.twist,
        )


class Span:
    """Span section data for Lagrange."""

    def __init__(
        self,
        length: float,
        sweep: float,
        dihed: float,
        n_elem: int = 10,
        elem_type: str = "uniform",
    ) -> None:
        """Initialize Span.

        Args:
            length: Span length.
            sweep: Sweep angle.
            dihed: Dihedral angle.
            n_elem: Number of elements.
            elem_type: Element type.
        """
        self.length = length
        self.sweep = sweep
        self.dihed = dihed
        self.n_elem = n_elem
        self.elem_type = elem_type

    @classmethod
    def from_component(cls, comp: assembly.Span) -> Span:
        """Create Span from assembly component.

        Args:
            comp: The assembly Span component.

        Returns:
            Span instance.
        """
        opts = _lagrange_options(comp)
        return cls(
            length=comp.length,
            sweep=comp.sweep,
            dihed=comp.dihed,
            n_elem=getattr(comp, "n_elem", 10),
            **opts,
        )


class MovableSurface:
    """Movable surface (control surface) data for Lagrange."""

    def __init__(
        self,
        length: float,
        pos: list[float],
        ampl: float,
        sweep: float,
        dihed: float,
        derivative: bool = False,
        dDelta: float = 0.0,
    ) -> None:
        """Initialize MovableSurface.

        Args:
            length: Surface length.
            pos: Position as [x, y, z].
            ampl: Amplitude.
            sweep: Sweep angle.
            dihed: Dihedral angle.
            derivative: Whether this is a derivative surface.
            dDelta: Delta for derivative.
        """
        self.length = length
        self.pos = pos
        self.ampl = ampl
        self.sweep = sweep
        self.dihed = dihed
        self.derivative = derivative
        self.dDelta = dDelta

    @classmethod
    def from_component(cls, comp: assembly.MovableSurface) -> MovableSurface:
        """Create MovableSurface from assembly component.

        Args:
            comp: The assembly MovableSurface component.

        Returns:
            MovableSurface instance.
        """
        opts = _lagrange_options(comp)
        pos = getattr(comp, "pos", [0.5, 0.0, 0.0])
        if isinstance(pos, (list, tuple)):
            pos_list = list(pos)
        else:
            pos_list = [0.5, 0.0, 0.0]
        return cls(
            length=comp.length,
            pos=pos_list,
            ampl=comp.ampl,
            sweep=getattr(comp, "sweep", 0.0),
            dihed=getattr(comp, "dihed", 0.0),
            **opts,
        )


class Wing(BaseWing):
    """Wing data class for Lagrange structural analysis.

    Extends BaseWing with Lagrange-specific structural parameters.
    """

    def __init__(
        self,
        name: str,
        sections: list[Section] | None = None,
        spans: list[Span] | None = None,
        movable_surfaces: list[MovableSurface] | None = None,
        ACapRoot: float = 10.0e-3,
        AStringerRoot: float = 1.0e-3,
        panelMaxLength: float = 0.1,
        ribsMaxSeparation: float = 0.5,
        xstruct: dict | None = None,
        lagrange_input_file: str = "lagrange.inp",
        **kwargs: Any,
    ) -> None:
        """Initialize Wing.

        Args:
            name: Wing name.
            sections: List of section components.
            spans: List of span components.
            movable_surfaces: List of movable surface components.
            ACapRoot: Cap area at root.
            AStringerRoot: Stringer area at root.
            panelMaxLength: Maximum panel length.
            ribsMaxSeparation: Maximum rib separation.
            xstruct: Structural design variables dictionary.
            lagrange_input_file: Input file for Lagrange.
            **kwargs: Additional arguments passed to BaseWing.
        """
        from multiads.solvers.aerodynamics.dust_lib import WingMethod, WingPanelType

        super().__init__(
            name=name,
            sections=sections or [],
            spans=spans or [],
            movable_surfaces=movable_surfaces or [],
            method=kwargs.pop("method", WingMethod.VORTEX_LATTICE),
            panel_type=kwargs.pop("panel_type", WingPanelType.UNIFORM),
            num_panels=kwargs.pop("num_panels", 0),
            **kwargs,
        )
        self.ACapRoot = ACapRoot
        self.AStringerRoot = AStringerRoot
        self.panelMaxLength = panelMaxLength
        self.ribsMaxSeparation = ribsMaxSeparation
        self.xstruct = xstruct
        self.lagrange_input_file = lagrange_input_file

    @classmethod
    def from_component(cls, comp: assembly.Wing) -> Wing:
        """Create Wing from assembly component.

        Args:
            comp: The assembly Wing component.

        Returns:
            Wing instance.
        """
        opts = _lagrange_options(comp)
        sections = [Section.from_component(s) for s in comp.sections]
        spans = [Span.from_component(s) for s in comp.spans]
        movable_surfaces = [
            MovableSurface.from_component(s) for s in comp.movable_surfaces
        ]

        return cls(
            name=comp.name,
            sections=sections,
            spans=spans,
            movable_surfaces=movable_surfaces,
            ACapRoot=getattr(comp, "ACapRoot", 10.0e-3),
            AStringerRoot=getattr(comp, "AStringerRoot", 1.0e-3),
            **opts,
        )

    def write_file(self, wing_file: Path) -> None:
        """Write wing data to file.

        Args:
            wing_file: Path to the output file.
        """
        pass


class Propeller:
    """Propeller data class for Lagrange."""

    def __init__(
        self,
        name: str,
        blade: Wing,
        r_tip: float,
        n_blades: int,
        pitch: float = 0.0,
        rpm: float = 0.0,
        reverse: bool = False,
        pos: list[float] | None = None,
        alpha: float = 0.0,
        beta: float = 0.0,
    ) -> None:
        """Initialize Propeller.

        Args:
            name: Propeller name.
            blade: Wing representing the blade.
            r_tip: Tip radius.
            n_blades: Number of blades.
            pitch: Pitch angle.
            rpm: Rotational speed.
            reverse: Whether propeller reverses.
            pos: Position as [x, y, z].
            alpha: Alpha angle.
            beta: Beta angle.
        """
        self.name = name
        self.blade = blade
        self.r_tip = r_tip
        self.n_blades = n_blades
        self.pitch = pitch
        self.rpm = rpm
        self.reverse = reverse
        self.pos = pos or [0.0, 0.0, 0.0]
        self.alpha = alpha
        self.beta = beta

    @classmethod
    def from_component(cls, comp: assembly.Propeller) -> Propeller:
        """Create Propeller from assembly component.

        Args:
            comp: The assembly Propeller component.

        Returns:
            Propeller instance.
        """
        blade = Wing.from_component(comp.blade)
        global_pos = getattr(comp, "global_pos", [0.0, 0.0, 0.0])
        if isinstance(global_pos, np.ndarray):
            pos = global_pos.tolist()
        elif isinstance(global_pos, (list, tuple)):
            pos = list(global_pos)
        else:
            pos = [0.0, 0.0, 0.0]
        return cls(
            name=comp.name,
            blade=blade,
            r_tip=comp.r_tip,
            n_blades=comp.n_blades,
            pitch=comp.pitch,
            rpm=comp.rpm,
            reverse=comp.reverse,
            pos=pos,
            alpha=comp.alpha,
            beta=comp.beta,
        )


class Fuselage:
    """Fuselage data class for Lagrange."""

    def __init__(
        self,
        name: str,
        wetted_area: float | None = None,
        maximum_width: float | None = None,
        maximum_height: float | None = None,
        length: float | None = None,
        volume_pressurized_cabin: float | None = None,
        maximum_fuselage_pressure_differential: float | None = None,
        mass: float | None = None,
        pos: NDArray[np.float64] | list[float] | None = None,
    ) -> None:
        """Initialize Fuselage.

        Args:
            name: Fuselage name.
            wetted_area: Wetted surface area.
            maximum_width: Maximum width.
            maximum_height: Maximum height.
            length: Fuselage length.
            volume_pressurized_cabin: Pressurized cabin volume.
            maximum_fuselage_pressure_differential: Maximum pressure differential.
            mass: Fuselage mass.
            pos: Position as array or list.
        """
        self.name = name
        self.wetted_area = wetted_area
        self.maximum_width = maximum_width
        self.maximum_height = maximum_height
        self.length = length
        self.volume_pressurized_cabin = volume_pressurized_cabin
        self.maximum_fuselage_pressure_differential = (
            maximum_fuselage_pressure_differential
        )
        self.mass = mass
        if pos is None:
            self.pos = np.array([-17.0, 0.0, -3.5])
        elif isinstance(pos, list):
            self.pos = np.array(pos)
        else:
            self.pos = pos

    @classmethod
    def from_component(cls, comp: assembly.Fuselage) -> Fuselage:
        """Create Fuselage from assembly component.

        Args:
            comp: The assembly Fuselage component.

        Returns:
            Fuselage instance.
        """
        return cls(
            name=comp.name,
            wetted_area=getattr(comp, "wetted_area", None),
            maximum_width=getattr(comp, "maximum_width", None),
            maximum_height=getattr(comp, "maximum_height", None),
            length=getattr(comp, "length", None),
            volume_pressurized_cabin=getattr(comp, "volume_pressurized_cabin", None),
            maximum_fuselage_pressure_differential=getattr(
                comp, "maximum_fuselage_pressure_differential", None
            ),
            mass=getattr(comp, "mass", None),
            pos=getattr(comp, "pos", [-17.0, 0.0, -3.5]),
        )


class LagrangePostLoads(PostLoads):
    """Post-processing class for Lagrange loads results."""

    pass


class LagrangeDriver(BaseDriver):
    """Driver class for Lagrange structural analysis.

    This class manages the execution of the Lagrange structural solver,
    including preprocessing, running, and postprocessing.
    """

    def __init__(
        self,
        environment: assembly.Environment,
        wings: list[Wing],
        propellers: list[Propeller] | None = None,
        fuselages: list[Fuselage] | None = None,
        options: LagrangeOptions | None = None,
    ) -> None:
        """Initialize Lagrange driver.

        Args:
            environment: The environment component.
            wings: List of wing components.
            options: Lagrange solver options.
            propellers: Optional list of propeller components.
            fuselages: Optional list of fuselage components.
        """
        super().__init__(
            environment=environment,
            wings=wings,
            propellers=propellers or [],
            fuselages=fuselages or [],
            options=options,
        )

        self.lagrange_opt = options
        self.lagrange_input_file = options.lagrange_input_file
        self.xstruct = (
            np.zeros(len(options.xstruct)) if options.xstruct else np.array([])
        )
        self._lagrange_instance = None
        self._lagrange_module = None
        self._objective = 0.0
        self._constraints: NDArray[np.float64] = np.array([])
        self._x_struct_opt: NDArray[np.float64] = np.array([])

    def preprocess(self) -> None:
        """Preprocess: set up input files and design variables."""
        self.options.work_dir.mkdir(parents=True, exist_ok=True)

        for wing in self.wings:
            if hasattr(wing, "lagrange_input_file"):
                self.lagrange_input_file = wing.lagrange_input_file
            if hasattr(wing, "xstruct") and wing.xstruct:
                self.xstruct = np.zeros(len(wing.xstruct))

        self._try_import_lagrange()

    def _try_import_lagrange(self) -> None:
        """Try to import the Lagrange Python module."""
        try:
            import lagrange

            path_lag_msg = Path(__file__).absolute().parent / "lagrange_msg.txt"
            lagrange.init(str(path_lag_msg))
            self._lagrange_module = lagrange
        except (ModuleNotFoundError, FileNotFoundError):
            self._lagrange_module = None

    def run(self) -> None:
        """Run the Lagrange structural analysis."""
        logger = logging.getLogger(__name__)
        logger.info("lagrange :: started")

        main_dir = Path.cwd()
        os.chdir(self.options.work_dir)

        if self._lagrange_module is None or self._lagrange_instance is None:
            logger.warning(
                "Lagrange module not available, skipping structural analysis"
            )
            os.chdir(main_dir)
            return

        x_struct = np.asarray(self.xstruct)
        self._lagrange_instance.set_od_x(x_struct)
        self._lagrange_instance.design()

        x_struct_opt = self._lagrange_instance.get_od_x()
        objective = self._lagrange_instance.get_od_f()
        constraints = self._lagrange_instance.get_od_g()

        self._objective = objective
        self._constraints = constraints
        self._x_struct_opt = x_struct_opt

        os.chdir(main_dir)
        logger.info("lagrange :: finished")

    def postprocess(self, analyses: list[LagrangePostLoads] | None = None) -> None:
        """Postprocess: read results from Lagrange output files.

        Args:
            analyses: Optional list of post-processing objects.
        """
        main_dir = Path.cwd()
        os.chdir(self.options.work_dir)

        if analyses:
            for analysis in analyses:
                if hasattr(analysis, "read_output"):
                    analysis.read_output(Path(self.lagrange_input_file))

        os.chdir(main_dir)

    @property
    def objective(self) -> float:
        """Get the objective function value (mass)."""
        return self._objective

    @property
    def constraints(self) -> NDArray[np.float64]:
        """Get the constraint values."""
        return self._constraints

    @property
    def x_struct_opt(self) -> NDArray[np.float64]:
        """Get the optimized structural variables."""
        return self._x_struct_opt

    def var_assign(
        self,
        comp: list[Wing],
        x_struct_opt: NDArray[np.float64] | None = None,
        mode: str = "local",
        update_value: NDArray[np.float64] | None = None,
    ) -> None:
        """Assign variables between component and Lagrange.

        Args:
            comp: List of wing components.
            x_struct_opt: Optimized structural variables.
            mode: Assignment mode ('local' or 'global').
            update_value: Updated values for global assignment.
        """
        x_struct_local = (
            deepcopy(x_struct_opt) if x_struct_opt is not None else self.xstruct
        )

        if mode == "local":
            for wing in comp:
                for var_name in vars(wing):
                    for k, v in (x_struct_local or {}).items():
                        if (
                            var_name == str(v[1].name)
                            if isinstance(v, list) and len(v) > 1
                            else False
                        ):
                            setattr(self, str(v[1].name), getattr(wing, var_name))
                            idx = list((x_struct_local or {}).keys()).index(k)
                            self.xstruct[idx] = getattr(wing, var_name)

        elif mode == "global" and update_value is not None:
            for wing in comp:
                for var_name in vars(wing):
                    for k, v in (x_struct_local or {}).items():
                        if (
                            var_name == str(v[1].name)
                            if isinstance(v, list) and len(v) > 1
                            else False
                        ):
                            idx = list((x_struct_local or {}).keys()).index(k)
                            setattr(self, str(v[1].name), update_value[idx])

    def compute_mass(self) -> float:
        """Compute the total mass from Lagrange analysis.

        Returns:
            The computed mass value.
        """
        if self._lagrange_instance is not None:
            return float(self._lagrange_instance.get_od_f())
        return 0.0


def Driver(
    wings: list[Wing],
    environment: assembly.Environment | None,
    propellers: list[Propeller] | None = None,
    fuselages: list[Fuselage] | None = None,
    options: LagrangeOptions | None = None,
) -> LagrangeDriver:
    """Factory function to create Lagrange driver.

    Args:
        wings: List of wing components.
        environment: The environment component.
        options: Lagrange solver options.
        propellers: Optional list of propeller components.
        fuselages: Optional list of fuselage components.

    Returns:
        LagrangeDriver instance.
    """
    if environment is None:
        environment = assembly.Environment(name="default", height=1000.0, speed=100.0)
    return LagrangeDriver(
        environment=environment,
        wings=wings,
        propellers=propellers,
        fuselages=fuselages,
        options=options,

    )


LAGRANGE = LagrangeDriver
