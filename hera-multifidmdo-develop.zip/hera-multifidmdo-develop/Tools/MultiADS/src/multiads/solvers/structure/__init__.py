"""Structure solvers for MultiADS.

This module provides structural analysis capabilities including the Lagrange
and MBDyn structural solvers.
"""

from multiads.solvers.structure.Lagrange import LAGRANGE, mass
from multiads.solvers.structure.Lagrange_lib import (
    Driver,
    Driver as LagrangeDriverFactory,
    Fuselage,
    LagrangeDriver,
    LagrangeOptions,
    LagrangePostLoads,
    MovableSurface,
    Propeller,
    Section,
    Span,
    Wing,
)
from multiads.solvers.structure.mbdyn import MBDYN
from multiads.solvers.structure.mbdyn_lib import (
    DUSTMBDYN,
    Driver as MBDYNDriverFactory,
    DriverDUSTMBDYN,
    DUSTMBDYNOptions,
    MBDYNDriver,
    MBDYNOptions,
    MBDYNPostDeform,
    SolverMode,
    WingMBDYN,
)

__all__ = [
    # Lagrange solver
    "LAGRANGE",
    "mass",
    "LagrangeDriverFactory",
    "Driver",  # Lagrange Driver factory
    "Fuselage",
    "LagrangeDriver",
    "LagrangeOptions",
    "LagrangePostLoads",
    "MovableSurface",
    "Propeller",
    "Section",
    "Span",
    "Wing",
    # MBDyn solver
    "MBDYN",
    "DUSTMBDYN",
    "MBDYNDriverFactory",  # MBDyn Driver factory
    "DriverDUSTMBDYN",
    "DUSTMBDYNOptions",
    "MBDYNDriver",
    "MBDYNOptions",
    "MBDYNPostDeform",
    "SolverMode",
    "WingMBDYN",
]
