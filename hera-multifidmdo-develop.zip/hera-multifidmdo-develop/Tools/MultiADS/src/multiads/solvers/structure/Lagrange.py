"""Lagrange structural solver for MultiADS.

This solver provides structural analysis capabilities using the Lagrange
structural solver. It supports mass computation and structural optimization.
"""

from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

import multiads.solvers.structure.Lagrange_lib as ll
from multiads.assembly import (
    Environment,
    Fuselage,
    MADSComponent,
    Propeller,
    Wing,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import (
    InnerVariable,
    InnerVariableFloat,
    InnerVariableFloatNP,
)
from multiads.solvers import BaseSolver

if TYPE_CHECKING:
    from collections.abc import Sequence


class LAGRANGE(BaseSolver):
    """Lagrange structural solver.

    This solver provides structural analysis using the Lagrange structural
    solver, supporting mass computation and structural optimization.

    Attributes:
        options: Solver options.
        driver: The Lagrange driver instance.
        environment: The environment component.
        wings: List of wing components.
        propellers: List of propeller components.
        fuselages: List of fuselage components.
        outputs_map: Mapping of output variable names to variables.
        run_directory: Temporary directory for solver execution.

    """

    def __init__(self, options: ll.LagrangeOptions | None = None) -> None:
        """Initialize the Lagrange solver.

        Args:
            options: Optional Lagrange solver options. If None, uses defaults.

        """
        super().__init__()
        self.options: ll.LagrangeOptions = options or ll.LagrangeOptions()
        self.driver: ll.LagrangeDriver | None = None
        self.environment: Environment | None = None
        self.wings: Sequence[ll.Wing] | None = None
        self.propellers: Sequence[ll.Propeller] | None = None
        self.fuselages: Sequence[ll.Fuselage] | None = None
        self.outputs_map: dict[str, InnerVariable] | None = None
        self.run_directory: Path | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv: Any,
    ) -> Sequence[MADSComponent]:
        """Parse and extract components from the input.

        Args:
            components: Sequence of MADS components.
            *argv: Additional arguments (unused).

        Returns:
            List of components after parsing.

        """
        _components = copy_components(components)
        comp_flat = flatten_components(_components)

        wings = [c for c in comp_flat if type(c) is Wing]
        propellers = [c for c in comp_flat if type(c) is Propeller]
        fuselages = [c for c in comp_flat if type(c) is Fuselage]

        try:
            environment = next(c for c in comp_flat if type(c) is Environment)
        except StopIteration:
            environment = None

        wings_mapped = [ll.Wing.from_component(w) for w in wings]
        propellers_mapped = [ll.Propeller.from_component(p) for p in propellers]
        fuselages_mapped = [ll.Fuselage.from_component(f) for f in fuselages]

        self.environment = environment
        self.wings = wings_mapped
        self.propellers = propellers_mapped
        self.fuselages = fuselages_mapped

        self.outputs = self._create_output_variables(wings_mapped)
        self.outputs_map = {v.name: v for v in self.outputs}

        result = (
            [environment, *wings, *propellers, *fuselages]
            if environment
            else [
                *wings,
                *propellers,
                *fuselages,
            ]
        )
        return result

    def _create_output_variables(
        self,
        wings: Sequence[ll.Wing],
    ) -> list[InnerVariable]:
        """Create output variables for the solver.

        Args:
            wings: List of wing components.

        Returns:
            List of output variables.

        """
        outputs: list[InnerVariable] = []

        for wing in wings:
            outputs.append(InnerVariableFloatNP(f"{wing.name}.mass", np.zeros(1)))
            if wing.xstruct:
                outputs.append(InnerVariableFloat(f"{wing.name}.x_struct_opt", 0.0))

        return outputs

    def set_state(self, components: Sequence[MADSComponent]) -> None:
        """Set the state of the solver with current component values.

        Args:
            components: Sequence of MADS components.

        """
        if self.wings is None:
            msg = f"Components of solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        local_components = list(self.wings)
        for comp in components:
            for l_comp in local_components:
                if comp.name == l_comp.name:
                    l_comp.update(comp)

        self.options.work_dir.mkdir(parents=True, exist_ok=True)
        self.run_directory = Path(
            tempfile.mkdtemp(
                dir=self.options.work_dir,
                prefix=self.options.name,
            ),
        )

    def _run(self) -> None:
        """Execute the Lagrange structural analysis."""
        if self.wings is None:
            msg = f"The solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        main_dir = Path.cwd()
        os.chdir(self.run_directory)

        self.driver = ll.Driver(
            environment=self.environment,
            wings=list(self.wings),
            propellers=list(self.propellers) if self.propellers else None,
            fuselages=list(self.fuselages) if self.fuselages else None,
            options=self.options,
        )

        self.driver.preprocess()
        self.driver.run()
        self.driver.postprocess()

        os.chdir(main_dir)

    def compute_output(self) -> None:
        """Compute and store solver outputs."""
        if self.wings is None:
            msg = f"Components of solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        if self.outputs is None or self.outputs_map is None:
            msg = f"The interface of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.driver is None or self.run_directory is None:
            msg = f"Solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        for wing in self.wings:
            mass_var = self.outputs_map.get(f"{wing.name}.mass")
            if mass_var is not None:
                mass_var.value[0] = self.driver.compute_mass()

            if wing.xstruct:
                x_struct_var = self.outputs_map.get(f"{wing.name}.x_struct_opt")
                if x_struct_var is not None:
                    x_struct_var.value = self.driver.x_struct_opt

        shutil.rmtree(self.run_directory)

    def compute_sensitivities(
        self,
        input_names: Sequence[str],
        inputs: Sequence[Any],
        output_names: Sequence[str],
        outputs: Sequence[Any],
    ) -> dict[str, Any]:
        """Compute Jacobian matrix for sensitivities.

        Args:
            input_names: Names of input variables.
            inputs: Input variable values.
            output_names: Names of output variables.
            outputs: Output variable values.

        Returns:
            Dictionary of Jacobian matrices.

        """
        return {}


def mass(
    name: str,
    driver: ll.LAGRANGE,
    **kwargs: Any,
) -> np.ndarray:
    """Compute mass output from Lagrange driver.

    Args:
        name: Variable name (unused).
        driver: The Lagrange driver instance.
        **kwargs: Additional keyword arguments (unused).

    Returns:
        Array containing the mass value.

    """
    m = driver.compute_mass()
    return np.asarray([m])
