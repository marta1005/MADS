"""MBDyn structural solver library.

This module provides structural analysis capabilities using MBDyn solver,
either standalone or coupled with DUST via preCICE for aeroelastic simulations.
"""

from __future__ import annotations

import logging
import os
import subprocess as sp
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from multiads import assembly
from multiads.solvers.aerodynamics.dust_lib import (
    Driver as BaseDriver,
    MovableSurface,
    Options as BaseOptions,
    PostLoads,
    Wing as BaseWing,
    _log_cmd_output,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


class SolverMode(Enum):
    COUPLED = "coupled"
    STANDALONE = "standalone"


@dataclass
class MBDYNOptions:
    name: str = "mbdyn"
    mbdyn_command: str = "mbdyn"
    mbdyn_model: str = "wing.mbd"
    mbdyn_output: str = "Output"
    dt: float = 0.001
    t_end: float = 2.0
    work_dir: Path = Path(".")


class DUSTMBDYNOptions(BaseOptions):
    def __init__(
        self,
        *,
        name: str = "dustmbdyn",
        solver_mode: SolverMode = SolverMode.COUPLED,
        structure_dir: str | Path = "structure",
        coupling_command: str = "",
        preCICE_config: str = "precice-config.xml",
        mbdyn_model: str = "wing.mbd",
        mbdyn_output: str = "Output",
        mbdyn_command: str = "mbdyn",
        mbdyn_dt: float = 0.001,
        mbdyn_t_end: float = 2.0,
        **kwargs: Any,
    ) -> None:
        super().__init__(name=name, **kwargs)
        self.solver_mode = solver_mode
        self.structure_dir = Path(structure_dir)
        self.coupling_command = coupling_command
        self.preCICE_config = preCICE_config
        self.mbdyn_model = mbdyn_model
        self.mbdyn_output = mbdyn_output
        self.mbdyn_command = mbdyn_command
        self.mbdyn_dt = mbdyn_dt
        self.mbdyn_t_end = mbdyn_t_end


class WingMBDYN(BaseWing):
    def __init__(
        self,
        *args: Any,
        beam_nodes: NDArray[np.float64] | None = None,
        structural_massproperties: NDArray[np.float64] | None = None,
        structural_stiffnessmatrix: NDArray[np.float64] | None = None,
        undeformed_spans: list[float] | None = None,
        undeformed_dihed: list[float] | None = None,
        undeformed_twists: list[float] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.beam_nodes = beam_nodes
        self.structural_massproperties = structural_massproperties
        self.structural_stiffnessmatrix = structural_stiffnessmatrix
        self.undeformed_spans = undeformed_spans
        self.undeformed_dihed = undeformed_dihed
        self.undeformed_twists = undeformed_twists

    @classmethod
    def from_component(cls, comp: assembly.Wing) -> WingMBDYN:
        wing = super().from_component(comp)
        wing.beam_nodes = getattr(comp, "beam_nodes", None)
        wing.structural_massproperties = getattr(
            comp, "structural_massproperties", None
        )
        wing.structural_stiffnessmatrix = getattr(
            comp, "structural_stiffnessmatrix", None
        )
        wing.undeformed_spans = getattr(comp, "undeformed_spans", None)
        wing.undeformed_dihed = getattr(comp, "undeformed_dihed", None)
        wing.undeformed_twists = getattr(comp, "undeformed_twists", None)
        return wing

    def _write_coupling_block(self, f) -> None:
        if not hasattr(self, "beam_nodes") or self.beam_nodes is None:
            return

        f.writelines(
            [
                "coupled = T\n",
                "coupling_type = rbf\n",
                "coupling_node_file = refConfigNodes.in\n",
                "coupling_node_orientation = (/ 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 /)\n",
            ],
        )

    def write_file(self, wing_file: Path) -> None:
        with wing_file.open("w") as f:
            f.writelines(self._make_header())
            f.writelines(self._make_global_props())
            self._write_coupling_block(f)
            f.writelines(self._make_sections())


class MBDYNPostDeform(PostLoads):
    def __init__(
        self,
        wings: list[WingMBDYN] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.wings = wings or []

    def read_nc_file(self, file_name: Path) -> None:
        try:
            import netCDF4 as nc  # type: ignore
        except ImportError:
            msg = "netCDF4 is required for MBDyn post-processing"
            raise ImportError(msg) from None

        dataset = nc.Dataset(str(file_name), "r")

        displacements: list[NDArray] = []
        rotations: list[NDArray] = []

        for wing in self.wings:
            if (
                wing.structural_massproperties is not None
                and wing.structural_massproperties.reshape(-1, 10).shape[0] > 0
            ):
                nnodes = wing.structural_massproperties.reshape(-1, 10).shape[0]

                for i_node in range(1, nnodes + 1):
                    var_x = f"node.struct.{i_node}.X"
                    var_phi = f"node.struct.{i_node}.Phi"

                    node_disp = dataset.variables[var_x][:]
                    node_rot = dataset.variables[var_phi][:]
                    displacements.append(node_disp)
                    rotations.append(node_rot)

        dataset.close()

        self.displ = np.array(displacements)
        self.rot = np.array(rotations)


class DriverDUSTMBDYN(BaseDriver):
    def __init__(
        self,
        environment: assembly.Environment,
        wings: list[WingMBDYN],
        propellers: list[Any] | None = None,
        fuselages: list[Any] | None = None,
        options: DUSTMBDYNOptions | None = None,
    ) -> None:
        super().__init__(
            environment=environment,
            wings=wings,
            propellers=propellers or [],
            fuselages=fuselages or [],
            options=options,
        )

    def preprocess(self) -> None:
        super().preprocess()

        self.options.structure_dir.mkdir(parents=True, exist_ok=True)

        self._setup_structural_wings()
        self._write_coupling_nodes()
        self._write_mbdyn()
        self._write_precice_config()
        self._write_main()

    def _setup_structural_wings(self) -> None:
        for wing in self.wings:
            if (
                wing.structural_massproperties is not None
                and wing.structural_massproperties.reshape(-1, 10).shape[0] > 0
            ):
                wing.structural_massproperties = wing.structural_massproperties.reshape(
                    -1, 10
                )
                wing.structural_stiffnessmatrix = (
                    wing.structural_stiffnessmatrix.reshape(-1, 21)
                    if wing.structural_stiffnessmatrix is not None
                    else None
                )

                wing.beam_nodes = np.zeros((wing.structural_massproperties.shape[0], 3))
                wing.beam_nodes[:, 1] = wing.structural_massproperties[:, 2]

    def _write_coupling_nodes(self) -> None:
        with Path("refConfigNodes.in").open("w") as f:
            for wing in self.wings:
                if wing.beam_nodes is not None and wing.beam_nodes.size > 0:
                    for row in wing.beam_nodes:
                        f.write(f"{row[0]:8.4f}{row[1]:8.4f}{row[2]:8.4f}\n")

    def run(self) -> None:
        self.run_coupled()

    def run_coupled(self) -> None:
        logger = logging.getLogger(__name__)
        logger.info("dustmbdyn :: started")

        main_dir = Path.cwd()
        os.chdir(self.options.work_dir)

        command = self.options.coupling_command

        if command:
            out = sp.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
            )
            _log_cmd_output(
                Path(self.options.name + ".log"),
                out,
                "dustmbdyn",
                mode="a",
            )

        os.chdir(main_dir)
        logger.info("dustmbdyn :: finished")

    def postprocess(self, analyses: list[MBDYNPostDeform] | None = None) -> None:
        main_dir = Path.cwd()
        os.chdir(self.options.structure_dir)

        if analyses:
            self._read_nc(analyses)

        os.chdir(main_dir)

    def _read_nc(self, analyses: list[MBDYNPostDeform]) -> None:
        for analysis in analyses:
            analysis.read_nc_file(Path(self.options.mbdyn_output + ".nc"))

    def _write_mbdyn(self) -> None:
        for wing in self.wings:
            if wing.beam_nodes is None or wing.beam_nodes.size == 0:
                continue

            nodes = wing.beam_nodes
            nel = len(nodes) - 1
            l_total = sum(
                abs(nodes[i + 1][1] - nodes[i][1]) for i in range(len(nodes) - 1)
            )

            with Path("wing.mbd").open("w") as f:
                f.writelines(self._mbdyn_header(nel, l_total))
                f.writelines(self._mbdyn_nodes(nodes))
                f.writelines(self._mbdyn_elements(wing, nodes, nel))

    def _mbdyn_header(self, nel: int, l_total: float) -> list[str]:
        return [
            "# === data ======================================================\n",
            "begin: data;\n",
            "  problem: initial value;\n",
            "end: data;\n",
            f"set: const real dt = {self.options.mbdyn_dt:.6f};\n",
            f"set: const real t_end = {self.options.mbdyn_t_end:.6f};\n",
            "set: const real t_start = 0.000000;\n",
            "# === initial value problem =====================================\n",
            "begin: initial value;\n",
            "  initial time: t_start;\n",
            "  final time: t_end;\n",
            "  time step: dt;\n",
            "  max iterations: 250;\n",
            "  tolerance: 1.000000e-02;\n",
            "  derivatives tolerance: 1e-3;\n",
            "  derivatives max iterations: 100;\n",
            "  derivatives coefficient: 1.000000e-03, auto, max iterations, 100, factor, 3.0;\n",
            "  linear solver: naive, colamd, pivot factor, 1e-5;\n",
            "  method: ms, cosine, 0., pi/0.01, 0.6/2, half, 0.;\n",
            "  output: counter;\n",
            "end: initial value;\n",
            "# === variable definitions =======================================\n",
            "set: integer curr_elem;\n",
            "set: const integer GROUND = 0;\n",
            f"set: integer Nel = {nel};\n",
            f"set: real L = {l_total:.6f};\n",
            "set: real Chord = 3;\n",
            "set: real M = 217.74912;\n",
            "set: real dL = L / Nel;\n",
            "set: real m = M / L;\n",
            "set: real j = 7.452;\n",
            "set: real EA  = 1.e+10;\n",
            "set: real GAy = 1.e+10;\n",
            "set: real GAz = 1.e+10;\n",
            "set: real GJ  = 1.88e+7;\n",
            "set: real EJy = 9.77e+6;\n",
            "set: real EJz = 9.77e+7;\n",
            "set: real CA_location = 25;\n",
            "set: real EA_location = 33;\n",
            "set: real CG_location = 43;\n",
            "set: real Off_CA = (CA_location - EA_location) * Chord / 100;\n",
            "set: real Off_CG = (CG_location - EA_location) * Chord / 100;\n",
            "set: const integer naca0012 = 1;\n",
            "# === control data ===============================================\n",
            "begin: control data;\n",
            "  structural nodes: +1\n",
            "                    +Nel;\n",
            "  rigid bodies:     +Nel+1;\n",
            "  joints:           +1;\n",
            "  beams:            +Nel;\n",
            "  forces:           +1;\n",
            "  default output: reference frames;\n",
            "  default orientation: orientation vector;\n",
            "  output results: netcdf, classic, sync;\n",
            "end: control data;\n",
        ]

    def _mbdyn_nodes(self, nodes: NDArray) -> list[str]:
        lines = [
            "reference: GROUND,\n",
            " reference, global, null,\n",
            " reference, global, eye,\n",
            " reference, global, null,\n",
            " reference, global, null;\n\n",
            "begin: nodes;\n",
            " structural: 0, dynamic,\n",
            " reference, GROUND, null,\n",
            " reference, GROUND, eye,\n",
            " reference, GROUND, null,\n",
            " reference, GROUND, null,\n",
            " output, no;\n",
        ]

        for i, (x, y, z) in enumerate(nodes[1:], start=1):
            lines.extend(
                [
                    f" structural: {i}, dynamic,\n",
                    f" reference, GROUND, {x:.4f}, {y:.4f}, {z:.4f},\n",
                    " reference, GROUND, eye,\n",
                    " reference, GROUND, null,\n",
                    " reference, GROUND, null;\n",
                ],
            )

        lines.append("end: nodes;\n\n")
        return lines

    def _mbdyn_elements(
        self,
        wing: WingMBDYN,
        nodes: NDArray,
        nel: int,
    ) -> list[str]:
        lines = ["begin: elements;\n"]

        dL_1 = np.linalg.norm(nodes[1] - nodes[0])
        if dL_1 < 1e-6:
            dL_1 = 1

        m_1 = wing.structural_massproperties[0, 0] / dL_1
        j_1 = -wing.structural_massproperties[0, 5] * 1e-6 / dL_1

        lines.extend(
            [
                f" body: 0, 0,\n",
                f" ({dL_1}/2.)*{m_1},\n",
                f"  reference, node, Off_CG, {dL_1}/4, 0.0,\n",
                f"  diag, 1./12.*({dL_1}/2.)^3*{m_1}, ({dL_1}/2.)*{j_1}, 1./12.*({dL_1}/2.)^3*{m_1};\n\n",
            ],
        )

        for e in range(1, nel + 1):
            dL_i = np.linalg.norm(nodes[e] - nodes[e - 1])
            if dL_i < 1e-6:
                dL_i = 1

            m_i = wing.structural_massproperties[e - 1, 0] / dL_i
            j_i = -wing.structural_massproperties[e - 1, 5] / dL_i

            if wing.structural_stiffnessmatrix is not None:
                ea_i = wing.structural_stiffnessmatrix[e - 1, 6]
                gax_i = wing.structural_stiffnessmatrix[e - 1, 11]
                gaz_i = wing.structural_stiffnessmatrix[e - 1, 20]
                gj_i = wing.structural_stiffnessmatrix[e - 1, 18]
                ejx_i = -wing.structural_stiffnessmatrix[e - 1, 8]
                ejz_i = wing.structural_stiffnessmatrix[e - 1, 10]
            else:
                ea_i = 1.0e10
                gax_i = 1.0e10
                gaz_i = 1.0e10
                gj_i = 1.88e7
                ejx_i = 9.77e6
                ejz_i = 9.77e7

            lines.extend(
                [
                    f" body: {e}, {e},\n",
                    f" ({dL_i})*{m_i},\n",
                    "  reference, node, Off_CG, 0.0, 0.0,\n",
                    f"  diag, 1./12.*({dL_i})^3*{m_i}, ({dL_i})*{j_i}, 1./12.*({dL_i})^3*{m_i};\n\n",
                    f" beam2: {e}, {e - 1}, reference, node, null, {e}, reference, node, null,\n",
                    "  eye,\n",
                    "  linear time variant viscoelastic generic,\n",
                    f"  diag, {ea_i}, 1./(1./{gax_i}+{dL_i}^2/12./{ejz_i}), 1./(1./{gaz_i}+{dL_i}^2/12./{ejx_i}), {gj_i}, {ejx_i}, {ejz_i},\n",
                    "  const, 1.,\n",
                    "  diag, 0,0,0,\n",
                    f"        0, 0, 3e-3*{gj_i},\n",
                    "  const, 1;\n\n",
                ],
            )

        lines.extend(
            [
                "joint: GROUND, clamp, 0, node, node;\n",
                "force: 9, external structural,\n",
                "socket,\n",
                "  create, yes,\n",
                '  path, "$MBSOCK",\n',
                "  no signal,\n",
                "coupling, tight,\n",
                "sorted, yes,\n",
                "orientation, orientation vector,\n",
                "accelerations, yes,\n",
                f" {nel + 1},\n",
                " " + ",".join(str(i) for i in range(nel + 1)) + ";\n",
                "end: elements;\n\n",
            ],
        )

        return lines

    def _write_precice_config(self) -> None:
        with Path("precice-config.xml").open("w") as f:
            f.writelines(
                [
                    '<?xml version="1.0"?>\n',
                    "<precice-configuration>\n",
                    "<log>\n",
                    "    <sink\n",
                    '      filter="(%Severity% > error)"\n',
                    '      format="\\033[0;33m ▶ in progress ▶ %ColorizedSeverity% %Message%"\n',
                    '      enabled="true" /></log>\n',
                    '  <solver-interface dimensions="3">\n',
                    "    <!-- === Data =========================================== -->\n",
                    '    <data:vector name="Position" />\n',
                    '    <data:vector name="Rotation" />\n',
                    '    <data:vector name="Velocity" />\n',
                    '    <data:vector name="AngularVelocity" />\n',
                    '    <data:vector name="Force" />\n',
                    '    <data:vector name="Moment" />\n',
                    "    <!-- === Mesh =========================================== -->\n",
                    '    <mesh name="MBDynNodes">\n',
                    '      <use-data name="Position" />\n',
                    '      <use-data name="Rotation" />\n',
                    '      <use-data name="Velocity" />\n',
                    '      <use-data name="AngularVelocity" />\n',
                    '      <use-data name="Force" />\n',
                    '      <use-data name="Moment" />\n',
                    "    </mesh>\n",
                    '    <mesh name="dust_mesh">\n',
                    '      <use-data name="Position" />\n',
                    '      <use-data name="Rotation" />\n',
                    '      <use-data name="Velocity" />\n',
                    '      <use-data name="AngularVelocity" />\n',
                    '      <use-data name="Force" />\n',
                    '      <use-data name="Moment" />\n',
                    "    </mesh>\n",
                    "    <!-- === Participants =================================== -->\n",
                    '    <participant name="MBDyn">\n',
                    '      <use-mesh   name="MBDynNodes" provide="yes"/>\n',
                    '      <write-data name="Position"        mesh="MBDynNodes" />\n',
                    '      <write-data name="Rotation"        mesh="MBDynNodes" />\n',
                    '      <write-data name="Velocity"        mesh="MBDynNodes" />\n',
                    '      <write-data name="AngularVelocity" mesh="MBDynNodes" />\n',
                    '      <read-data  name="Force"           mesh="MBDynNodes" />\n',
                    '      <read-data  name="Moment"          mesh="MBDynNodes" />\n',
                    "    </participant>\n",
                    '    <participant name="dust">\n',
                    '      <use-mesh   name="dust_mesh"  provide="yes" />\n',
                    '      <use-mesh   name="MBDynNodes" from="MBDyn" />\n',
                    '      <write-data name="Force"           mesh="dust_mesh" />\n',
                    '      <write-data name="Moment"          mesh="dust_mesh" />\n',
                    '      <read-data  name="Position"        mesh="dust_mesh" />\n',
                    '      <read-data  name="Rotation"        mesh="dust_mesh" />\n',
                    '      <read-data  name="Velocity"        mesh="dust_mesh" />\n',
                    '      <read-data  name="AngularVelocity" mesh="dust_mesh" />\n',
                    '      <mapping:nearest-neighbor direction="read"  from="MBDynNodes" to="dust_mesh"\n',
                    '        constraint="consistent" />\n',
                    '      <mapping:nearest-neighbor direction="write" from="dust_mesh"  to="MBDynNodes"\n',
                    '        constraint="conservative" />\n',
                    "    </participant>\n",
                    "    <!-- === Communication ================================== -->\n",
                    '    <m2n:sockets exchange-directory="./../" from="MBDyn" to="dust"/>\n',
                    "    <!-- === Coupling scheme ================================ -->\n",
                    "    <coupling-scheme:serial-implicit>\n",
                    '      <participants first="MBDyn" second="dust" />\n',
                    '      <max-time value="100.0" />\n',
                    '      <time-window-size value="-1" valid-digits="10" method="first-participant" />\n',
                    '      <exchange data="Position"        from="MBDyn" mesh="MBDynNodes" to="dust" />\n',
                    '      <exchange data="Rotation"        from="MBDyn" mesh="MBDynNodes" to="dust" />\n',
                    '      <exchange data="Velocity"        from="MBDyn" mesh="MBDynNodes" to="dust" />\n',
                    '      <exchange data="AngularVelocity" from="MBDyn" mesh="MBDynNodes" to="dust" />\n',
                    '      <exchange data="Force"           from="dust"  mesh="MBDynNodes" to="MBDyn" />\n',
                    '      <exchange data="Moment"          from="dust"  mesh="MBDynNodes" to="MBDyn" />\n',
                    '      <max-iterations value="100"/>\n',
                    '      <min-iteration-convergence-measure min-iterations="1" data="Moment" mesh="MBDynNodes"/>\n',
                    '      <relative-convergence-measure limit="1.0e-8" data="Position" mesh="MBDynNodes" />\n',
                    '      <relative-convergence-measure limit="1.0e-8" data="Rotation" mesh="MBDynNodes" />\n',
                    '      <relative-convergence-measure limit="1.0e-8" data="Velocity" mesh="MBDynNodes" />\n',
                    '      <relative-convergence-measure limit="1.0e-8" data="AngularVelocity" mesh="MBDynNodes" /> \n',
                    "      <acceleration:aitken>\n",
                    '        <data name="Force" mesh="MBDynNodes"/>\n',
                    '        <initial-relaxation value="0.1"/>\n',
                    "      </acceleration:aitken>\n",
                    "    </coupling-scheme:serial-implicit>\n",
                    "  </solver-interface>\n",
                    "</precice-configuration>\n",
                ],
            )

    def _write_main(self) -> None:
        with Path("main.py").open("w") as f:
            f.writelines(
                [
                    "import os\n",
                    "# Add coupling execution logic here\n",
                    "# This is a placeholder - implement based on your infrastructure\n",
                    "print('DUST-MBDyn coupling simulation')\n",
                ],
            )


class MBDYNDriver:
    def __init__(
        self,
        wings: list[WingMBDYN],
        options: MBDYNOptions,
    ) -> None:
        self.wings = wings
        self.options = options
        self.displ: NDArray[np.float64] | None = None
        self.rot: NDArray[np.float64] | None = None

    def preprocess(self) -> None:
        self.options.work_dir.mkdir(parents=True, exist_ok=True)

        main_dir = Path.cwd()
        os.chdir(self.options.work_dir)

        self._setup_structural_wings()
        self._write_mbdyn()

        os.chdir(main_dir)

    def _setup_structural_wings(self) -> None:
        for wing in self.wings:
            if (
                wing.structural_massproperties is not None
                and wing.structural_massproperties.reshape(-1, 10).shape[0] > 0
            ):
                wing.structural_massproperties = wing.structural_massproperties.reshape(
                    -1, 10
                )
                wing.structural_stiffnessmatrix = (
                    wing.structural_stiffnessmatrix.reshape(-1, 21)
                    if wing.structural_stiffnessmatrix is not None
                    else None
                )

                wing.beam_nodes = np.zeros((wing.structural_massproperties.shape[0], 3))
                wing.beam_nodes[:, 1] = wing.structural_massproperties[:, 2]

    def run(self) -> None:
        logger = logging.getLogger(__name__)
        logger.info("mbdyn :: started")

        main_dir = Path.cwd()
        os.chdir(self.options.work_dir)

        command = (
            f"{self.options.mbdyn_command} "
            f"-f {self.options.mbdyn_model} "
            f"-o {self.options.mbdyn_output}"
        )

        out = sp.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
        )
        _log_cmd_output(
            Path(self.options.name + ".log"),
            out,
            "mbdyn",
            mode="a",
        )

        os.chdir(main_dir)
        logger.info("mbdyn :: finished")

    def postprocess(self, analyses: list[MBDYNPostDeform] | None = None) -> None:
        main_dir = Path.cwd()
        os.chdir(self.options.work_dir)

        if analyses:
            self._read_nc(analyses)

        os.chdir(main_dir)

    def _read_nc(self, analyses: list[MBDYNPostDeform]) -> None:
        for analysis in analyses:
            analysis.read_nc_file(Path(self.options.mbdyn_output + ".nc"))
            self.displ = analysis.displ
            self.rot = analysis.rot

    def _write_mbdyn(self) -> None:
        for wing in self.wings:
            if wing.beam_nodes is None or wing.beam_nodes.size == 0:
                continue

            nodes = wing.beam_nodes
            nel = len(nodes) - 1
            l_total = sum(
                abs(nodes[i + 1][1] - nodes[i][1]) for i in range(len(nodes) - 1)
            )

            with Path(self.options.mbdyn_model).open("w") as f:
                f.writelines(self._mbdyn_header(nel, l_total))
                f.writelines(self._mbdyn_nodes(nodes))
                f.writelines(self._mbdyn_elements(wing, nodes, nel))

    def _mbdyn_header(self, nel: int, l_total: float) -> list[str]:
        return [
            "# === data ======================================================\n",
            "begin: data;\n",
            "  problem: initial value;\n",
            "end: data;\n",
            f"set: const real dt = {self.options.dt:.6f};\n",
            f"set: const real t_end = {self.options.t_end:.6f};\n",
            "set: const real t_start = 0.000000;\n",
            "# === initial value problem =====================================\n",
            "begin: initial value;\n",
            "  initial time: t_start;\n",
            "  final time: t_end;\n",
            "  time step: dt;\n",
            "  max iterations: 250;\n",
            "  tolerance: 1.000000e-02;\n",
            "  derivatives tolerance: 1e-3;\n",
            "  derivatives max iterations: 100;\n",
            "  derivatives coefficient: 1.000000e-03, auto, max iterations, 100, factor, 3.0;\n",
            "  linear solver: naive, colamd, pivot factor, 1e-5;\n",
            "  method: ms, cosine, 0., pi/0.01, 0.6/2, half, 0.;\n",
            "  output: counter;\n",
            "end: initial value;\n",
            "# === variable definitions =======================================\n",
            "set: integer curr_elem;\n",
            "set: const integer GROUND = 0;\n",
            f"set: integer Nel = {nel};\n",
            f"set: real L = {l_total:.6f};\n",
            "set: real Chord = 3;\n",
            "set: real M = 217.74912;\n",
            "set: real dL = L / Nel;\n",
            "set: real m = M / L;\n",
            "set: real j = 7.452;\n",
            "set: real EA  = 1.e+10;\n",
            "set: real GAy = 1.e+10;\n",
            "set: real GAz = 1.e+10;\n",
            "set: real GJ  = 1.88e+7;\n",
            "set: real EJy = 9.77e+6;\n",
            "set: real EJz = 9.77e+7;\n",
            "set: real CA_location = 25;\n",
            "set: real EA_location = 33;\n",
            "set: real CG_location = 43;\n",
            "set: real Off_CA = (CA_location - EA_location) * Chord / 100;\n",
            "set: real Off_CG = (CG_location - EA_location) * Chord / 100;\n",
            "set: const integer naca0012 = 1;\n",
            "# === control data ===============================================\n",
            "begin: control data;\n",
            "  structural nodes: +1\n",
            "                    +Nel;\n",
            "  rigid bodies:     +Nel+1;\n",
            "  joints:           +1;\n",
            "  beams:            +Nel;\n",
            "  forces:           +0;\n",
            "  default output: reference frames;\n",
            "  default orientation: orientation vector;\n",
            "  output results: netcdf, classic, sync;\n",
            "end: control data;\n",
        ]

    def _mbdyn_nodes(self, nodes: NDArray) -> list[str]:
        lines = [
            "reference: GROUND,\n",
            " reference, global, null,\n",
            " reference, global, eye,\n",
            " reference, global, null,\n",
            " reference, global, null;\n\n",
            "begin: nodes;\n",
            " structural: 0, dynamic,\n",
            " reference, GROUND, null,\n",
            " reference, GROUND, eye,\n",
            " reference, GROUND, null,\n",
            " reference, GROUND, null,\n",
            " output, no;\n",
        ]

        for i, (x, y, z) in enumerate(nodes[1:], start=1):
            lines.extend(
                [
                    f" structural: {i}, dynamic,\n",
                    f" reference, GROUND, {x:.4f}, {y:.4f}, {z:.4f},\n",
                    " reference, GROUND, eye,\n",
                    " reference, GROUND, null,\n",
                    " reference, GROUND, null;\n",
                ],
            )

        lines.append("end: nodes;\n\n")
        return lines

    def _mbdyn_elements(
        self,
        wing: WingMBDYN,
        nodes: NDArray,
        nel: int,
    ) -> list[str]:
        lines = ["begin: elements;\n"]

        dL_1 = np.linalg.norm(nodes[1] - nodes[0])
        if dL_1 < 1e-6:
            dL_1 = 1

        m_1 = wing.structural_massproperties[0, 0] / dL_1
        j_1 = -wing.structural_massproperties[0, 5] * 1e-6 / dL_1

        lines.extend(
            [
                f" body: 0, 0,\n",
                f" ({dL_1}/2.)*{m_1},\n",
                f"  reference, node, Off_CG, {dL_1}/4, 0.0,\n",
                f"  diag, 1./12.*({dL_1}/2.)^3*{m_1}, ({dL_1}/2.)*{j_1}, 1./12.*({dL_1}/2.)^3*{m_1};\n\n",
            ],
        )

        for e in range(1, nel + 1):
            dL_i = np.linalg.norm(nodes[e] - nodes[e - 1])
            if dL_i < 1e-6:
                dL_i = 1

            m_i = wing.structural_massproperties[e - 1, 0] / dL_i
            j_i = -wing.structural_massproperties[e - 1, 5] / dL_i

            if wing.structural_stiffnessmatrix is not None:
                ea_i = wing.structural_stiffnessmatrix[e - 1, 6]
                gax_i = wing.structural_stiffnessmatrix[e - 1, 11]
                gaz_i = wing.structural_stiffnessmatrix[e - 1, 20]
                gj_i = wing.structural_stiffnessmatrix[e - 1, 18]
                ejx_i = -wing.structural_stiffnessmatrix[e - 1, 8]
                ejz_i = wing.structural_stiffnessmatrix[e - 1, 10]
            else:
                ea_i = 1.0e10
                gax_i = 1.0e10
                gaz_i = 1.0e10
                gj_i = 1.88e7
                ejx_i = 9.77e6
                ejz_i = 9.77e7

            lines.extend(
                [
                    f" body: {e}, {e},\n",
                    f" ({dL_i})*{m_i},\n",
                    "  reference, node, Off_CG, 0.0, 0.0,\n",
                    f"  diag, 1./12.*({dL_i})^3*{m_i}, ({dL_i})*{j_i}, 1./12.*({dL_i})^3*{m_i};\n\n",
                    f" beam2: {e}, {e - 1}, reference, node, null, {e}, reference, node, null,\n",
                    "  eye,\n",
                    "  linear time variant viscoelastic generic,\n",
                    f"  diag, {ea_i}, 1./(1./{gax_i}+{dL_i}^2/12./{ejz_i}), 1./(1./{gaz_i}+{dL_i}^2/12./{ejx_i}), {gj_i}, {ejx_i}, {ejz_i},\n",
                    "  const, 1.,\n",
                    "  diag, 0,0,0,\n",
                    f"        0, 0, 3e-3*{gj_i},\n",
                    "  const, 1;\n\n",
                ],
            )

        lines.extend(
            [
                "joint: GROUND, clamp, 0, node, node;\n",
                "end: elements;\n\n",
            ],
        )

        return lines


def MBDYNDriverFactory(
    wings: list[WingMBDYN],
    environment: assembly.Environment | None,
    propellers: list[Any] | None = None,
    fuselages: list[Any] | None = None,
    options: DUSTMBDYNOptions | None = None,
) -> DriverDUSTMBDYN | MBDYNDriver:
    if options.solver_mode == SolverMode.STANDALONE:
        mbdyn_opts = MBDYNOptions(
            name=options.name,
            mbdyn_command=options.mbdyn_command,
            mbdyn_model=options.mbdyn_model,
            mbdyn_output=options.mbdyn_output,
            dt=options.mbdyn_dt,
            t_end=options.mbdyn_t_end,
            work_dir=options.structure_dir,
        )
        return MBDYNDriver(wings=wings, options=mbdyn_opts)

    if environment is None:
        msg = "Environment is required for coupled mode."
        raise ValueError(msg)

    return DriverDUSTMBDYN(
        environment=environment,
        wings=wings,
        options=options,
        propellers=propellers,
        fuselages=fuselages,
    )


DUSTMBDYN = DriverDUSTMBDYN
Driver = MBDYNDriverFactory
