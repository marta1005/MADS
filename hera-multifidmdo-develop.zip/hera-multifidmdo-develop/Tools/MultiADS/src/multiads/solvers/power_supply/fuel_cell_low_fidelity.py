from __future__ import annotations

from typing import TYPE_CHECKING, Any

from multiads.assembly import (
    Environment,
    FuelCell,
    MADSComponent,
    PowerManagSyst,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import BaseVariable, InnerVariable, InnerVariableFloat
from multiads.solvers import BaseSolver
from multiads.solvers.power_supply.fuel_cell_low_fidelity_lib import Driver, Options

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    import numpy as np
    from numpy.typing import NDArray


class FuelCellLowFidelity(BaseSolver):
    def __init__(self, options: Options | None = None) -> None:
        super().__init__()
        self.options: Options = options or Options()
        self.driver: Driver | None = None
        self.fuelcells: Sequence[FuelCell] | None = None
        self.powermanagement: PowerManagSyst | None = None
        self.outputs_map: dict[str, InnerVariable] | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv: Any,  # noqa: ANN401, ARG002
    ) -> Sequence[MADSComponent]:
        # Filter fuel cells
        _components = copy_components(components)
        c_flat = flatten_components(_components)

        self.fuelcells = [c for c in c_flat if isinstance(c, FuelCell)]

        try:
            self.powermanagement = next(
                c for c in c_flat if isinstance(c, PowerManagSyst)
            )
        except StopIteration:
            print(
                "warning...model 'FuelCellLowFidelity' using DEFAULT PowerManagSyst()",
            )
            self.powermanagement = PowerManagSyst(
                name="Default :: Power Management",
                type="Hybrid",
            )

        try:
            self.environment = next(c for c in c_flat if isinstance(c, Environment))
        except StopIteration:
            print("warning...model 'FuelCellLowFidelity' using DEFAULT Environment()")
            self.environment = Environment(
                name="Default :: Environment",
                height=0.0,
                speed=150.0,
            )

        # Extract variables
        inputs: list[BaseVariable] = []
        for fuelcell in self.fuelcells:
            if v := fuelcell.variables.get("power"):
                inputs.append(v)

        outputs: list[InnerVariableFloat] = []
        for fuelcell in self.fuelcells:
            outputs.extend(
                [
                    InnerVariableFloat(f"{fuelcell.name}.mass", 0.0),
                    InnerVariableFloat(f"{fuelcell.name}.h2_fuel_flow", 0.0),
                    InnerVariableFloat(f"{fuelcell.name}.waste_heat", 0.0),
                ],
            )

        self.inputs = inputs
        self.outputs = outputs
        self.outputs_map = {v.name: v for v in self.outputs}

        return [self.environment, self.powermanagement, *self.fuelcells]

    def _run(self) -> None:
        if self.fuelcells is None or self.powermanagement is None:
            msg = f"Components in solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        self.driver = Driver(
            fuelcells=self.fuelcells,
            powermanag_sys=self.powermanagement,
            environment=self.environment,
            options=self.options,
        )
        self.driver.run()

    def compute_output(self) -> None:
        if self.fuelcells is None:
            msg = f"Components of solver '{type(self).__name__} are not initialized."
            raise RuntimeError(msg)

        if self.driver is None:
            msg = f"The driver of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.outputs is None or self.outputs_map is None:
            msg = f"The outputs of solver '{type(self).__name__} are not initialized"
            raise RuntimeError(msg)

        masses = self.driver.mass
        fuelflows = self.driver.h2_fuel_flow
        wasteheatfc = self.driver.waste_heat

        for i, fuelcell in enumerate(self.fuelcells):
            self.outputs_map[f"{fuelcell.name}.mass"].value = masses[i]
            self.outputs_map[f"{fuelcell.name}.h2_fuel_flow"].value = fuelflows[i]
            self.outputs_map[f"{fuelcell.name}.waste_heat"].value = wasteheatfc[i]

    def compute_sensitivities(
        self,
        input_names: Sequence[str],  # noqa: ARG002
        inputs: Sequence[BaseVariable],
        output_names: Sequence[str],  # noqa: ARG002
        outputs: Sequence[BaseVariable],  # noqa: ARG002
    ) -> Mapping[str, Mapping[str, NDArray]]:
        """Compute sensitivities of the inputs with respect to the outputs.

        Args:
            input_names ([type]): [description]
            inputs ([type]): [description]
            requested_outputs ([type]): [description]
            mapped_outputs ([type]): [description]

        Raises:
            ValueError: [description]

        Returns:
            [type]: [description]

        """
        if self.driver is None or self.outputs is None:
            msg = f"Solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        sensitivity = self.driver.get_sensitivity()
        jac: Mapping[str, Mapping[str, NDArray[np.float64]]] = {}
        for out in self.outputs:
            for inp in inputs:
                out_dict = jac.setdefault(out.name, {})
                try:
                    out_dict[inp] = sensitivity[out.name][inp.name]
                except KeyError:
                    msg = (
                        "'The Jacobian for the FuelCellLowFidelity is not computed "
                        f"for input '{inp}' and output '{out}' "
                    )
                    raise ValueError(msg) from None
        return jac
