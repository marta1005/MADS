from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from multiads.solvers import SolverOptions
from multiads.utilities.algebra import cosd, softmax

if TYPE_CHECKING:
    from multiads.assembly import Fuselage, Wing


@dataclass
class Options(SolverOptions):
    density: float = 1.225
    velocity: float = 100.0

    def __init__(
        self,
        *,
        length_tail_moment_arm: float = 0.0,
        wing_names_contributing_to_total_span: list[str] | None = None,
        m_tom: float | None = None,
        ultimate_load_factor: float | None = None,
        density: float = 1.225,
        velocity: float = 100.0,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.length_tail_moment_arm = length_tail_moment_arm
        self.wing_names_contributing_to_total_span = (
            wing_names_contributing_to_total_span or []
        )
        self.m_tom = m_tom
        self.ultimate_load_factor = ultimate_load_factor
        self.density = density
        self.velocity = velocity


@dataclass
class Wing:
    name: str
    ar: float
    tr: float
    area: float
    sweep_25: float
    spans: list
    sections: list
    fuel_mass_in_wing: float

    @classmethod
    def from_component(cls, comp: Wing) -> Wing:
        wing = cls(
            name=comp.name,
            ar=comp.aspect_ratio,
            tr=comp.taper_ratio,
            area=comp.area,
            sweep_25=comp.sweep_at_chord_station(0.25),
            spans=comp.spans,
            sections=comp.sections,
            fuel_mass_in_wing=comp.fuel_mass_in_wing,
        )
        if hasattr(comp, "options") and comp.options:
            for k, v in comp.options.get("raymer_mass", {}).items():
                if hasattr(wing, k):
                    setattr(wing, k, v)
        return wing


@dataclass
class Fuselage:
    wetted_area: float
    maximum_width: float
    maximum_height: float
    length: float
    volume_pressurized_cabin: float
    maximum_fuselage_pressure_differential: float

    @classmethod
    def from_component(cls, comp: Fuselage) -> Fuselage:
        fuselage = cls(
            wetted_area=comp.wetted_area,
            maximum_width=comp.maximum_width,
            maximum_height=comp.maximum_height,
            length=comp.length,
            volume_pressurized_cabin=comp.volume_pressurized_cabin,
            maximum_fuselage_pressure_differential=comp.maximum_fuselage_pressure_differential,
        )
        if hasattr(comp, "options") and comp.options:
            for k, v in comp.options.get("raymer_mass", {}).items():
                if hasattr(fuselage, k):
                    setattr(fuselage, k, v)
        return fuselage


class Driver:
    def __init__(
        self,
        wings: list[Wing],
        fuselage: Fuselage,
        options: Options,
    ) -> None:
        self.options = options
        self.wings = wings
        self.fuselage = fuselage
        self.wing_masses: list[float] = []
        self.fuselage_mass: float = 0.0
        self.total_mass: float = 0.0

    def run(self) -> None:
        self.wing_masses = []
        for wing in self.wings:
            wing_mass = self._compute_wing_mass(wing)
            self.wing_masses.append(wing_mass)

        self.fuselage_mass = self._compute_fuselage_mass()
        self.total_mass = sum(self.wing_masses) + self.fuselage_mass

    def _compute_wing_mass(self, wing: Wing) -> float:
        from multiads.utilities import units as u

        if wing.fuel_mass_in_wing > 0:
            fuel_weight_factor = softmax(
                (wing.fuel_mass_in_wing / u.lbm) ** 0.0035,
                1,
                hardness=1000,
            )
        else:
            fuel_weight_factor = 1.0

        section = wing.sections[0]
        thickness_to_chord_ratio = section.thickness_to_chord_ratio

        dynamic_pressure = 0.5 * self.options.density * self.options.velocity**2

        wing_mass = (
            0.036
            * (wing.area / u.foot**2) ** 0.758
            * fuel_weight_factor
            * (wing.ar / cosd(wing.sweep_25) ** 2) ** 0.6
            * (dynamic_pressure / u.psf) ** 0.006
            * wing.tr**0.04
            * (100 * thickness_to_chord_ratio / cosd(wing.sweep_25)) ** -0.3
            * (self.options.m_tom / u.lbm * self.options.ultimate_load_factor) ** 0.49
        ) * u.lbm

        return wing_mass

    def _compute_fuselage_mass(self) -> float:

        m2ft = 3.28084
        kg2lbs = 2.20462
        m32ft3 = 35.3147
        m22ft2 = 10.7639
        Pa2lb_ft2 = 0.02088547
        Pa2psi = 0.000145038

        fuselage_diameter = (
            (self.fuselage.maximum_height + self.fuselage.maximum_width) / 2 * m2ft
        )

        length_tail = self.options.length_tail_moment_arm * m2ft
        volume_cabin = self.fuselage.volume_pressurized_cabin * m32ft3
        length_fus = self.fuselage.length * m2ft
        weight = self.options.m_tom * kg2lbs
        wetted_area_fus = self.fuselage.wetted_area * m22ft2

        dynamic_pressure = 0.5 * self.options.density * self.options.velocity**2
        dynamic_pressure_psf = dynamic_pressure * Pa2lb_ft2

        max_pressure_diff_psi = (
            self.fuselage.maximum_fuselage_pressure_differential * Pa2psi
        )

        fuselage_mass_lb = (
            0.052
            * (wetted_area_fus**1.086)
            * ((self.options.ultimate_load_factor * weight) ** 0.177)
            * (length_tail**-0.051)
            * ((length_fus / fuselage_diameter) ** -0.072)
            * (dynamic_pressure_psf**0.241)
        )

        controls_mass_lb = (
            0.053
            * (length_fus**1.536)
            * (self._get_effective_span() * m2ft) ** 0.371
            * (self.options.ultimate_load_factor * weight * 1e-4) ** 0.8
        )

        pressurization_mass_lb = 11.9 * (volume_cabin * max_pressure_diff_psi) ** 0.271

        total_mass_lb = fuselage_mass_lb + controls_mass_lb + pressurization_mass_lb

        return total_mass_lb / kg2lbs

    def _get_effective_span(self) -> float:
        effective_span = 0.0
        for wing in self.wings:
            if wing.name in self.options.wing_names_contributing_to_total_span:
                if hasattr(wing, "spans") and wing.spans:
                    for span in wing.spans:
                        effective_span += span.length
                else:
                    effective_span += 0.0
        return effective_span
