"""
Physical Model for Environmental Control System (ECS)

This module provides a comprehensive physical model for aircraft Environmental Control Systems,
including:
- ISA atmospheric calculations
- Human and equipment heat loads
- Bleed air requirements
- Pack refrigeration cycle
- Ram air drag
- Mass and volume estimation
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def ISA_calc(height: float) -> tuple[float, float, float]:
    """Calculate ISA atmospheric conditions at given altitude.

    Args:
        height: Altitude in meters

    Returns:
        Tuple of (pressure [Pa], temperature [K], density [kg/m³])
    """
    if height < 0:
        raise ValueError("Height cannot be negative")
    
    # ISA sea level conditions
    P0 = 101325.0  # Pa
    T0 = 288.15    # K
    rho0 = 1.225   # kg/m³
    g = 9.80665    # m/s²
    R = 287.05     # J/(kg·K)
    L = 0.0065     # K/m (temperature lapse rate)
    
    # Troposphere (up to 11 km)
    if height <= 11000:
        T = T0 - L * height
        P = P0 * (1 - L * height / T0) ** (g / (R * L))
    # Stratosphere (11-20 km)
    elif height <= 20000:
        T = 216.65
        P = 22632 * np.exp(-g * (height - 11000) / (R * T))
    # Stratosphere (20-32 km)
    elif height <= 32000:
        T = 216.65 + (height - 20000) * 0.001
        P = 5474.9 * np.exp(-g * (height - 20000) / (R * T))
    else:
        raise ValueError("Height exceeds model range (>32 km)")
    
    rho = P / (R * T)
    
    return P, T, rho


def humanVent(
    crew: int,
    passengers: int,
    operational_engines: int,
    n_engines: int,
    margin: float = 10.0,
) -> float:
    """Calculate human ventilation air requirements.

    Based on ASHRAE standards for aircraft cabin ventilation.
    Each person requires approximately 0.0055 kg/s of ventilation air
    for adequate CO2 removal and odor control.

    Args:
        crew: Number of crew members
        passengers: Number of passengers
        operational_engines: Number of engines in operation
        n_engines: Total number of engines
        margin: Safety margin percentage

    Returns:
        Mass flow rate of ventilation air [kg/s]
    """
    # Fresh air requirement per person (kg/s)
    fresh_air_per_person = 0.0055
    
    # Total people
    total_people = crew + passengers
    
    # Basic ventilation requirement
    vent_kg = total_people * fresh_air_per_person
    
    # Add safety margin
    vent_kg *= (1 + margin / 100.0)
    
    return vent_kg


def equipVent(
    q_total: float,
    temp_out: float,
    temp_in: float,
    cp: float = 1006.0,
) -> float:
    """Calculate equipment ventilation air requirements.

    The ventilation air must absorb the equipment heat load and maintain
    acceptable cabin temperature.

    Args:
        q_total: Total equipment heat dissipation [W]
        temp_out: Ambient temperature [°C]
        temp_in: Desired cabin temperature [°C]
        cp: Specific heat capacity of air [J/(kg·K)], default 1006 (air at ~300K)

    Returns:
        Mass flow rate of cooling air [kg/s]
    """
    if temp_in <= temp_out:
        raise ValueError("Cabin temperature must be higher than ambient for cooling")
    
    # Temperature difference
    delta_T = temp_in - temp_out
    
    # Convert heat load to kW for readability
    q_kw = q_total / 1000.0
    
    # Mass flow rate: m_dot = Q / (cp * delta_T)
    # Add 20% margin for non-uniform distribution
    m_dot = (q_total / (cp * delta_T)) * 1.2
    
    return m_dot


def OBOGS_bleed(
    pressure: float,
    temperature: float,
    crew: int,
    height: float,
) -> float:
    """Calculate OBOGS (On-Board Oxygen Generation System) bleed air requirement.

    OBOGS uses a molecular sieve to extract oxygen from compressed air.
    Requires approximately 3.5% of total cabin ventilation for oxygen enrichment.

    Args:
        pressure: Ambient pressure [Pa]
        temperature: Ambient temperature [K]
        crew: Number of crew members
        height: Altitude [m]

    Returns:
        Mass flow rate of OBOGS bleed air [kg/s]
    """
    # OBOGS requires ~3.5% of ventilation air for adequate O2
    obogs_percentage = 0.035
    
    # Minimum fresh air per person at altitude (accounting for pressurization)
    # At sea level: ~0.0055 kg/s, increases with altitude due to lower density
    sea_level_flow = 0.0055
    pressure_ratio = pressure / 101325.0
    
    min_flow = sea_level_flow * pressure_ratio * crew
    
    return min_flow * obogs_percentage


def OBIGGS_bleed(
    fuel_tank_volume: float,
    margin: float = 10.0,
) -> float:
    """Calculate OBIGGS (On-Board Inert Gas Generation System) bleed air requirement.

    OBIGGS provides inert nitrogen-enriched air (NEA) to fuel tanks to reduce
    fire/explosion risk. Requires ~2-3% of pack flow for fuel tank inerting.

    Args:
        fuel_tank_volume: Fuel tank volume [liters]
        margin: Safety margin percentage

    Returns:
        Mass flow rate of OBIGGS bleed air [kg/s]
    """
    # OBIGS typically requires ~2.5% of pack flow
    obiggs_percentage = 0.025
    
    # Convert liters to m³ (approximate, assuming fuel density ~0.8 kg/L)
    tank_volume_m3 = fuel_tank_volume / 1000.0
    
    # Flow rate proportional to tank volume (larger tanks need more inerting)
    # Rough estimate: 0.001 kg/s per 1000 liters
    base_flow = tank_volume_m3 * 0.001
    
    # Add safety margin
    base_flow *= (1 + margin / 100.0)
    
    return base_flow * obiggs_percentage


def pack_cycle(
    m_dot_cabin: float,
    temp_in: float,
    temp_out: float,
    pressure_alt: float,
) -> tuple[float, float, float]:
    """Simulate vapor compression cycle (pack) performance.

    The pack uses a refrigeration cycle to remove heat from cabin air.
    This is a simplified model based on typical aircraft A/C pack performance.

    Args:
        m_dot_cabin: Cabin air mass flow [kg/s]
        temp_in: Pack inlet temperature [°C]
        temp_out: Pack outlet temperature [°C]
        pressure_alt: Pressure altitude [m]

    Returns:
        Tuple of (cop, compressor_power [kW], cooling_capacity [kW])
    """
    # Get ambient conditions
    _, T_amb, _ = ISA_calc(pressure_alt)
    T_amb_C = T_amb - 273.15
    
    # Temperature lift (positive when cooling needed)
    delta_T = temp_in - temp_out
    
    # If delta_T is negative, we need heating, not cooling
    if delta_T < 0:
        return 0.0, 0.0, 0.0
    
    # Typical COP range for aircraft packs: 2.5-4.0
    # COP decreases at high altitude due to lower ambient pressure
    altitude_factor = 1.0 - (pressure_alt / 20000.0) * 0.15
    base_cop = 3.0
    cop = base_cop * altitude_factor * (1.0 - 0.1 * delta_T / 50.0)
    
    # Ensure minimum COP
    cop = max(cop, 1.5)
    
    # Refrigeration capacity: Q = m_dot * cp * delta_T
    cp_air = 1006.0  # J/(kg·K)
    cooling_capacity = m_dot_cabin * cp_air * delta_T / 1000.0  # kW
    
    # Compressor power
    compressor_power = cooling_capacity / cop if cop > 0 else 0
    
    return cop, compressor_power, cooling_capacity


def inlet_drag(
    velocity: float,
    density: float,
    mass_flow: float,
) -> float:
    """Calculate ram drag from ECS air intake.

    Ram drag is the drag penalty due to scooping air into the ECS intake.
    D = 0.5 * rho * V² * A * Cd * (m_dot / (rho * V * A))

    Args:
        velocity: True airspeed [m/s]
        density: Air density [kg/m³]
        mass_flow: ECS mass flow [kg/s]

    Returns:
        Ram drag force [N]
    """
    if velocity <= 0:
        return 0.0
    
    # Intake area (typical: 0.02 m² per pack)
    A_intake = 0.02
    
    # Drag coefficient for ram inlet
    Cd = 0.3
    
    # Capture mass flow fraction
    capture_ratio = mass_flow / (density * velocity * A_intake)
    capture_ratio = min(capture_ratio, 1.0)
    
    # Dynamic pressure
    q = 0.5 * density * velocity**2
    
    # Ram drag
    ram_drag = q * A_intake * Cd * capture_ratio
    
    return ram_drag


def Weight_Volume(
    pack_mass: float = 150.0,
    ducting_mass: float = 50.0,
    control_mass: float = 30.0,
    pack_volume: float = 0.15,
    ducting_volume: float = 0.05,
    control_volume: float = 0.02,
) -> tuple[float, float]:
    """Estimate ECS mass and volume based on system components.

    Args:
        pack_mass: Pack/compressor mass [kg], default 150
        ducting_mass: Ducting and distribution mass [kg], default 50
        control_mass: Control system mass [kg], default 30
        pack_volume: Pack volume [m³], default 0.15
        ducting_volume: Ducting volume [m³], default 0.05
        control_volume: Control system volume [m³], default 0.02

    Returns:
        Tuple of (total_mass [kg], total_volume [m³])
    """
    total_mass = pack_mass + ducting_mass + control_mass
    total_volume = pack_volume + ducting_volume + control_volume
    
    return total_mass, total_volume


def Elect_ECS_Power(
    compressor_power: float = 0.0,
    fan_power: float = 5.0,
    control_power: float = 1.0,
) -> float:
    """Calculate total ECS electrical power consumption.

    Args:
        compressor_power: Pack compressor power [kW]
        fan_power: Fan and recirculation power [kW]
        control_power: Control system power [kW]

    Returns:
        Total electrical power [kW]
    """
    return compressor_power + fan_power + control_power


def compute_ecs_full(
    height: float,
    speed: float,
    fuel_tank_volume: float,
    crew: int,
    passengers: int,
    operational_engines: int,
    n_engines: int,
    q_total: float,
    temp_out: float,
    temp_in: float,
    cp: float = 1006.0,
) -> dict[str, float]:
    """Compute full ECS performance.

    Args:
        height: Altitude [m]
        speed: True airspeed [m/s]
        fuel_tank_volume: Fuel tank volume [L]
        crew: Number of crew members
        passengers: Number of passengers
        operational_engines: Number of operational engines
        n_engines: Total number of engines
        q_total: Equipment heat load [W]
        temp_out: Ambient temperature [°C]
        temp_in: Cabin temperature [°C]
        cp: Specific heat of air [J/(kg·K)]

    Returns:
        Dictionary with all ECS outputs
    """
    # Ambient conditions
    pressure, temperature, density = ISA_calc(height)
    
    # Human ventilation
    human_kg = humanVent(crew, passengers, operational_engines, n_engines)
    
    # Equipment ventilation
    equip_kg = equipVent(q_total, temp_out, temp_in, cp)
    
    # OBOGS bleed
    obogs_kg = OBOGS_bleed(pressure, temperature, crew, height)
    
    # OBIGGS bleed
    obiggs_kg = OBIGGS_bleed(fuel_tank_volume)
    
    # Total ECS bleed
    ecs_bleed = obogs_kg + obiggs_kg + equip_kg + human_kg
    
    # Pack refrigeration cycle
    # Note: temp_out in pack_cycle is the temperature after cooling (lower than cabin)
    # We use a typical pack outlet temperature of 10°C below cabin
    pack_outlet_temp = temp_in - 10.0
    m_dot_cabin = human_kg + equip_kg
    cop, comp_power, cool_cap = pack_cycle(m_dot_cabin, temp_in, pack_outlet_temp, height)
    
    # Ram drag
    ram_drag = inlet_drag(speed, density, ecs_bleed)
    
    # Mass and volume
    ecs_mass, ecs_vol = Weight_Volume()
    
    # Electrical power
    ecs_power = Elect_ECS_Power(compressor_power=comp_power)
    
    return {
        "ecs_bleed": ecs_bleed,  # kg/s - total bleed air
        "ram_drag": ram_drag,    # N - ram drag
        "ecs_mass": ecs_mass,    # kg - ECS mass
        "ecs_volume": ecs_vol,   # m³ - ECS volume
        "ecs_power": ecs_power,  # kW - electrical power
        "cop": cop,              # coefficient of performance
        "compressor_power": comp_power,  # kW
        "cooling_capacity": cool_cap,    # kW
        "human_ventilation": human_kg,   # kg/s
        "equipment_ventilation": equip_kg,  # kg/s
        "obogs_bleed": obogs_kg,      # kg/s
        "obiggs_bleed": obiggs_kg,     # kg/s
    }


if __name__ == "__main__":
    # Example calculation
    result = compute_ecs_full(
        height=6705,          # 22000 ft
        speed=250.85,        # m/s (~487 kts)
        fuel_tank_volume=37820,  # L (10000 gal)
        crew=5,
        passengers=120,
        operational_engines=2,
        n_engines=2,
        q_total=15000,       # W
        temp_out=-10,        # °C (ISA at altitude)
        temp_in=24,          # °C (cabin)
    )
    
    print("ECS Performance:")
    print(f"  Total bleed: {result['ecs_bleed']:.4f} kg/s")
    print(f"  Ram drag: {result['ram_drag']:.2f} N")
    print(f"  ECS mass: {result['ecs_mass']:.1f} kg")
    print(f"  ECS volume: {result['ecs_volume']:.3f} m³")
    print(f"  ECS power: {result['ecs_power']:.1f} kW")
    print(f"  COP: {result['cop']:.2f}")
    print(f"  Cooling capacity: {result['cooling_capacity']:.1f} kW")
