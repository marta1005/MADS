# ruff: noqa: N801, N802 ARG004


class IPS_BlockModel:
    @staticmethod
    def IPS(
        limit_root: float,
        limit_tip: float,
        limit_htp_root: float,
        limit_htp_tip: float,
        limit_vtp_root: float,
        limit_vtp_tip: float,
        protected_length_wing: float,
        protected_length_htp: float,
        protected_length_vtp: float,
        ips_mode: int,
    ) -> tuple[float, float, float, float]:
        return 1.0, 2.0, 3.0, 4.0

    @staticmethod
    def impLimits(name: str, chord: float, min_aoa: float, max_aoa: float) -> float:
        return 1.0
