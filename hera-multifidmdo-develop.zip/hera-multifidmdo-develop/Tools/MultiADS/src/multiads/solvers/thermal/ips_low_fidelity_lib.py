# ruff: noqa: N803, N806

from __future__ import annotations

from typing import TYPE_CHECKING

from typing_extensions import Self

from multiads.solvers import SolverOptions

# TODO @Andres: Using stub IPS model now
from multiads.solvers.thermal.models.ips_block_model_stub import IPS_BlockModel

if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import Any

    from multiads.assembly import Environment
    from multiads.assembly import ThermalSystem as Base_ThermalSystem
    from multiads.assembly import Wing as Base_Wing


class Options(SolverOptions):
    def __init__(
        self,
        *,
        AoA_min_root: float = 0.0,  # Wing/HTP/VTP root minimum angle of attack [deg] ---- Range [ 0.0 - 8.0 ]
        AoA_min_tip: float = 0.0,  # Wing/HTP/VTP tip minimum angle of attack [deg] ---- Range [ 0.0 - 8.0 ]
        AoA_max_root: float = 7.0,  # Wing/HTP/VTP root maximum angle of attack [deg] ---- Range [ 0.0 - 8.0 ]
        AoA_max_tip: float = 7.0,  # Wing/HTP/VTP tip minimum angle of attack [deg] ---- Range [ 0.0 - 8.0 ]
        wing_span_protect: float = 13.0460,  # semi-span length to protect [m] ------------ Range [ 0.0 - inf ]
        vtp_span_protect: float = 0.0,  # semi-span length to protect [m] ------------ Range [ 0.0 - inf ]
        htp_span_protect: float = 0.0,  # semi-span length to protect [m] ------------ Range [ 0.0 - inf ]
        chord_root: float = 4.56400,  # Wing root chord [m] ------------------------ Range [ 2.5 - 5.0 ]
        ips_mode: int = 1,  # IPS technology selection mode -------------------------------------- Range [0 - 4] - [11,22,33,44]
        # [0] - No Ice Protection System
        # [1] - Thermoelectrical inductive de-icing system ON | [11] - Thermoelectrical inductive de-icing system OFF
        # [2] - Thermoelectrical resistive de-icing system ON | [22] - Thermoelectrical resistive de-icing system OFF
        # [3] - Pneumatic boots ice protection system ON      | [33] - Pneumatic boots ice protection system OFF
        # [4] - Hot air anti-icing system ON                  | [44] - Hot air anti-icing system OFF
        **kwargs: Any,  # noqa: ANN401
    ) -> None:
        super().__init__(**kwargs)
        self.AoA_min_root = AoA_min_root
        self.AoA_min_tip = AoA_min_tip
        self.AoA_max_tip = AoA_max_tip
        self.AoA_max_root = AoA_max_root
        self.wing_span_protect = wing_span_protect
        self.vtp_span_protect = vtp_span_protect
        self.htp_span_protect = htp_span_protect
        self.chord_root = chord_root
        self.ips_mode = ips_mode


class ThermalSystem:
    def __init__(
        self,
        name: str,
    ) -> None:
        self.name = name

    @classmethod
    def from_component(cls, comp: Base_ThermalSystem) -> Self:
        return cls(
            name=comp.name,
        )


class Wing:
    def __init__(self, name: str, chord: float) -> None:
        self.name = name
        self.chord = chord

    @classmethod
    def from_component(cls, comp: Base_Wing) -> Self:
        return cls(
            name=comp.name,
            chord=comp.sections[0].chord,
        )


# Step 1: compute Weigh of Environment control
class _IPS:
    def __init__(self) -> None:
        return

    @staticmethod
    def compute_ice_protection(
        wings: Sequence[Wing],
        options: Options,
    ) -> tuple[float, float, float, float]:
        for wing in wings:
            impLimit_Root = IPS_BlockModel.impLimits(
                wing.name,  # "Wing",
                wing.chord,  # chord_WingRoot
                options.AoA_min_root,  # options.AoA_min_root,
                options.AoA_max_root,  # options.AoA_max_root,
            )
            impLimit_Tip = IPS_BlockModel.impLimits(
                wing.name,  # "Wing",
                wing.chord,  # chord_WingTip
                options.AoA_min_tip,
                options.AoA_max_tip,
            )

        ## Wing geometry and impingement limits
        # impLimit_WingRoot = IPS_BlockModel.impLimits(
        #    "Wing",
        #    self.chord_WingRoot,
        #    self.AoA_min_root_Wing,
        #    self.AoA_max_root_Wing,
        # )
        # impLimit_WingTip = IPS_BlockModel.impLimits(
        #   "Wing",
        #   IPS_data.chord_WingTip,
        #   IPS_data.AoA_min_tip_Wing,
        #   IPS_data.AoA_max_tip_Wing,
        # )
        # HTP geometry and impingement limits airfoil_data
        impLimit_HTPRoot = IPS_BlockModel.impLimits(
            "HTP",
            0.0,  # IPS_data.chord_HTPRoot,
            0.0,  # IPS_data.AoA_min_root_htp,
            0.0,  # IPS_data.AoA_max_root_htp,
        )
        impLimit_HTPTip = IPS_BlockModel.impLimits(
            "HTP",
            0.0,  # IPS_data.chord_HTPTip,
            0.0,  # IPS_data.AoA_min_tip_htp,
            0.0,  # IPS_data.AoA_max_tip_htp,
        )
        # VTP geometry and impingement limits
        impLimit_VTPRoot = IPS_BlockModel.impLimits(
            "VTP",
            0.0,  # IPS_data.chord_VTPRoot,
            0.0,  # IPS_data.AoA_min_root_vtp,
            0.0,  # IPS_data.AoA_max_root_vtp,
        )
        impLimit_VTPTip = IPS_BlockModel.impLimits(
            "VTP",
            0.0,  # IPS_data.chord_VTPTip,
            0.0,  # IPS_data.AoA_min_tip_vtp,
            0.0,  # IPS_data.AoA_max_tip_vtp,
        )

        Bleed_IPS, Power_IPS, IPS_W, IPS_V = IPS_BlockModel.IPS(
            impLimit_Root,
            impLimit_Tip,
            impLimit_HTPRoot,
            impLimit_HTPTip,
            impLimit_VTPRoot,
            impLimit_VTPTip,
            options.wing_span_protect,
            0.0,  # IPS_data.leadingEdge_HTP,
            0.0,  # IPS_data.leadingEdge_VTP,
            options.ips_mode,  # IPS_data.mode,
        )

        return Bleed_IPS, Power_IPS, IPS_W, IPS_V


class Driver:
    def __init__(
        self,
        environment: Environment,
        wings: list[Base_Wing],
        options: Options,
    ) -> None:
        self.options = options
        self.height = environment.height
        self.density = environment.density
        self.soundSpeed = environment.sound_speed
        self.viscosity = environment.dyn_viscosity
        self.speed = environment.speed

        # instatiate the engine from the base class
        self.wings = [Wing.from_component(w) for w in wings]

        # initialise main engine QOI
        self.ips_mass: float
        self.ips_volume: float
        self.ips_power: float

    def run(self) -> None:
        (_, ips_w, ips_vol, ips_power) = self._run(self.wings, self.options)
        self.ips_mass = ips_w
        self.ips_volume = ips_vol
        self.ips_power = ips_power

    @staticmethod
    def _run(
        wings: Sequence[Wing],
        options: Options,
    ) -> tuple[float, float, float, float]:
        IPS = _IPS()
        (
            ips_bleed,
            ips_w,
            ips_vol,
            ips_power,
        ) = IPS.compute_ice_protection(wings, options)

        return ips_bleed, ips_w, ips_vol, ips_power

    def total_mass(self) -> float:
        return self.ips_mass

    def cumulative_power(self) -> float:
        return self.ips_power

    def cumulative_volume(self) -> float:
        return self.ips_volume


if __name__ == "__main__":
    IPS = _IPS()
    wings = [Wing("Wing", 4.0)]

    options = Options()
    Bleed_IPS, Power_IPS, IPS_W, IPS_V = IPS.compute_ice_protection(
        wings,
        options,
    )

    print(Bleed_IPS, Power_IPS, IPS_W, IPS_V)
