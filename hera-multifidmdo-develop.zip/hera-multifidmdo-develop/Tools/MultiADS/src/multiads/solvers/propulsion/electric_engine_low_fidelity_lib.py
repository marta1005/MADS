import copy
from dataclasses import dataclass, field
from typing import Any
from typing_extensions import Self
import numpy as np
from collections.abc import Sequence
from pathlib import Path

from multiads.solvers import SolverOptions
from multiads.assembly import Environment as Base_Environment
from multiads.assembly import PropulsionSystem as Base_PropulsionSystem
from multiads.assembly import PowerManagSyst as Base_PowerManagSyst


class Options(SolverOptions):
    def __init__(
        self,
        *,
        tech_level: str = "SOA",
        efficiency_SOA: float = 0.96,
        efficiency_HTS: float = 0.98,
        weight_base: float = 0.0,
        elec_power_rating: float = 1000000.0,
        efficiency: float = 0.8,
        voltage_rating: float = 800.0,
        fuel_power: float = 500.0,
        efficiency_gear_box: float = 0.98,
        jac_approx_type: str = "finite_differences",
        jac_approx_step: float = 1e-03,
        jac_approx_n_processes: int = 1,
        jac_approx_use_threading: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.tech_level = tech_level
        self.efficiency_SOA = efficiency_SOA
        self.efficiency_HTS = efficiency_HTS
        self.weight_base = weight_base
        self.elec_power_rating = elec_power_rating
        self.efficiency = efficiency
        self.voltage_rating = voltage_rating
        self.fuel_power = fuel_power
        self.efficiency_gear_box = efficiency_gear_box
        self.jac_approx_type = jac_approx_type
        self.jac_approx_step = jac_approx_step
        self.jac_approx_n_processes = jac_approx_n_processes
        self.jac_approx_use_threading = jac_approx_use_threading


@dataclass
class PropulsionSystem:
    name: str = ""
    type: str = "Electric"
    shaft_power: float = 0.0

    @classmethod
    def from_component(cls, comp: Base_PropulsionSystem) -> Self:
        engine = PropulsionSystem(
            name=getattr(comp, 'name', ""),
            type=getattr(comp, 'type', 'Electric'),
            shaft_power=getattr(comp, 'shaft_power', 0.0),
        )
        if hasattr(comp, 'options') and isinstance(comp.options, dict):
            for k, v in comp.options.get("e_eng_lf", {}).items():
                if k in vars(engine):
                    setattr(engine, k, v)
        return engine
    
@dataclass
class PowerManagSyst:
    name: str = ""
    type: str = "Electric"
    hybrid_factor_engine: float = 0.0

    @classmethod
    def from_component(cls, comp: Base_PowerManagSyst | None) -> Self:
        if comp is not None:
            pwr_mng = PowerManagSyst(
                name=getattr(comp, 'name', ""),
                type=getattr(comp, 'type', 'Electric'),
                hybrid_factor_engine=getattr(comp, 'hybrid_factor_engine', 0.0),
            )
            if hasattr(comp, 'options') and isinstance(comp.options, dict):
                for k, v in comp.options.get("power_mng_lf", {}).items():
                    if k in vars(pwr_mng):
                        setattr(pwr_mng, k, v)
        else:
            pwr_mng = PowerManagSyst(name="", type="Electric")
            pwr_mng.hybrid_factor_engine = 0.0
              
        return pwr_mng


class Driver:
    def __init__(
        self,
        engines: Sequence[Base_PropulsionSystem],
        environment: Base_Environment,
        pwr_mng: Base_PowerManagSyst | None,
        options: Options,
    ) -> None:
        self.options = options
        self.density = environment.density
        self.soundSpeed = environment.sound_speed
        self.speed = environment.speed

        self.engines = [PropulsionSystem.from_component(e) for e in engines]
        self.mapind = {e.name: i for i, e in enumerate(self.engines)}
        
        self.pwr_mng = PowerManagSyst.from_component(pwr_mng)
               
        self.electric_engine_power: list[float] = []
        self.electric_engine_mass: list[float] = []
        self.electric_engine_voltage: list[float] = []
        self.engine_temperature: list[float] = []

    def run(self) -> None:
        for engine in self.engines:
            (
                electric_engine_power,
                electric_engine_voltage,
                engine_temperature,
                electric_engine_mass,
            ) = self._run(engine, self.pwr_mng, self.options)

            self.electric_engine_power.append(electric_engine_power)
            self.electric_engine_mass.append(electric_engine_mass)
            self.electric_engine_voltage.append(electric_engine_voltage)
            self.engine_temperature.append(engine_temperature)

    @staticmethod
    def _run(engine: PropulsionSystem, pwr_mng: PowerManagSyst, options: Options) -> tuple[float, float, float, float]:
        if options.tech_level == "SOA":
            eta_m = options.efficiency_SOA
            weight_inc = (
                1.96 * 0.453592 * (options.elec_power_rating / 1000) ** (0.8997)
            )
        elif options.tech_level == "HTS":
            eta_m = options.efficiency_HTS
            weight_inc = (
                2.28 * 0.453592 * (options.elec_power_rating / 1000) ** (0.6616)
            )
        else:
            raise ValueError("tech_level must be 'SOA' or 'HTS'")

        efficiency = options.efficiency * options.efficiency_gear_box
        voltage_rating = options.voltage_rating
        power_rating = options.elec_power_rating

        shaft_power = engine.shaft_power

        if engine.type == "Electric":
            electric_engine_power = shaft_power / efficiency
        elif engine.type == "Hybrid":
            electric_engine_power = (1 - pwr_mng.hybrid_factor_engine) * shaft_power / efficiency
        else:
            raise ValueError(f"Engine type {engine.type} not implemented")

        electric_engine_power = min(electric_engine_power, power_rating)
        
        electric_engine_voltage = voltage_rating * (electric_engine_power / power_rating)
        engine_temperature = electric_engine_power * 0.01 + 25
        engine_temperature = min(engine_temperature, 100)
        
        throttle = electric_engine_power / options.elec_power_rating
        heat_out = throttle * options.elec_power_rating * (1.0 - eta_m)
        
        electric_engine_weight = weight_inc + options.weight_base

        return (
            electric_engine_power,
            electric_engine_voltage,
            engine_temperature,
            electric_engine_weight,
        )

    def power_electric_engine(self, engine_names: list[str] | None = None) -> float:
        if engine_names is None:
            engine_names = list(self.mapind.keys())

        electric_engine_power = 0.0
        for name in engine_names:
            try:
                i = self.mapind[name]
                electric_engine_power += self.electric_engine_power[i]
            except KeyError:
                pass

        return electric_engine_power

    def mass_electric_engine(self, engine_names: list[str] | None = None) -> float:
        if engine_names is None:
            engine_names = list(self.mapind.keys())

        electric_engine_mass = 0.0
        for name in engine_names:
            try:
                i = self.mapind[name]
                electric_engine_mass += self.electric_engine_mass[i]
            except KeyError:
                pass

        return electric_engine_mass

    def _get_sensitivity(self) -> dict:
        sensitivity = {}
        step = self.options.jac_approx_step

        for eng_idx, engine in enumerate(self.engines):
            eng_name = engine.name

            shaft_power_val = float(np.atleast_1d(engine.shaft_power).item()) if engine.shaft_power is not None else None
            efficiency_val = self.options.efficiency
            power_rating_val = self.options.elec_power_rating
            voltage_rating_val = self.options.voltage_rating

            base_power, base_voltage, base_temp, base_mass = self._run(
                engine, self.pwr_mng, self.options
            )

            output_names = [
                f"{eng_name}.electric_engine_power",
                f"{eng_name}.electric_engine_voltage",
                f"{eng_name}.engine_temperature",
                f"{eng_name}.electric_engine_mass",
            ]

            for out_name in output_names:
                sensitivity[out_name] = {}

                if shaft_power_val is not None:
                    shaft_perturbed = shaft_power_val * (1 + step)
                    original_shaft = engine.shaft_power
                    engine.shaft_power = shaft_perturbed
                    power_p, voltage_p, temp_p, mass_p = self._run(engine, self.pwr_mng, self.options)
                    engine.shaft_power = original_shaft

                    d_power_d_shaft = (power_p - base_power) / (shaft_perturbed - shaft_power_val) if shaft_perturbed != shaft_power_val else 0.0
                    d_voltage_d_shaft = (voltage_p - base_voltage) / (shaft_perturbed - shaft_power_val) if shaft_perturbed != shaft_power_val else 0.0
                    d_temp_d_shaft = (temp_p - base_temp) / (shaft_perturbed - shaft_power_val) if shaft_perturbed != shaft_power_val else 0.0

                    sensitivity[out_name]["shaft_power"] = np.array([d_power_d_shaft if "power" in out_name else 
                                                                    d_voltage_d_shaft if "voltage" in out_name else 
                                                                    d_temp_d_shaft])

                efficiency_perturbed = efficiency_val * (1 + step)
                options_perturbed = Options(
                    tech_level=self.options.tech_level,
                    efficiency_SOA=self.options.efficiency_SOA,
                    efficiency_HTS=self.options.efficiency_HTS,
                    weight_base=self.options.weight_base,
                    elec_power_rating=self.options.elec_power_rating,
                    efficiency=efficiency_perturbed,
                    voltage_rating=self.options.voltage_rating,
                    fuel_power=self.options.fuel_power,
                    efficiency_gear_box=self.options.efficiency_gear_box,
                )
                power_p, voltage_p, temp_p, mass_p = self._run(engine, self.pwr_mng, options_perturbed)

                d_power_d_eff = (power_p - base_power) / (efficiency_perturbed - efficiency_val) if efficiency_perturbed != efficiency_val else 0.0
                d_voltage_d_eff = (voltage_p - base_voltage) / (efficiency_perturbed - efficiency_val) if efficiency_perturbed != efficiency_val else 0.0

                sensitivity[out_name]["efficiency"] = np.array([d_power_d_eff if "power" in out_name else 
                                                                d_voltage_d_eff if "voltage" in out_name else 
                                                                0.0])

                power_rating_perturbed = power_rating_val * (1 + step)
                options_perturbed = Options(
                    tech_level=self.options.tech_level,
                    efficiency_SOA=self.options.efficiency_SOA,
                    efficiency_HTS=self.options.efficiency_HTS,
                    weight_base=self.options.weight_base,
                    elec_power_rating=power_rating_perturbed,
                    efficiency=self.options.efficiency,
                    voltage_rating=self.options.voltage_rating,
                    fuel_power=self.options.fuel_power,
                    efficiency_gear_box=self.options.efficiency_gear_box,
                )
                power_p, voltage_p, temp_p, mass_p = self._run(engine, self.pwr_mng, options_perturbed)

                d_power_d_rating = (power_p - base_power) / (power_rating_perturbed - power_rating_val) if power_rating_perturbed != power_rating_val else 0.0
                d_voltage_d_rating = (voltage_p - base_voltage) / (power_rating_perturbed - power_rating_val) if power_rating_perturbed != power_rating_val else 0.0

                sensitivity[out_name]["power_rating"] = np.array([d_power_d_rating if "power" in out_name else 
                                                                  d_voltage_d_rating if "voltage" in out_name else 
                                                                  0.0])

        return sensitivity


if __name__ == "__main__":
    options = Options()
    
    engines = [
        PropulsionSystem(name="eng1", type="Electric", shaft_power=4000.0),
        PropulsionSystem(name="eng2", type="Hybrid", shaft_power=3000.0),
    ]
    
    pwr_mng = PowerManagSyst(hybrid_factor_engine=0.3)
    
    class MockEnv:
        density = 1.225
        sound_speed = 340.0
        speed = 150.0
    
    driver = Driver(engines=engines, environment=MockEnv(), pwr_mng=pwr_mng, options=options)
    driver.run()
    
    print("Electric engine power:", driver.electric_engine_power)
    print("Electric engine mass:", driver.electric_engine_mass)
    print("Electric engine voltage:", driver.electric_engine_voltage)
    print("Engine temperature:", driver.engine_temperature)
