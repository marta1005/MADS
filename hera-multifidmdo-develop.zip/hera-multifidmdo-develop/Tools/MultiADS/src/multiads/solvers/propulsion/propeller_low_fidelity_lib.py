# ruff: noqa: N806

from collections.abc import Callable, Sequence
from typing import Self

import numpy as np
from numpy.typing import NDArray

from multiads.assembly import ComponentOptions, Environment, Propeller

# Logger
from multiads.solvers import SolverOptions


class Options(SolverOptions):
    pass


class LFPropellerOptions(ComponentOptions):
    def __init__(
        self,
        propmap: Callable[[NDArray[np.float64]], float] | None = None,
        low_speed: bool = False,
        estimate_thrust: bool = True,
    ) -> None:
        super().__init__()
        self.propmap = propmap
        self.low_speed = low_speed
        self.estimate_thrust = estimate_thrust


class MtipPropeller:
    """Constant speed propeller.

    A more sphisticated propeller model, it is defined with a constant speed
    refered to the blade tip mach number at sea level. The thrust is calculated
    with the standard coeficients and a propeller maps, adjustements are made
    to keep the MDA robust
    """

    def __init__(
        self,
        name: str,
        diameter: float,
        pitch: float,
        rpm: float,
        thrust: float | None,
        propmap: Callable[[NDArray[np.float64]], float] | None,
        low_speed_correction: bool,
    ) -> None:
        self.name = name
        self.diameter = diameter
        self.pitch = pitch
        self.rpm = rpm
        self.thrust = thrust
        self.propmap = propmap
        self.low_speed_correction = low_speed_correction

    @classmethod
    def from_component(cls, comp: Propeller) -> Self:
        try:
            opts = next(o for o in comp.options if type(o) is LFPropellerOptions)
            return cls(
                name=comp.name,
                diameter=comp.r_tip * 2,
                pitch=comp.pitch,
                rpm=comp.rpm,
                thrust=None if opts.estimate_thrust else 0.0,
                propmap=opts.propmap,
                low_speed_correction=opts.low_speed,
            )
        except StopIteration:
            msg = f"No 'LFPropellerOptions' in component '{comp.name}'."
            raise ValueError(msg) from None

    def update(self, comp: Propeller) -> None:
        self.diameter = comp.r_tip * 2
        self.pitch = comp.pitch
        self.rpm = comp.rpm

    def calculate_prop_power(
        self,
        flight_speed: float,
        density: float,
    ) -> tuple[float, float, float, float]:
        """_______________________ CONSTANT SPEED PROPELLER _______________________
        A more sphisticated propeller model, it is defined with a constant speed
        refered to the blade tip mach number at sea level. The thurst is calculated
        with the standard coeficients and a propeller maps, adjustements are made
        to keep the MDA robust

        Args:
        flight_speed: Flight speed of the aircraft in m/s.
        diameter: Diameter of the selected propeller in meters.
        Mtip: Mach number at the blade tip at sea level.
        propmap: Propeller map, J-Cp map of the propeller.
        density: Air density in kg/m^3.
        thrust: Thrust of the propeller in N.


        Returns:
        thrust: Thrust of the propeller in N.
        shaft_power: Shaft power of the motor in Watts.

        """
        # ---------------- MAKE THE MDA ROBUST IN CASE OF NEGATIVE POWER ----------------#
        # GEMSEO this has to be done in code base, here we just make the power
        # values positive if they are negative. And we add a slope to keep the direction of
        # the gradient.
        # WARNING: This approaches are more effective when a lower bound is applied over the
        # state variable, this fix that we do here is just so the MDA does not break.
        # if np.any(shaft_power < 1):
        #  shaft_power = np.where(shaft_power<1, 100-0.0002*(1-shaft_power), shaft_power)
        #  shaft_power=shaft_power.flatten()
        #  print('WARNING: Negative power values, forcing positive values into the MDA')

        # ------------------------ CALCULATE OPERATING MAP POINTS ------------------------#
        # Here we calculate the operating points of the propeller that we use to enter the
        # propeller map. This is done by calculating the advance ratio and the power coefficient

        # https://www.electricrcaircraftguy.com/2014/04/propeller-static-dynamic-thrust-equation-background.html
        if self.thrust is None:
            print("warning :: Propeller thrust computed with semi-empirical model")
            pitch = (
                np.pi * 0.75 * self.diameter * np.tan(np.radians(self.pitch)) * 39.3701
            )
            thrust = (
                4.392e-8
                * self.rpm
                * (self.diameter * 39.3701) ** 3.5
                / np.sqrt(pitch)
                * (4.233e-4 * self.rpm * pitch - flight_speed)
            )
        else:
            thrust = self.thrust

        vtip = self.rpm * np.pi / 60 * self.diameter
        Ct = thrust / (density * vtip**2 * self.diameter**2 / np.pi**2)
        J = flight_speed * np.pi / vtip
        Cp = Ct * J

        # ------------------------ INTERPOLATE THE PROP MAP ------------------------#
        # Here we need to interpolate in the propeller map, from the previous fix we have ensured
        # that there is no point outside the interpolation range. From the propeller map surrrogate
        # generation we specificed that any value outisde the propeller map is set to a np.nan value.
        # This means that the extrapolation wont happen but wont generate an error.
        # We need to define how to handle the extended values, for this we agan perform a similar process
        # as before. The most critical part will be the cp values, as the propeller map is defined only till
        # cp_max=3.209 with an end value of eta=0.15.
        # Here again we fill the space with the addition of a small slope, a constraint will also help
        # to move the map to a feasible region.

        # exit velocity from actuator disk
        A_disk = np.pi * (self.diameter / 2) ** 2
        ue = np.sqrt(
            flight_speed**2 * (thrust / (A_disk * flight_speed**2 * density / 2) + 1),
        )

        # intoduce propeller efficiency
        if self.low_speed_correction:
            Ct_max_static = (
                Cp * 0.5 * (Cp) ** (2 / 3) * (np.pi / 2) ** (1 / 3) / ((Cp) ** 1.27)
            )
            Ct = min(Ct_max_static, Ct)
            eta = Ct * J / Cp
        elif self.propmap is not None:
            eta_interp = self.propmap(np.array([Cp, J]).T)
            eta = eta_interp if Cp < 3.2 else 0.38 - 0.01 * Cp
        else:
            eta = 2 / (1 + ue / flight_speed)  # Ct * J / Cp

        # ------------------------ COMPUTE THE RESULTANT THRUST  ------------------------#
        # Here we calculate the operating points of the propeller that we use to enter the
        # propeller map. This is done by calculating the advance ratio and the power coefficient.
        #
        # If the low speed correction is activated the thrust coefficient is corrected to not to be
        # greater than the maximum value imposed by the momentum theory given the Cp value at that
        # operating point.
        # The equation is adjusted to better mach the propeller maps given by Hamilton.
        shaft_power = (
            0.5 * Cp * density * np.pi * (self.diameter / 2) ** 2 * flight_speed**3
        )

        return thrust, eta, J, shaft_power

    def calculate_propeller_weight(self) -> float:
        return 0.01 * (np.pi * self.diameter**2) * 683 / (np.pi * 5.3**2)


class Driver:
    def __init__(
        self,
        propellers: Sequence[MtipPropeller],
        environment: Environment,
        options: Options,
    ) -> None:
        self.options = options
        self.density = environment.density
        self.speed = environment.speed

        self.propellers = propellers

        npr = len(propellers)
        self.eta: list[float] = [0.0] * npr
        self.thrust: list[float] = [0.0] * npr
        self.shaft_power: list[float] = [0.0] * npr
        self.mass: list[float] = [0.0] * npr

    def run(self) -> None:
        for i, prop in enumerate(self.propellers):
            thrust, eta, shaft_power, mass = self._run(prop)
            self.eta[i] = eta
            self.thrust[i] = thrust
            self.shaft_power[i] = shaft_power
            self.mass[i] = mass

    def _run(self, prop: MtipPropeller) -> tuple[float, float, float, float]:

        thrust, eta, _, shaft_power = prop.calculate_prop_power(
            self.speed,
            self.density,
        )
        mass = prop.calculate_propeller_weight()

        return thrust, eta, shaft_power, mass

    def get_sensitivity(self) -> dict[str, dict[str, NDArray[np.float64]]]:
        """Compute the Jacobian of the propeller outputs with respect to inputs.

        Returns:
            dict: Nested dictionary with sensitivities[output][input]

        """
        sensitivity = {}

        step = self.options.jac_approx_step

        for prop in self.propellers:
            prop_name = prop.name

            rpm_val = float(np.atleast_1d(prop.rpm).item())
            r_tip_val = prop.diameter / 2
            thrust_val = (
                float(np.atleast_1d(prop.thrust).item())
                if prop.thrust is not None
                else None
            )

            base_thrust, base_eta, _, base_power = self._run(prop)

            output_names = [
                f"{prop_name}.shaft_power",
                f"{prop_name}.prop_efficiency",
                f"{prop_name}.mass",
            ]
            if thrust_val is None:
                output_names.append(f"{prop_name}.thrust")

            for out_name in output_names:
                sensitivity[out_name] = {}

                if out_name == f"{prop_name}.mass":
                    d_mass_d_rtip = (
                        0.01 * (np.pi * 2 * r_tip_val) * 683 / (np.pi * 5.3**2)
                    )
                    sensitivity[out_name]["rpm"] = np.array([0.0])
                    sensitivity[out_name]["r_tip"] = np.array([d_mass_d_rtip])
                    continue

                if rpm_val is not None:
                    rpm_perturbed = rpm_val * (1 + step)
                    prop.rpm = rpm_perturbed
                    thrust_p, eta_p, _, power_p = self._run(prop)
                    prop.rpm = rpm_val

                    d_power_d_rpm = (
                        (power_p - base_power) / (rpm_perturbed - rpm_val)
                        if rpm_perturbed != rpm_val
                        else 0.0
                    )
                    d_eta_d_rpm = (
                        (eta_p - base_eta) / (rpm_perturbed - rpm_val)
                        if rpm_perturbed != rpm_val
                        else 0.0
                    )
                    d_thrust_d_rpm = (
                        (thrust_p - base_thrust) / (rpm_perturbed - rpm_val)
                        if rpm_perturbed != rpm_val
                        else 0.0
                    )

                    sensitivity[out_name]["rpm"] = np.array(
                        [
                            d_power_d_rpm
                            if "shaft_power" in out_name
                            else d_eta_d_rpm
                            if "efficiency" in out_name
                            else d_thrust_d_rpm,
                        ],
                    )

                r_tip_perturbed = r_tip_val * (1 + step)
                original_r_tip = prop.diameter / 2
                prop.diameter = r_tip_perturbed * 2
                thrust_p, eta_p, _, power_p = self._run(prop)
                prop.diameter = original_r_tip * 2

                d_power_d_rtip = (
                    (power_p - base_power) / (r_tip_perturbed - r_tip_val)
                    if r_tip_perturbed != r_tip_val
                    else 0.0
                )
                d_eta_d_rtip = (
                    (eta_p - base_eta) / (r_tip_perturbed - r_tip_val)
                    if r_tip_perturbed != r_tip_val
                    else 0.0
                )
                d_thrust_d_rtip = (
                    (thrust_p - base_thrust) / (r_tip_perturbed - r_tip_val)
                    if r_tip_perturbed != r_tip_val
                    else 0.0
                )

                sensitivity[out_name]["r_tip"] = np.array(
                    [
                        d_power_d_rtip
                        if "shaft_power" in out_name
                        else d_eta_d_rtip
                        if "efficiency" in out_name
                        else d_thrust_d_rtip,
                    ],
                )

                if thrust_val is not None:
                    thrust_perturbed = thrust_val * (1 + step)
                    original_thrust = prop.thrust
                    prop.thrust = thrust_perturbed
                    thrust_p, eta_p, _, power_p = self._run(prop)
                    prop.thrust = original_thrust

                    d_power_d_thrust = (
                        (power_p - base_power) / (thrust_perturbed - thrust_val)
                        if thrust_perturbed != thrust_val
                        else 0.0
                    )
                    d_eta_d_thrust = (
                        (eta_p - base_eta) / (thrust_perturbed - thrust_val)
                        if thrust_perturbed != thrust_val
                        else 0.0
                    )
                    d_thrust_d_thrust = (
                        (thrust_p - base_thrust) / (thrust_perturbed - thrust_val)
                        if thrust_perturbed != thrust_val
                        else 0.0
                    )

                    sensitivity[out_name]["thrust"] = np.array(
                        [
                            d_power_d_thrust
                            if "shaft_power" in out_name
                            else d_eta_d_thrust
                            if "efficiency" in out_name
                            else d_thrust_d_thrust,
                        ],
                    )

        return sensitivity


if __name__ == "__main__":
    Test1 = True

    """
  ################################## TESTING THE MODELS ##################################

  """
    # import matplotlib.pyplot as plt

    # if Test1:
    #     flight_speed = 100  # m/s
    #     diameter = 2.5  # meters
    #     Mtip = 0.8  # Mach number
    #     propmap = None  # Placeholder, not used in this example
    #     density = 1.225
    #     propeller = MtipPropeller(flight_speed, diameter, Mtip, propmap, density)
    #     power_values = np.linspace(-1000, 1000, 100)
    #     thrust_values = propeller.calculate_thrust(power_values)

    #     print("Thrust values:", thrust_values)
    #     print("Power values:", power_values)
    #     print("Thrust values shape:", thrust_values.shape)
    #     print("Power values shape:", power_values.shape)

    #     # Plot thrust as a function of power
    #     plt.figure()
    #     plt.plot(power_values, thrust_values, label="Thrust vs Power")
    #     plt.xlabel("Shaft Power (W)")
    #     plt.ylabel("Thrust (N)")
    #     plt.title("Thrust as a Function of Shaft Power")
    #     plt.legend()
    #     plt.grid(True)
    #     plt.show()
