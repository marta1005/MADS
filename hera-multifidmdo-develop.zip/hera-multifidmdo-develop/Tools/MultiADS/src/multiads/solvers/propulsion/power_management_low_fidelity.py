from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from multiads.assembly import (
    Environment,
    MADSComponent,
    PowerManagSyst,
    PropulsionSystem,
    ThermalSystem,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import BaseVariable, InnerVariableFloat
from multiads.solvers import BaseSolver
from multiads.solvers.propulsion.power_management_low_fidelity_lib import (
    Driver,
    Options,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from numpy.typing import NDArray


class PowerManagementLowFidelity(BaseSolver):
    def __init__(self, options: Options | None = None) -> None:
        super().__init__()
        self.options: Options = options or Options()
        self.driver: Driver | None = None
        self.engines: Sequence[PropulsionSystem] | None = None
        self.ecs: Sequence[ThermalSystem] | None = None
        self.powermanag_sys: PowerManagSyst | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv,
    ) -> Sequence[MADSComponent]:
        c_flat = flatten_components(components)

        self.engines = copy_components(
            c for c in c_flat if isinstance(c, PropulsionSystem)
        )
        self.ecs = copy_components(c for c in c_flat if isinstance(c, ThermalSystem))

        if env := next((c for c in c_flat if isinstance(c, Environment)), None):
            self.environment = env
        else:
            print(
                "warning...model 'PowerManagementLowFidelity' using DEFAULT Environment()"
            )
            self.environment = Environment(
                name="Default :: Environment", height=0.0, speed=150.0
            )

        if pm := next((c for c in c_flat if isinstance(c, PowerManagSyst)), None):
            self.powermanag_sys = pm
        else:
            print(
                "warning...model 'PowerManagementLowFidelity' using DEFAULT PowerManagSyst()"
            )
            self.powermanag_sys = PowerManagSyst(
                name="Default :: PowerManagSyst",
                type="Electric",
                hybrid_factor_engine=0.0,
                hybrid_factor_electric_power=1.0,
            )

        self.inputs: list[BaseVariable] = []
        self.outputs: list[BaseVariable] = []

        def update_io(
            eng: PropulsionSystem,
            inputs: list[BaseVariable],
            outputs: list[BaseVariable],
        ) -> None:
            if p := eng.variables.get("engine_power"):
                self.inputs.append(p)

            self.outputs.extend(
                [InnerVariableFloat(f"{eng.name}.electric_engine_power", 0.0)]
            )
            self.outputs.extend(
                [InnerVariableFloat(f"{eng.name}.comb_engine_power", 0.0)]
            )
            self.outputs.extend([InnerVariableFloat(f"{eng.name}.inverter_power", 0.0)])

        for eng in self.engines:
            update_io(eng, self.inputs, self.outputs)

        def update_ecs_io(
            ecs_sys: ThermalSystem,
            inputs: list[BaseVariable],
            outputs: list[BaseVariable],
        ) -> None:
            if p := ecs_sys.variables.get("ecs_power"):
                self.inputs.append(p)

        for ecs_sys in self.ecs:
            update_ecs_io(ecs_sys, self.inputs, self.outputs)

        self.outputs_map = {v.name: v for v in self.outputs}

        return [*self.engines]

    def _run(self) -> None:
        if self.engines is None:
            msg = f"Components in solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        self.driver = Driver(
            engines=self.engines,
            environment=self.environment,
            pwr_mng=self.powermanag_sys,
            ecs=self.ecs,
            options=self.options,
        )
        self.driver.run()

    def compute_output(self) -> None:
        if self.driver is None:
            msg = f"The driver of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.outputs is None:
            msg = f"The outputs of solver '{type(self).__name__} are not initialized"
            raise RuntimeError(msg)

        for i, eng in enumerate(self.engines):
            self.outputs_map[
                f"{eng.name}.electric_engine_power"
            ].value = self.driver.electric_engine_power[i]
            self.outputs_map[
                f"{eng.name}.comb_engine_power"
            ].value = self.driver.comb_engine_power[i]
            self.outputs_map[
                f"{eng.name}.inverter_power"
            ].value = self.driver.inverter_power[i]

    def compute_sensitivities(
        self,
        input_names: Sequence[str],
        inputs: Sequence[BaseVariable],
        output_names: Sequence[str],
        outputs: Sequence[BaseVariable],
    ) -> Mapping[str, NDArray]:
        sensitivity = self.driver._get_sensitivity()
        jac = {}

        input_name_map = {inp.name: inp for inp in inputs}

        for out_name in output_names:
            jac[out_name] = {}
            for inp_name in input_names:
                if out_name in sensitivity and inp_name in sensitivity[out_name]:
                    jac[out_name][input_name_map[inp_name]] = sensitivity[out_name][
                        inp_name
                    ]
                else:
                    jac[out_name][input_name_map[inp_name]] = np.zeros((1,))

        return jac
