from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np

# Logger
from gemseo import LOGGER

from multiads.assembly import (
    Environment,
    MADSComponent,
    Propeller,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import BaseVariable, InnerVariableFloat
from multiads.solvers import BaseSolver
from multiads.solvers.propulsion.propeller_low_fidelity_lib import (
    Driver,
    MtipPropeller,
    Options,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from numpy.typing import NDArray


class PropellerLowFidelity(BaseSolver):
    def __init__(self, options: Options | None = None) -> None:
        super().__init__()
        self.options: Options = options or Options()
        self.driver: Driver | None = None
        self.propellers: Sequence[MtipPropeller] | None = None
        self.inputs_map: Mapping[str, BaseVariable] | None = None
        self.outputs_map: Mapping[str, InnerVariableFloat] | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv: Any,  # noqa: ANN401, ARG002
    ) -> Sequence[MADSComponent]:
        # Filter components
        _components = copy_components(components)
        c_flat = flatten_components(_components)

        propellers = [c for c in c_flat if isinstance(c, Propeller)]
        self.propellers = [MtipPropeller.from_component(c) for c in propellers]

        try:
            self.environment = next(c for c in c_flat if isinstance(c, Environment))
        except StopIteration:
            LOGGER.info(
                "warning...model 'PropellerLowFidelity' using DEFAULT Environment()",
            )
            self.environment = Environment(
                name="Default :: Environment",
                height=0.0,
                speed=150.0,
            )

        # Inputs and outputs
        inputs: list[BaseVariable] = []
        outputs: list[InnerVariableFloat] = []

        # Environment
        if v := self.environment.variables.get("speed"):
            inputs.append(v)
        if v := self.environment.variables.get("height"):
            inputs.append(v)

        # Propellers
        for prop, l_prop in zip(propellers, self.propellers, strict=True):
            for sec in prop.blade.sections:
                if v := sec.variables.get("chord"):
                    inputs.append(v)
                if v := sec.variables.get("twist"):
                    inputs.append(v)

            if v := prop.variables.get("r_tip"):
                inputs.append(v)
            if v := prop.variables.get("pitch"):
                inputs.append(v)
            if v := prop.variables.get("rpm"):
                inputs.append(v)

            outputs.extend(
                [
                    InnerVariableFloat(f"{prop.name}.mass", 0.0),
                    InnerVariableFloat(f"{prop.name}.prop_efficiency", 0.0),
                    InnerVariableFloat(f"{prop.name}.shaft_power", 0.0),
                ],
            )

            if l_prop.thrust is None:
                print("warning :: thrust from propeller defined as InnerVariable")
                outputs.append(InnerVariableFloat(f"{prop.name}.thrust", 0.0))
            else:
                inputs.append(InnerVariableFloat(f"{prop.name}.thrust", 0.0))

        self.inputs = inputs
        self.outputs = outputs
        self.inputs_map = {v.name: v for v in self.inputs}
        self.outputs_map = {v.name: v for v in self.outputs}

        return [self.environment, *propellers]

    def set_state(self, components: Sequence[MADSComponent]) -> None:
        if self.propellers is None or self.inputs_map is None:
            msg = f"Solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        for l_prop in self.propellers:
            for comp in components:
                if type(comp) is Propeller and comp.name == l_prop.name:
                    l_prop.update(comp)
            if l_prop.thrust is not None:
                l_prop.thrust = self.inputs_map[f"{l_prop.name}.thrust"].value

    def _run(self) -> None:
        if self.environment is None or self.propellers is None:
            msg = f"Components in solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        self.driver = Driver(
            propellers=self.propellers,
            environment=self.environment,
            options=self.options,
        )
        self.driver.run()

    def compute_output(self) -> None:
        if self.driver is None or self.propellers is None or self.outputs_map is None:
            msg = f"Solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        thrusts = self.driver.thrust
        efficiencies = self.driver.eta
        shaft_powers = self.driver.shaft_power
        masses = self.driver.mass

        for i, prop in enumerate(self.propellers):
            if prop.thrust is None:
                self.outputs_map[f"{prop.name}.thrust"].value = thrusts[i]
            self.outputs_map[f"{prop.name}.prop_efficiency"].value = efficiencies[i]
            self.outputs_map[f"{prop.name}.shaft_power"].value = shaft_powers[i]
            self.outputs_map[f"{prop.name}.mass"].value = masses[i]

    def compute_sensitivities(
        self,
        input_names: Sequence[str],
        inputs: Sequence[BaseVariable],  # noqa: ARG002
        output_names: Sequence[str],
        outputs: Sequence[BaseVariable],  # noqa: ARG002
    ) -> Mapping[str, Mapping[str, NDArray]]:
        if self.driver is None:
            msg = f"The driver of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        sensitivity = self.driver.get_sensitivity()
        jac = {}

        for out_name in output_names:
            jac[out_name] = {}
            for inp_name in input_names:
                if out_name in sensitivity and inp_name in sensitivity[out_name]:
                    jac[out_name][inp_name] = sensitivity[out_name][inp_name]
                else:
                    jac[out_name][inp_name] = np.zeros((1,))

        return jac
