from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from multiads.assembly import (
    Environment,
    MADSComponent,
    PowerManagSyst,
    PropulsionSystem,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import BaseVariable, InnerVariableFloat
from multiads.solvers import BaseSolver
from multiads.solvers.propulsion.electric_engine_low_fidelity_lib import Driver, Options

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from numpy.typing import NDArray


class ElectricEngineLowFidelity(BaseSolver):
    def __init__(self, options: Options | None = None) -> None:
        super().__init__()
        self.options: Options = options or Options()
        self.driver: Driver | None = None
        self.engines: Sequence[PropulsionSystem] | None = None
        self.powermanag_sys: PowerManagSyst | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv,
    ) -> Sequence[MADSComponent]:
        c_flat = flatten_components(components)

        self.engines = copy_components(
            c for c in c_flat if isinstance(c, PropulsionSystem)
        )

        if env := next((c for c in c_flat if isinstance(c, Environment)), None):
            self.environment = env
        else:
            print(
                "warning...model 'ElectricEngineLowFidelity' using DEFAULT Environment()"
            )
            self.environment = Environment(
                name="Default :: Environment", height=0.0, speed=150.0
            )

        if pm := next((c for c in c_flat if isinstance(c, PowerManagSyst)), None):
            self.powermanag_sys = pm
        else:
            print(
                "warning...model 'ElectricEngineLowFidelity' using DEFAULT PowerManagSyst()"
            )
            self.powermanag_sys = PowerManagSyst(
                name="Default :: PowerManagSyst",
                type="Electric",
                hybrid_factor_engine=0.0,
            )

        self.inputs: list[BaseVariable] = []
        self.outputs: list[BaseVariable] = []

        def update_io(
            eng: PropulsionSystem,
            inputs: list[BaseVariable],
            outputs: list[BaseVariable],
        ) -> None:
            if p := eng.variables.get("shaft_power"):
                self.inputs.append(p)
            if p := eng.variables.get("engine_power"):
                self.inputs.append(p)

            self.outputs.extend(
                [InnerVariableFloat(f"{eng.name}.electric_engine_power", 0.0)]
            )
            self.outputs.extend(
                [InnerVariableFloat(f"{eng.name}.electric_engine_voltage", 0.0)]
            )
            self.outputs.extend(
                [InnerVariableFloat(f"{eng.name}.engine_temperature", 0.0)]
            )
            self.outputs.extend(
                [InnerVariableFloat(f"{eng.name}.electric_engine_mass", 0.0)]
            )

        for eng in self.engines:
            update_io(eng, self.inputs, self.outputs)

        self.outputs_map = {v.name: v for v in self.outputs}

        return [*self.engines]

    def _run(self) -> None:
        if self.engines is None:
            msg = f"Components in solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        self.driver = Driver(
            engines=self.engines,
            environment=self.environment,
            pwr_mng=self.powermanag_sys,
            options=self.options,
        )
        self.driver.run()

    def compute_output(self) -> None:
        if self.driver is None:
            msg = f"The driver of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.outputs is None:
            msg = f"The outputs of solver '{type(self).__name__} are not initialized"
            raise RuntimeError(msg)

        electric_powers = self.driver.electric_engine_power
        electric_voltages = self.driver.electric_engine_voltage
        engine_temps = self.driver.engine_temperature
        engine_masses = self.driver.electric_engine_mass

        for i, eng in enumerate(self.engines):
            self.outputs_map[
                f"{eng.name}.electric_engine_power"
            ].value = electric_powers[i]
            self.outputs_map[
                f"{eng.name}.electric_engine_voltage"
            ].value = electric_voltages[i]
            self.outputs_map[f"{eng.name}.engine_temperature"].value = engine_temps[i]
            self.outputs_map[f"{eng.name}.electric_engine_mass"].value = engine_masses[
                i
            ]

    def compute_sensitivities(
        self,
        input_names: Sequence[str],
        inputs: Sequence[BaseVariable],
        output_names: Sequence[str],
        outputs: Sequence[BaseVariable],
    ) -> Mapping[str, NDArray]:
        sensitivity = self.driver._get_sensitivity()
        jac = {}

        input_name_map = {inp.name: inp for inp in inputs}

        for out_name in output_names:
            jac[out_name] = {}
            for inp_name in input_names:
                if out_name in sensitivity and inp_name in sensitivity[out_name]:
                    jac[out_name][input_name_map[inp_name]] = sensitivity[out_name][
                        inp_name
                    ]
                else:
                    jac[out_name][input_name_map[inp_name]] = np.zeros((1,))

        return jac
