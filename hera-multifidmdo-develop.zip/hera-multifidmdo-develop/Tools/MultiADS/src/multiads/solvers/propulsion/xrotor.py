from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from multiads.assembly import (
    Environment,
    MADSComponent,
    Propeller,
    copy_components,
    flatten_components,
)
from multiads.scenario.variables import BaseVariable, InnerVariableFloat
from multiads.solvers import BaseSolver
from multiads.solvers.propulsion.xrotor_lib import Driver, Options

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from numpy.typing import NDArray


class Xrotor(BaseSolver):
    def __init__(self, options: Options | None = None) -> None:
        super().__init__()
        self.options: Options = options or Options()
        self.driver: Driver | None = None
        self.propellers: Sequence[Propeller] | None = None

    def parse_variables(
        self,
        components: Sequence[MADSComponent],
        *argv,
    ) -> Sequence[MADSComponent]:
        c_flat = flatten_components(components)
        self.propellers = copy_components(c for c in c_flat if isinstance(c, Propeller))

        if env := next((c for c in c_flat if isinstance(c, Environment)), None):
            self.environment = env
        else:
            print("warning...model 'Xrotor' using DEFAULT Environment()")
            self.environment = Environment(
                name="Default :: Environment", height=0.0, speed=150.0
            )

        self.inputs: list[BaseVariable] = []
        self.outputs: list[BaseVariable] = []

        def update_io(
            prop: Propeller,
            inputs: list[BaseVariable],
            outputs: list[BaseVariable],
        ) -> None:
            for sec in prop.blade.sections:
                if v := sec.variables.get("chord"):
                    self.inputs.append(v)
                if v := sec.variables.get("twist"):
                    self.inputs.append(v)

            if p := prop.variables.get("r_tip"):
                self.inputs.append(p)
            if p := prop.variables.get("pitch"):
                self.inputs.append(p)
            if p := prop.variables.get("rpm"):
                self.inputs.append(p)

            self.outputs.extend([InnerVariableFloat(f"{prop.name}.shaft_power", 0.0)])
            self.outputs.extend(
                [InnerVariableFloat(f"{prop.name}.prop_efficiency", 0.0)]
            )
            self.outputs.extend([InnerVariableFloat(f"{prop.name}.mass", 0.0)])

        for prop in self.propellers:
            update_io(prop, self.inputs, self.outputs)

            if p := prop.thrust is None:
                print("warning :: thrust from propeller defined as InnerVariable")
                self.outputs.append(InnerVariableFloat(f"{prop.name}.thrust", 0.0))
            elif p := prop.variables.get("thrust"):
                self.inputs.append(p)

        self.outputs_map = {v.name: v for v in self.outputs}

        return [*self.propellers]

    def _run(self) -> None:
        if self.propellers is None:
            msg = f"Components in solver '{type(self).__name__}' not initialized."
            raise RuntimeError(msg)

        from multiads.solvers.propulsion.xrotor_lib import Propeller as XRotorPropeller

        xr_propellers = [
            XRotorPropeller(
                r_tip=prop.r_tip,
                pitch=prop.pitch,
                n_blades=prop.n_blades,
                rpm=prop.rpm,
                r_hub=prop.r_hub,
                rake=prop.rake,
                geomdata=prop.geomdata,
                case=prop.case,
                r_wake=prop.r_wake,
                power=prop.power,
                thrust=prop.thrust,
                adv=prop.adv,
            )
            for prop in self.propellers
        ]

        self.driver = Driver(
            propellers=xr_propellers,
            environment=self.environment,
            options=self.options,
        )
        self.driver.run()

    def compute_output(self) -> None:
        if self.driver is None:
            msg = f"The driver of solver '{type(self).__name__}' is not initialized."
            raise RuntimeError(msg)

        if self.outputs is None:
            msg = f"The outputs of solver '{type(self).__name__} are not initialized"
            raise RuntimeError(msg)

        thrusts = self.driver.thrust
        prop_efficiencies = self.driver.eta
        shaft_powers = self.driver.shaft_power
        masses = self.driver.mass

        for i, prop in enumerate(self.propellers):
            if self.outputs_map.get(f"{prop.name}.thrust") is not None:
                self.outputs_map[f"{prop.name}.thrust"].value = thrusts[i]
            self.outputs_map[f"{prop.name}.prop_efficiency"].value = prop_efficiencies[
                i
            ]
            self.outputs_map[f"{prop.name}.shaft_power"].value = shaft_powers[i]
            self.outputs_map[f"{prop.name}.mass"].value = masses[i]

    def compute_sensitivities(
        self,
        input_names: Sequence[str],
        inputs: Sequence[BaseVariable],
        output_names: Sequence[str],
        outputs: Sequence[BaseVariable],
    ) -> Mapping[str, NDArray]:
        sensitivity = self.driver._get_sensitivity()
        jac = {}

        input_name_map = {inp.name: inp for inp in inputs}

        for out_name in output_names:
            jac[out_name] = {}
            for inp_name in input_names:
                if out_name in sensitivity and inp_name in sensitivity[out_name]:
                    jac[out_name][input_name_map[inp_name]] = sensitivity[out_name][
                        inp_name
                    ]
                else:
                    jac[out_name][input_name_map[inp_name]] = np.zeros((1,))

        return jac
