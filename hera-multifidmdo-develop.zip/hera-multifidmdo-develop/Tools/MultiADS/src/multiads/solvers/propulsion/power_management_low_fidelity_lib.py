from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any
from typing_extensions import Self
import numpy as np
from collections.abc import Sequence
from pathlib import Path

from multiads.solvers import SolverOptions
from multiads.assembly import Environment as Base_Environment
from multiads.assembly import PropulsionSystem as Base_PropulsionSystem
from multiads.assembly import PowerManagSyst as Base_PowerManagSyst
from multiads.assembly import ThermalSystem as Base_ThermalSystem


class Options(SolverOptions):
    def __init__(
        self,
        *,
        number_of_engines: int = 3,
        efficiency_inverter: float = 0.98,
        efficiency_gear_box: float = 0.98,
        inverter_power: float = 800.0,
        jac_approx_type: str = "finite_differences",
        jac_approx_step: float = 1e-04,
        jac_approx_n_processes: int = 1,
        jac_approx_use_threading: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.number_of_engines = number_of_engines
        self.efficiency_inverter = efficiency_inverter
        self.efficiency_gear_box = efficiency_gear_box
        self.inverter_power = inverter_power
        self.jac_approx_type = jac_approx_type
        self.jac_approx_step = jac_approx_step
        self.jac_approx_n_processes = jac_approx_n_processes
        self.jac_approx_use_threading = jac_approx_use_threading


@dataclass
class PropulsionSystem:
    name: str = ""
    type: str = "Electric"
    engine_power: float = 0.0

    @classmethod
    def from_component(cls, comp: Base_PropulsionSystem) -> Self:
        engine = PropulsionSystem(
            name=getattr(comp, 'name', ""),
            type=getattr(comp, 'type', 'Electric'),
            engine_power=getattr(comp, 'engine_power', 0.0),
        )
        if hasattr(comp, 'options') and isinstance(comp.options, dict):
            for k, v in comp.options.get("power_mng_lf", {}).items():
                if k in vars(engine):
                    setattr(engine, k, v)
        return engine


@dataclass
class ThermalSystem:
    name: str = ""
    ecs_power: float = 0.0

    @classmethod
    def from_component(cls, comp: Base_ThermalSystem) -> Self:
        ecs = ThermalSystem(
            name=getattr(comp, 'name', ""),
            ecs_power=getattr(comp, 'ecs_power', 0.0),
        )
        if hasattr(comp, 'options') and isinstance(comp.options, dict):
            for k, v in comp.options.get("power_mng_lf", {}).items():
                if k in vars(ecs):
                    setattr(ecs, k, v)
        return ecs


@dataclass
class PowerManagSyst:
    name: str = ""
    type: str = "Electric"
    hybrid_factor_engine: float = 0.0
    hybrid_factor_electric_power: float = 1.0

    @classmethod
    def from_component(cls, comp: Base_PowerManagSyst | None) -> Self:
        if comp is not None:
            pwr_mng = PowerManagSyst(
                name=getattr(comp, 'name', ""),
                type=getattr(comp, 'type', 'Electric'),
                hybrid_factor_engine=getattr(comp, 'hybrid_factor_engine', 0.0),
                hybrid_factor_electric_power=getattr(comp, 'hybrid_factor_electric_power', 1.0),
            )
            if hasattr(comp, 'options') and isinstance(comp.options, dict):
                for k, v in comp.options.get("power_mng_lf", {}).items():
                    if k in vars(pwr_mng):
                        setattr(pwr_mng, k, v)
        else:
            pwr_mng = PowerManagSyst()
            pwr_mng.hybrid_factor_engine = 0.0
            pwr_mng.hybrid_factor_electric_power = 1.0
        return pwr_mng


class Driver:
    def __init__(
        self,
        engines: Sequence[Base_PropulsionSystem],
        environment: Base_Environment,
        pwr_mng: Base_PowerManagSyst | None,
        ecs: Sequence[Base_ThermalSystem],
        options: Options,
    ) -> None:
        self.options = options
        self.density = environment.density
        self.soundSpeed = environment.sound_speed
        self.speed = environment.speed

        self.engines = [PropulsionSystem.from_component(e) for e in engines]
        self.mapind = {e.name: i for i, e in enumerate(self.engines)}
        
        self.ecs = [ThermalSystem.from_component(e) for e in ecs]
        self.mapind2 = {cs.name: i for i, cs in enumerate(self.ecs)}
        
        self.pwr_mng = PowerManagSyst.from_component(pwr_mng)

        self.hybrid_factor_engine: list[float] = []
        self.hybrid_factor_power: float = 0.0
        self.electric_engine_power: list[float] = []
        self.comb_engine_power: list[float] = []
        self.inverter_power: list[float] = []

    def run(self) -> None:
        for engine in self.engines:
            (
                el_engine_power,
                inv_power,
                comb_eng_power,
                hybrid_factor_eng,
            ) = self._run(engine, self.pwr_mng, self.ecs, self.options)

            if engine.type == "Electric":
                self.hybrid_factor_engine.append(0)
            else:
                self.hybrid_factor_engine.append(hybrid_factor_eng)
            
            self.electric_engine_power.append(el_engine_power)
            self.comb_engine_power.append(comb_eng_power)
            self.inverter_power.append(inv_power)

    @staticmethod
    def _run(engine: PropulsionSystem, pwr_mng: PowerManagSyst, ecs: list[ThermalSystem], options: Options) -> tuple[float, float, float, float]:
        efficiency_gear_box = options.efficiency_gear_box
        efficiency_inverter = options.efficiency_inverter

        if engine.type == "Electric":
            engine_power = engine.engine_power
            electric_engine_power = engine.engine_power
            comb_engine_power = 0.0
        else:
            engine_power = engine.engine_power
            electric_engine_power = engine_power * (1 - pwr_mng.hybrid_factor_engine)
            comb_engine_power = engine_power - electric_engine_power

        inverter_power = options.inverter_power / efficiency_inverter

        return (
            electric_engine_power,
            inverter_power,
            comb_engine_power,
            pwr_mng.hybrid_factor_engine,
        )

    def total_electrical_power(self, engine_names: list[str] | None = None, ecs_names: list[str] | None = None) -> float:
        if engine_names is None:
            engine_names = list(self.mapind.keys())

        total = 0.0
        for name in engine_names:
            try:
                i = self.mapind[name]
                total += self.electric_engine_power[i] + self.inverter_power[i]
            except KeyError:
                pass

        if ecs_names is None:
            ecs_names = list(self.mapind2.keys())

        for name in ecs_names:
            try:
                i = self.mapind2[name]
                total += self.ecs[i].ecs_power
            except KeyError:
                pass

        return total

    def total_combustion_power(self, engine_names: list[str] | None = None) -> float:
        if engine_names is None:
            engine_names = list(self.mapind.keys())

        total = 0.0
        for name in engine_names:
            try:
                i = self.mapind[name]
                total += self.comb_engine_power[i]
            except KeyError:
                pass

        return total

    def electrical_power_from_battery(self) -> float:
        hybrid_factor_power = self._compute_hybrid_global_factor()
        return self.total_electrical_power() * hybrid_factor_power * self.pwr_mng.hybrid_factor_electric_power

    def electrical_power_from_fc(self) -> float:
        hybrid_factor_power = self._compute_hybrid_global_factor()
        return self.total_electrical_power() * hybrid_factor_power * (1 - self.pwr_mng.hybrid_factor_electric_power)

    def _compute_hybrid_global_factor(self) -> float:
        total_elec = self.total_electrical_power()
        total_comb = self.total_combustion_power()
        if total_elec + total_comb > 0:
            self.hybrid_factor_power = total_elec / (total_elec + total_comb)
        else:
            self.hybrid_factor_power = 0.0
        return self.hybrid_factor_power

    def _get_sensitivity(self) -> dict:
        sensitivity = {}
        step = self.options.jac_approx_step

        for eng_idx, engine in enumerate(self.engines):
            eng_name = engine.name

            engine_power_val = float(np.atleast_1d(engine.engine_power).item()) if engine.engine_power is not None else None

            base_elec, base_inv, base_comb, _ = self._run(
                engine, self.pwr_mng, self.ecs, self.options
            )
            base_total_elec = self.total_electrical_power()
            base_total_comb = self.total_combustion_power()

            output_names = [
                f"{eng_name}.electric_engine_power",
                f"{eng_name}.comb_engine_power",
                f"{eng_name}.inverter_power",
            ]

            for out_name in output_names:
                sensitivity[out_name] = {}

                if engine_power_val is not None:
                    power_perturbed = engine_power_val * (1 + step)
                    original_power = engine.engine_power
                    engine.engine_power = power_perturbed
                    elec_p, inv_p, comb_p, _ = self._run(engine, self.pwr_mng, self.ecs, self.options)
                    engine.engine_power = original_power

                    d_elec_d_power = (elec_p - base_elec) / (power_perturbed - engine_power_val) if power_perturbed != engine_power_val else 0.0
                    d_comb_d_power = (comb_p - base_comb) / (power_perturbed - engine_power_val) if power_perturbed != engine_power_val else 0.0
                    d_inv_d_power = (inv_p - base_inv) / (power_perturbed - engine_power_val) if power_perturbed != engine_power_val else 0.0

                    sensitivity[out_name]["engine_power"] = np.array([d_elec_d_power if "electric" in out_name else 
                                                                     d_comb_d_power if "comb" in out_name else 
                                                                     d_inv_d_power])

        return sensitivity


if __name__ == "__main__":
    options = Options()
    
    engines = [
        PropulsionSystem(name="engine1", type="Electric", engine_power=1000.0),
        PropulsionSystem(name="engine2", type="Hybrid", engine_power=2000.0),
    ]
    
    ecs = [
        ThermalSystem(name="ecs1", ecs_power=500.0),
    ]
    
    pwr_mng = PowerManagSyst(
        name="pwr_mng",
        type="Electric",
        hybrid_factor_engine=0.3,
        hybrid_factor_electric_power=0.5,
    )
    
    class MockEnv:
        density = 1.225
        sound_speed = 340.0
        speed = 150.0
    
    driver = Driver(
        engines=engines,
        environment=MockEnv(),
        pwr_mng=pwr_mng,
        ecs=ecs,
        options=options,
    )
    driver.run()
    
    print("Electric engine power:", driver.electric_engine_power)
    print("Combustion engine power:", driver.comb_engine_power)
    print("Inverter power:", driver.inverter_power)
    print("Total electrical power:", driver.total_electrical_power())
    print("Total combustion power:", driver.total_combustion_power())
    print("Electrical from battery:", driver.electrical_power_from_battery())
    print("Electrical from FC:", driver.electrical_power_from_fc())
