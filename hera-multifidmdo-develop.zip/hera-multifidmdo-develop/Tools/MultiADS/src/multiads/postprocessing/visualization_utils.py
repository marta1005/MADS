"""Shared utilities for visualization."""

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.path import Path
import matplotlib.patches as mpatches


def setup_plot_style():
    """Set consistent plot styling."""
    plt.style.use('seaborn-v0_8-darkgrid')


def get_default_markers():
    """Get default marker styles for feasible/optimal/valid points.

    Returns:
        list[dict]: List of marker dictionaries.
    """
    # Create custom centroid marker for optimal points
    sector1 = Path.arc(0.0, 90.0, is_wedge=True)
    sector2 = Path.arc(180.0, 270.0, is_wedge=True)
    circle = Path.circle()
    centroid = Path(
        vertices=np.concatenate([
            circle.vertices,
            sector1.vertices[::-1, ...],
            sector2.vertices[::-1, ...]
        ]),
        codes=np.concatenate([
            circle.codes,
            sector1.codes,
            sector2.codes
        ])
    )

    return [
        dict(label='Not Valid', marker='X', s=140, color='red', alpha=1.0),
        dict(label='Valid', marker='o', s=120, color='blue', alpha=0.2),
        dict(label='Close To Optimal', marker='o', s=100, color='green', alpha=0.6),
        dict(label='Optimal', marker=centroid, s=80, color='magenta',
             edgecolor='darkmagenta', alpha=1.0),
    ]


def save_plot(fig, filepath: str, dpi: int = 80):
    """Save plot to file.

    Args:
        fig: Matplotlib figure object.
        filepath: Output file path.
        dpi: Resolution (dots per inch).
    """
    fig.savefig(filepath, dpi=dpi, format=filepath.split('.')[-1])


def classify_points(objective_values, valid_mask, maximize: bool = True):
    """Classify points as feasible, optimal, etc.

    Args:
        objective_values: Array of objective values.
        valid_mask: Boolean array indicating feasible points.
        maximize: True if maximizing, False if minimizing.

    Returns:
        tuple: (min_obj, max_obj, cut_obj, classification_array)
            classification_array: 0=invalid, 1=valid, 2=close to optimal, 3=optimal
    """
    objective_values = np.array(objective_values)
    valid_mask = np.array(valid_mask, dtype=bool)

    valid_values = objective_values[valid_mask]

    if len(valid_values) == 0:
        return 0.0, 0.0, 0.0, np.zeros(len(objective_values))

    min_obj = np.min(valid_values)
    max_obj = np.max(valid_values)

    # Use same formula as objectiveClassification
    if maximize:
        cut_obj = 0.1 * min_obj + 0.9 * max_obj
    else:
        cut_obj = 0.9 * min_obj + 0.1 * max_obj

    # Classify: 0=invalid, 1=valid, 2=close to optimal, 3=optimal
    classification = np.zeros(len(objective_values))
    classification[valid_mask] = 1

    if len(valid_values) > 0:
        if maximize:
            opt_idx_in_valid = np.argmax(objective_values[valid_mask])
        else:
            opt_idx_in_valid = np.argmin(objective_values[valid_mask])

        # Map back to full array indices
        valid_indices = np.where(valid_mask)[0]
        if len(valid_indices) > opt_idx_in_valid:
            classification[valid_indices[opt_idx_in_valid]] = 3

            # Mark points close to optimal
            if maximize:
                # Points with value >= cut_obj (close to max)
                close_mask = (objective_values >= cut_obj) & valid_mask
            else:
                # Points with value <= cut_obj (close to min)
                close_mask = (objective_values <= cut_obj) & valid_mask
            # Don't mark the optimal point as "close"
            close_mask = close_mask & (classification != 3)
            classification[close_mask] = 2

    return min_obj, max_obj, cut_obj, classification
