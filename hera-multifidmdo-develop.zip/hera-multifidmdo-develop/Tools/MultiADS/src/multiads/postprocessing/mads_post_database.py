#
# library to update databases in GEMSEO
#

from numpy import array
import numpy as np

from gemseo.algos.optimization_problem import OptimizationProblem
from gemseo import read_design_space
from gemseo import write_design_space
import copy
from gemseo import import_database
from gemseo.algos.optimization_history import OptimizationHistory
from multiads.design_space.cpacs_structure_data import CPACSStructureData


class MadsPostProcessor:
    """
    Post-process optimization results from MADS scenarios.

    Attributes:
        database: The optimization history database.
    """

    def __init__(self, database) -> None:
        """
        Initialize with a database.

        Args:
            database: GEMSEO database or OptimizationHistory object.
        """
        self.database = database

    def get_history(self, var=""):
        """Recover optimization history from the database.

        Args:
            var (str, optional): Variable name to get gradient history.

        Returns:
            tuple: (outputs, inputs, jacobian)
        """
        outputs, inputs = self.database.get_history()
        jacobian = self.database.get_gradient_history(var)
        return outputs, inputs, jacobian

    def write_history_to_file(self, history_file):
        """Write history to a text file.

        Args:
            history_file (str): Path to output file.
        """
        f = open(history_file, "w")
        for i, (input, output) in enumerate(self.database.items()):
            f.write(f"iter {i} --> input = {input} / output = {output}\n")
        f.close()

    def get_iteration(self, x_vect=()):
        """Get iteration number for a given point.

        Args:
            x_vect (tuple, optional): Input vector.

        Returns:
            int: Iteration number.
        """
        iter = self.database.get_iteration(x_vect)
        return iter

    def export_to_hdf(self, file_name=""):
        """Export database to HDF5 format.

        Args:
            file_name (str): Path to output HDF5 file.
        """
        self.database.to_hdf(file_name)


class MadsExportHistory:
    """Export feasible designs from MADS scenarios."""

    def __init__(
        self,
        mads_scenario,
        constraints,
        var_name_list,
        out_file,
        scenario_type="DOE",  # "MDO" , "DOE"
    ) -> None:
        """
        Initialize export handler.

        Args:
            mads_scenario: MADS scenario object.
            constraints: Constraint functions.
            var_name_list: List of variable names.
            out_file: Output file path.
            scenario_type: Type of scenario ("MDO" or "DOE").
        """
        self.mads_scenario = mads_scenario
        self.var_name_list = var_name_list
        self.out_file = out_file
        self.constraints = constraints
        self.scenario_type = scenario_type

    def export_feasible_design(self):
        """Export feasible designs to file."""
        # Recover database
        database = import_database(self.out_file)

        # Recover design space
        design_space = self.mads_scenario.parameter_space.to_design_space()

        # Save optimization
        self.mads_scenario.scenario.save_optimization_history(
            self.out_file,
            file_format=OptimizationProblem.HistoryFileFormat.HDF5,
        )

        # Define design space to be postprocessed
        to_be_postprocess = OptimizationProblem(design_space)

        # Load optimization problem
        opt_problem = OptimizationProblem.from_hdf(self.out_file)

        # Write design space
        write_design_space(design_space, "design_space.csv")

        # Get history
        history = OptimizationHistory(self.constraints, database, design_space)

        # Get feasible points
        feasible_point = history.feasible_points
        feas_objective = feasible_point[1]
        feasible_var = feasible_point[0]

        # Initialize container
        data_array = np.zeros((int(len(feas_objective)), int(len(self.var_name_list))))

        # Pull feasible variables
        for nn in range(0, len(feas_objective)):
            for v, iv in enumerate(self.var_name_list):
                data_array[nn, v] = feasible_var[nn][iv]

        # Convert to array and save
        with open("feasible_var_and_objective.txt", "a") as txt_file:
            np.savetxt(txt_file, data_array, newline="\n")

        if self.scenario_type == "MDO":
            opt_result = self.mads_scenario.scenario.get_optimum()
            with open("optimum.txt", "a") as myfile:
                myfile.write(str(opt_result.f_opt).replace(".", ",") + ";")
                for i in range(0, len(opt_result.x_opt)):
                    myfile.write(str(opt_result.x_opt[i]).replace(".", ",") + ";")
