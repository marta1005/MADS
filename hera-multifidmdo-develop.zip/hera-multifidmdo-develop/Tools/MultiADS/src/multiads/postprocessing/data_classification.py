"""Data classification utilities for optimization results.

This module provides functions to classify objective values and variables
into categories (invalid, valid, close to optimal, optimal) for visualization.
"""

import numpy as np
from numpy.typing import NDArray
from typing import List, Tuple


def objectiveClassification(
    objective: NDArray, validity: NDArray, maximize: bool = True
) -> Tuple[float, float, float, List[NDArray]]:
    """Classify objective values for visualization.

    Classifies points into four categories:
    - 0: Invalid points (not feasible)
    - 1: Valid points (feasible but not close to optimal)
    - 2: Close to optimal
    - 3: Optimal point(s)

    Args:
        objective: Array of objective values.
        validity: Boolean array indicating feasible points.
        maximize: True if maximizing, False if minimizing.

    Returns:
        tuple: (minVal, maxVal, valueCut, objectiveArray) where objectiveArray
            is a list of 4 arrays containing values in each category.
    """
    objective = np.array(objective)
    validity = np.array(validity, dtype=bool)

    # Calculate min/max only from valid points
    valid_objective = objective[validity]

    if len(valid_objective) == 0:
        min_val = max_val = value_cut = 0.0
        return min_val, max_val, value_cut, [np.array([]) for _ in range(4)]

    min_val = np.min(valid_objective)
    max_val = np.max(valid_objective)

    # Calculate cutoff value
    if maximize:
        value_cut = 0.1 * min_val + 0.9 * max_val
    else:
        value_cut = 0.9 * min_val + 0.1 * max_val

    # Use a small epsilon for floating point comparisons
    eps = 1e-10

    # Initialize objective array (4 categories)
    objective_array = [[] for _ in range(4)]

    for i in range(len(objective)):
        if not validity[i]:
            # Category 0: Invalid
            objective_array[0] = np.append(objective_array[0], objective[i])
        elif maximize:
            if objective[i] < value_cut - eps:
                # Category 1: Valid but not close to optimal
                objective_array[1] = np.append(objective_array[1], objective[i])
            elif objective[i] < max_val + eps:
                # Category 2: Close to optimal
                if abs(objective[i] - max_val) < eps:
                    # This is the optimal point
                    objective_array[3] = np.append(objective_array[3], objective[i])
                else:
                    objective_array[2] = np.append(objective_array[2], objective[i])
            else:
                # Category 3: Optimal (shouldn't reach here with current logic)
                objective_array[3] = np.append(objective_array[3], objective[i])
        else:
            if objective[i] > value_cut + eps:
                # Category 1: Valid but not close to optimal
                objective_array[1] = np.append(objective_array[1], objective[i])
            elif objective[i] > min_val - eps:
                # Category 2: Close to optimal
                if abs(objective[i] - min_val) < eps:
                    # This is the optimal point
                    objective_array[3] = np.append(objective_array[3], objective[i])
                else:
                    objective_array[2] = np.append(objective_array[2], objective[i])
            else:
                # Category 3: Optimal (shouldn't reach here with current logic)
                objective_array[3] = np.append(objective_array[3], objective[i])

    # Convert lists to numpy arrays
    objective_array = [np.array(arr) for arr in objective_array]

    return min_val, max_val, value_cut, objective_array


def valuesClassification(
    data: List[NDArray],
    objective: NDArray,
    minVal: float,
    maxVal: float,
    valueCut: float,
    validity: NDArray,
    maximize: bool = True,
) -> List[List[NDArray]]:
    """Classify variable values based on objective classification.

    Args:
        data: List of variable arrays (each of same length as objective).
        objective: Array of objective values.
        minVal: Minimum objective value.
        maxVal: Maximum objective value.
        valueCut: Cutoff value for "close to optimal".
        validity: Boolean array indicating feasible points.
        maximize: True if maximizing, False if minimizing.

    Returns:
        list: dataArray where dataArray[i][j] contains values of variable i
            in category j (0=invalid, 1=valid, 2=close, 3=optimal).
    """
    objective = np.array(objective)
    validity = np.array(validity, dtype=bool)
    data = [np.array(d) for d in data]

    n_vars = len(data)

    # Initialize result array
    data_array = [[[] for _ in range(4)] for _ in range(n_vars)]

    for i_value in range(len(objective)):
        if not validity[i_value]:
            # Category 0: Invalid
            for i_var in range(n_vars):
                data_array[i_var][0] = np.append(
                    data_array[i_var][0], data[i_var][i_value]
                )
        elif maximize:
            if objective[i_value] < valueCut:
                # Category 1: Valid but not close to optimal
                for i_var in range(n_vars):
                    data_array[i_var][1] = np.append(
                        data_array[i_var][1], data[i_var][i_value]
                    )
            elif objective[i_value] < maxVal:
                # Category 2: Close to optimal
                for i_var in range(n_vars):
                    data_array[i_var][2] = np.append(
                        data_array[i_var][2], data[i_var][i_value]
                    )
            else:
                # Category 3: Optimal
                for i_var in range(n_vars):
                    data_array[i_var][3] = np.append(
                        data_array[i_var][3], data[i_var][i_value]
                    )
        else:
            if objective[i_value] > valueCut:
                # Category 1: Valid but not close to optimal
                for i_var in range(n_vars):
                    data_array[i_var][1] = np.append(
                        data_array[i_var][1], data[i_var][i_value]
                    )
            elif objective[i_value] > minVal:
                # Category 2: Close to optimal
                for i_var in range(n_vars):
                    data_array[i_var][2] = np.append(
                        data_array[i_var][2], data[i_var][i_value]
                    )
            else:
                # Category 3: Optimal
                for i_var in range(n_vars):
                    data_array[i_var][3] = np.append(
                        data_array[i_var][3], data[i_var][i_value]
                    )

    # Convert lists to numpy arrays
    for i_var in range(n_vars):
        for j in range(4):
            data_array[i_var][j] = np.array(data_array[i_var][j])

    return data_array
