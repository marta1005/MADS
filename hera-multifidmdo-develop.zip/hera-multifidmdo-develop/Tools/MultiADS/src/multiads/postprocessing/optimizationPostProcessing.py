"""Postprocessing for GEMSEO optimization results."""

import numpy as np
from numpy.typing import NDArray

from multiads.postprocessing.plotVariables import plotScattersAndHistograms
from multiads.postprocessing.visualization_utils import (
    get_default_markers,
    classify_points,
)


def optimizationResults(
    scenario,
    maximizeObservable=None,
    save=True,
    show=False,
):
    """Generate optimization results plots.

    Args:
        scenario: MADS scenario with formulation.
        maximizeObservable: List of maximize flags for observables.
        save: Whether to save plots.
        show: Whether to display plots.
    """
    # Get problem data
    opt_problem = scenario.formulation.opt_problem
    database = opt_problem.database

    # Get objective
    objectiveVar = str(opt_problem.objective)
    observableVars = opt_problem.observables

    # Get feasible points - GEMSEO 6.3.0: feasible_points is a property
    try:
        x_history, f_history = opt_problem.feasible_points
    except ValueError:
        print("Warning: Database is empty or no feasible points found")
        return None

    # Get all points
    points = np.array(database.get_x_vect_history())
    if len(points) == 0:
        print("Warning: No points in database")
        return None

    # Mark feasible points
    valid = np.array([any(np.array_equal(x, fx) for fx in x_history)
                            for x in points])

    # Get variable names
    pointVars = opt_problem.design_space.variable_names
    pointNames = [str(v) for v in pointVars]
    pointBins = [10] * len(pointVars)

    # Process objective
    maximize, objectiveName, objectiveVar = _parse_objective_name(objectiveVar)
    objectiveValues = _get_objective_values(database, objectiveVar, maximize)

    # Process observables
    observableNames, observableValues, observableBins, observableMax = \
        _process_observables(
            database, observableVars, objectiveValues, valid, maximizeObservable
        )

    # Classify points
    minObj, maxObj, cutObj, objMatrix = classify_points(
        objectiveValues, valid, maximize
    )

    # Create scatter/histogram plots for objective
    pointMatrix = _values_classification(
        points.transpose(), objectiveValues, minObj, maxObj, cutObj, valid
    )

    markers = get_default_markers()

    plotScattersAndHistoriograms(
        pointMatrix, pointNames, markers, pointBins,
        objMatrix, objectiveName, save, show, maximize
    )

    # Create plots for observables
    if len(observableNames) > 1:
        obsMatrix = _values_classification(
            observableValues, objectiveValues, minObj, maxObj, cutObj, valid
        )

        plotScattersAndHistoriograms(
            obsMatrix, observableNames, markers, observableBins,
            objMatrix, objectiveName, save, show, maximize
        )

        for i in range(len(observableNames)):
            minObs, maxObs, cutObs, obsMat = classify_points(
                observableValues[i], valid, observableMax[i]
            )
            pointMat = _values_classification(
                points.transpose(), observableValues[i],
                minObs, maxObs, cutObs, valid, observableMax[i]
            )

            plotScattersAndHistoriograms(
                pointMat, pointNames, markers, pointBins,
                obsMat, observableNames[i], save, show, observableMax[i]
            )


def _parse_objective_name(objectiveVar):
    """Parse objective name and maximize flag."""
    if objectiveVar[0:1] == '-':
        maximize = True
        objectiveName = objectiveVar[1:].split('(')[0]
    else:
        maximize = False
        objectiveName = objectiveVar.split('(')[0]

    objectiveVar = objectiveName  # Remove the "-min" or "max" prefix
    return maximize, objectiveName, objectiveVar


def _get_objective_values(database, objectiveVar, maximize):
    """Get objective values from database."""
    obj_data = database.get_data_by_names(objectiveVar)
    if isinstance(obj_data, dict):
        objectiveValues = np.array(list(obj_data.values())[0])
    else:
        objectiveValues = np.array(obj_data)

    if maximize:
        objectiveValues = -objectiveValues

    return objectiveValues


def _process_observables(
    database, observableVars, objectiveValues, valid, maximizeObservable
):
    """Process observable variables."""
    observableNames = []
    observableValues = []
    observableBins = []
    observableMax = []

    for i, var in enumerate(observableVars):
        name = str(var).split('(')[0]
        observableNames.append(name)

        obs_data = database.get_data_by_names(name)
        if isinstance(obs_data, dict):
            values = np.array(list(obs_data.values())[0])
        else:
            values = np.array(obs_data)
        observableValues.append(values)
        observableBins.append(10)

        if maximizeObservable is not None and i < len(maximizeObservable):
            observableMax.append(maximizeObservable[i])
        else:
            observableMax.append(True)

    return observableNames, observableValues, observableBins, observableMax


def _values_classification(
    values, objectiveValues, minVal, maxVal, cutVal, valid, maximize=True
):
    """Classify values for plotting."""
    from multiads.postprocessing.data_classification import valuesClassification
    return valuesClassification(
        values, objectiveValues, minVal, maxVal, cutVal, valid, maximize
    )
