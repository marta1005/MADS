"""Postprocessing module for MultiADS.

This module provides utilities for visualizing and post-processing
optimization results from GEMSEO.
"""

from multiads.postprocessing.optimizationPostProcessing import optimizationResults
from multiads.postprocessing.mads_post_database import MadsPostProcessor, MadsExportHistory
from multiads.postprocessing.plotVariables import (
    plotScattersAndHistograms,
    triangle,
    CreateTriangleList,
    PlotTriangleList,
)
from multiads.postprocessing.visualization_utils import (
    setup_plot_style,
    get_default_markers,
    save_plot,
    classify_points,
)
from multiads.postprocessing.data_classification import (
    objectiveClassification,
    valuesClassification,
)

__all__ = [
    "optimizationResults",
    "MadsPostProcessor",
    "MadsExportHistory",
    "plotScattersAndHistograms",
    "triangle",
    "CreateTriangleList",
    "PlotTriangleList",
    "setup_plot_style",
    "get_default_markers",
    "save_plot",
    "classify_points",
    "objectiveClassification",
    "valuesClassification",
]
