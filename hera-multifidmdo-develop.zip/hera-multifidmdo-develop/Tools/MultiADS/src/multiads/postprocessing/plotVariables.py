"""Plotting functions for optimization results."""

import matplotlib.pyplot as plt
import numpy as np
from numpy.typing import NDArray
from scipy.spatial import ConvexHull, Delaunay
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.path import Path

from multiads.postprocessing.visualization_utils import (
    get_default_markers,
    classify_points,
)


def plotScattersAndHistograms(
    variablesValues,
    variablesNames,
    dataMarkers,
    variablesBins,
    objectivesValues,
    objectiveName,
    save,
    show,
    maximize=True,
):
    """Create scatter plots and histograms for optimization results.

    Args:
        variablesValues: Array of variable values.
        variablesNames: List of variable names.
        dataMarkers: List of marker styles.
        variablesBins: List of bin counts.
        objectivesValues: Array of objective values.
        objectiveName: Name of the objective.
        save: Whether to save the plot.
        show: Whether to display the plot.
        maximize: True if maximizing, False if minimizing.
    """
    sizes = [len(variablesValues), len(variablesValues[0])]
    fig = plt.figure(figsize=(16, 9), dpi=80)

    title = f"{'max' if maximize else 'min'}[ {objectiveName}({', '.join(variablesNames)}) ]"
    fig.suptitle(title, fontsize=16)

    jointVar = [[] for _ in range(sizes[0])]
    jointVarC = [[] for _ in range(sizes[0])]

    axs = [[None for _ in range(sizes[0])] for _ in range(sizes[0])]

    jointObj = []
    cmap = plt.cm.jet

    # Sort values by objective
    initC = 1
    for i in reversed(range(initC, sizes[1])):
        if len(objectivesValues[i]) > 0:
            sortOrder = np.argsort(objectivesValues[i])
            if not maximize:
                sortOrder = list(reversed(sortOrder))
            jointObj = np.concatenate((jointObj, objectivesValues[i][sortOrder]))

            for j in range(sizes[0]):
                jointVar[j] = np.concatenate(
                    (jointVar[j], variablesValues[j][i][sortOrder])
                )
                if i >= initC:
                    jointVarC[j] = np.concatenate(
                        (jointVarC[j], variablesValues[j][i][sortOrder])
                    )

    # Calculate axis limits
    factorLine = 0.1
    dz = factorLine * (max(jointObj) - min(jointObj))
    z0 = min(jointObj) - dz
    zf = max(jointObj) + dz

    # Create plots
    for i in range(sizes[0]):
        for j in range(sizes[0]):
            iFig = sizes[0] * i + j + 1

            if i == j:
                # Diagonal: histogram
                axs[i][j] = fig.add_subplot(sizes[0], sizes[0], iFig)
                axs[i][j].hist(
                    jointVar[i], bins=variablesBins[i],
                    linewidth=0.5, edgecolor="white", color="lightcoral"
                )
                axs[i][j].set_ylabel("Frequency")

            elif i > j:
                # Lower triangle: 2D scatter
                axs[i][j] = fig.add_subplot(sizes[0], sizes[0], iFig)
                for k in range(sizes[1]):
                    if k == sizes[1] - 1:
                        for xP in variablesValues[j][k]:
                            axs[i][j].axvline(
                                x=xP,
                                color=dataMarkers[k].get('color'),
                                linestyle='--',
                                zorder=-0.5,
                            )
                        for yP in variablesValues[i][k]:
                            axs[i][j].axhline(
                                y=yP,
                                color=dataMarkers[k].get('color'),
                                linestyle='--',
                                zorder=-0.5,
                            )
                    axs[i][j].scatter(
                        variablesValues[j][k],
                        variablesValues[i][k],
                        **dataMarkers[k],
                        zorder=k,
                    )

                axs[i][j].set_ylabel(variablesNames[i])
                axs[i][j].legend(loc='upper right')

            else:
                # Upper triangle: 3D scatter
                axs[i][j] = fig.add_subplot(
                    sizes[0], sizes[0], iFig, projection='3d'
                )
                points = []
                for k in range(len(jointVarC[j])):
                    points.append([jointVarC[j][k], jointVarC[i][k], jointObj[k]])

                points = np.array(points)
                tri = Delaunay(points[:, :2])

                # Create triangle list
                triangleList = CreateTriangleList(points, (zf - z0) / 10.0)
                PlotTriangleList(triangleList, axs[i][j], cmap, z0, zf, maximize)

                # Add reference lines
                dx = factorLine * (max(jointVar[j]) - min(jointVar[j]))
                x0 = min(jointVar[j]) - dx
                xf = max(jointVar[j]) + dx

                dy = factorLine * (max(jointVar[i]) - min(jointVar[i]))
                y0 = min(jointVar[i]) - dy
                yf = max(jointVar[i]) + dy

                for k in range(2, sizes[1]):
                    if k == sizes[1] - 1:
                        for l in range(len(variablesValues[i][k])):
                            axs[i][j].plot(
                                [x0, xf],
                                [variablesValues[i][k][l], variablesValues[i][k][l]],
                                [z0, z0],
                                color=dataMarkers[k].get('color'),
                                linestyle='--',
                                zorder=-1.0,
                            )
                            axs[i][j].plot(
                                [variablesValues[j][k][l], variablesValues[j][k][l]],
                                [y0, yf],
                                [z0, z0],
                                color=dataMarkers[k].get('color'),
                                linestyle='--',
                                zorder=-1.0,
                            )
                            axs[i][j].plot(
                                [variablesValues[j][k][l], variablesValues[j][k][l]],
                                [variablesValues[i][k][l], variablesValues[i][k][l]],
                                [z0, objectivesValues[k][l]],
                                color=dataMarkers[k].get('color'),
                                linestyle='--',
                                zorder=-1.0,
                            )
                        axs[i][j].scatter(
                    variablesValues[j][k],
                    variablesValues[i][k],
                    objectivesValues[k],
                    **dataMarkers[k],
                    zorder=k,
                )

                axs[i][j].set_xlabel(variablesNames[j])
                axs[i][j].set_ylabel(variablesNames[i])
                axs[i][j].set_zlabel(objectiveName)
                axs[i][j].set_xlim([x0, xf])
                axs[i][j].set_ylim([y0, yf])
                axs[i][j].set_zlim([z0, zf])

            axs[i][j].grid(True)

    # Adjust layout
    box = axs[0][0].get_position()
    width = box.x1 - box.x0
    height = box.y1 - box.y0
    factor = 16.0 / 9.0

    for i in range(sizes[0]):
        for j in range(sizes[0]):
            if j > i:
                boxT = axs[i][j].get_position()
                xT = (boxT.x0 + boxT.x1) / 2.0
                yT = (boxT.y0 + boxT.y1) / 2.0
                axs[i][j].set_position([
                    xT - width * factor / 2.0,
                    yT - height * factor / 2.0,
                    factor * width,
                    factor * height,
                ])
                axs[i][j].set_facecolor((0.0, 0.0, 0.0, 0.0))

    if save:
        figH = 4.5 * sizes[0]
        figW = 8.0 * sizes[0]
        fig.suptitle(fig.suptitle.get_text(), fontsize=max(5 * sizes[0], 20))
        fig.set_size_inches(figW, figH)
        plt.savefig(f"{'max_' if maximize else 'min_'}{objectiveName}.png", dpi=80)

    if show:
        fig.suptitle(fig.suptitle.get_text(), fontsize=15)
        fig.set_size_inches(24, 13.5)
        plt.show()


# ---- Triangle utilities ----

class triangle:
    """Represents a triangle in 3D space."""

    def __init__(self, p1, p2, p3):
        """Initialize triangle with 3 points."""
        self.p1 = np.array(p1)
        self.p2 = np.array(p2)
        self.p3 = np.array(p3)

        p12 = np.subtract(self.p2, self.p1)
        self.u = p12 / np.linalg.norm(p12)
        p13 = np.subtract(self.p3, self.p1)
        self.d = np.dot(p13, self.u)
        v = p13 - self.d * self.u
        self.h = np.linalg.norm(v)
        self.v = v / self.h
        self.w = np.cross(self.u, self.v)

        self.l = np.array([
            np.linalg.norm(np.subtract(self.p1, self.p2)),
            np.linalg.norm(np.subtract(self.p2, self.p3)),
            np.linalg.norm(np.subtract(self.p3, self.p1)),
        ])

        self.z = np.array([
            abs(np.dot(np.subtract(self.p1, self.p2), np.array([0.0, 0.0, 1.0]))),
            abs(np.dot(np.subtract(self.p2, self.p3), np.array([0.0, 0.0, 1.0]))),
            abs(np.dot(np.subtract(self.p3, self.p1), np.array([0.0, 0.0, 1.0]))),
        ])

        self.area = self.h * self.l[0] / 2.0

    @property
    def maxLenght(self):
        """Get maximum edge length."""
        return max(self.l)

    @property
    def maxHeight(self):
        """Get maximum z-height."""
        return max(self.z)

    @property
    def exploitTriangle(self):
        """Get 4 sub-triangles from this triangle."""
        p4 = (self.p1 + self.p2) / 2.0
        p5 = (self.p2 + self.p3) / 2.0
        p6 = (self.p3 + self.p1) / 2.0

        return [
            triangle(p6, self.p1, p4),
            triangle(p4, self.p2, p5),
            triangle(p5, self.p3, p6),
            triangle(p4, p5, p6),
        ]

    @classmethod
    def interpol(cls, f1, f2, f3, u, v):
        """Interpolate value at (u, v) using barycentric coordinates."""
        return f1 * (1.0 - u) * (1 - v) + f2 * u + f3 * v

    def getPoint(self, u, v):
        """Get point at barycentric coordinates (u, v)."""
        return self.p1 * (1.0 - u) * (1 - v) + self.p2 * u + self.p3 * v

    def plot(self, axle, color):
        """Plot triangle on given axes."""
        triangles = [
            (self.p1[0], self.p1[1], self.p1[2]),
            (self.p2[0], self.p2[1], self.p2[2]),
            (self.p3[0], self.p3[1], self.p3[2]),
        ]
        axle.add_collection3d(
            Poly3DCollection([triangles], edgecolor='k', facecolor=color, linewidth=1.0)
        )


def CreateTriangleList(points, hCut):
    """Create a list of triangles with adaptive refinement.

    Args:
        points: Array of points (N x 3).
        hCut: Height threshold for refinement.

    Returns:
        list[triangle]: List of triangles.
    """
    hull = ConvexHull(points, qhull_options="Qs")
    triangleList = []

    new = True
    for simplex in hull.simplices:
        tTemp = triangle(points[simplex[0]], points[simplex[1]], points[simplex[2]])
        if tTemp.area > 0.0:
            if new:
                hMax = tTemp.maxHeight
                new = False
            else:
                hMax = max(hMax, tTemp.maxHeight)
            triangleList.append(tTemp)

    while hMax > hCut:
        new = True
        triangleList2 = []
        for t in triangleList:
            if t.maxHeight < hCut:
                triangleList2.append(t)
                if new:
                    hMax = t.maxHeight
                    new = False
                else:
                    hMax = max(hMax, t.maxHeight)
            else:
                tList = t.exploitTriangle
                for tTemp in tList:
                    triangleList2.append(tTemp)
                    if new:
                        hMax = tTemp.maxHeight
                        new = False
                    else:
                        hMax = max(hMax, tTemp.maxHeight)
        triangleList = triangleList2

    return triangleList


def PlotTriangleList(triangleList, axle, cmap, z0, zf, maximize):
    """Plot a list of triangles.

    Args:
        triangleList: List of triangle objects.
        axle: Matplotlib 3D axes.
        cmap: Colormap.
        z0, zf: Z-axis limits.
        maximize: True if maximizing.
    """
    for t in triangleList:
        z = t.getPoint(1.0 / 3.0, 1.0 / 3.0)
        zc = (z[2] - z0) / (zf - z0)
        if not maximize:
            zc = 1.0 - zc
        c = cmap(zc)
        t.plot(axle, [c[0], c[1], c[2], 0.9])
