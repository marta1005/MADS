from __future__ import annotations

from typing import TYPE_CHECKING, Any

from gemseo import (
    create_design_space,
    create_parameter_space,
    create_scenario,
    generate_n2_plot,
)
from gemseo.scenarios.base_scenario import BaseScenario
from gemseo_umdo.scenarios.udoe_scenario import UDOEScenario
from gemseo_umdo.scenarios.umdo_scenario import UMDOScenario
from gemseo.scenarios.mdo_scenario import MDOScenario
from gemseo_multi_fidelity.core.mf_scenario import MFMDOScenario

from multiads.design_space.cpacs_structure_data import CPACSStructureData
from multiads.scenario.variables import BaseVariable, RandomVariable, Variable

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from gemseo.algos.optimization_result import OptimizationResult
    from gemseo.core.discipline.discipline import Discipline
    from gemseo.datasets.dataset import Dataset
    from gemseo.formulations.base_formulation import BaseFormulation
    from gemseo.formulations.base_formulation_settings import BaseFormulationSettings
    from gemseo.post.base_post import BasePost
    from gemseo.scenarios.scenario_results.scenario_result import ScenarioResult
    from gemseo_umdo.formulations.base_umdo_formulation_settings import (
        BaseUMDOFormulationSettings,
    )


ConstraintType = BaseScenario.ConstraintType


class Constraint:
    def __init__(
        self,
        output_name: str,
        constraint_type: ConstraintType,
        value: float = 0.0,
        positive: bool = False,
    ) -> None:
        self.output_name = output_name
        self.constraint_type = constraint_type
        self.value = value
        self.positive = positive


class RandomConstraint(Constraint):
    def __init__(
        self,
        output_name: str,
        constraint_type: ConstraintType,
        value: float = 0.0,
        positive: bool = False,
        statistic_name: str | None = None,
        **statistic_parameters: Any,  # noqa: ANN401
    ) -> None:
        super().__init__(output_name, constraint_type, value, positive)
        self.statistic_name = statistic_name
        self.statistic_parameters = statistic_parameters


class MADSScenario():
    def __init__(self) -> None:
        self.design_space = create_design_space()
        self.parameter_space = create_parameter_space()
        self.scenario: BaseScenario | None = None
        self._disciplines: Sequence[Discipline] | None = None

    def fill_parameter_space(self, variables: Sequence[BaseVariable]) -> None:
        """Fill the design space with `variables`.

        Deterministic variables are stored in a `DesignSpace`, whereas random
        variables are stored in a `ParameterSpace`.

        Args:
            variables: the variables defined according the dictionary structure
                       compatible with the assembly

        """
        for ov in variables:
            # Variables to be created from CPACS files
            if cpacs := ov.cpacs:
                try:
                    input_file = cpacs["input_file"]
                    xpath = cpacs["xpath"]
                    marker = cpacs["cpacs_marker"]
                except KeyError:
                    msg = f"Incomplete CPACS options for variable '{ov.name}'"
                    raise ValueError(msg) from None

                cpacs_var = CPACSStructureData(input_file)
                cpacs_var.select_variable_from_xpath(xpath, marker)
                ov.value = cpacs_var.get_value(marker)

            if isinstance(ov, Variable):
                self.design_space.add_variable(
                    ov.name,
                    ov.value.size,
                    lower_bound=ov.lb,  # type: ignore[invalid-argument-type, ty:invalid-argument-type]
                    upper_bound=ov.ub,  # type: ignore[invalid-argument-type, ty:invalid-argument-type]
                    value=ov.value,
                )
            elif isinstance(ov, RandomVariable):
                self.parameter_space.add_random_variable(
                    ov.name,
                    ov.distribution,  # type: ignore[invalid-argument-type]
                    ov.value.size,
                )
            else:
                msg = (
                    f"Variable '{ov.name}' must be either a "
                    "'Variable' or a 'RandomVariable'"
                )
                raise TypeError(msg)

    def create_scenario(
        self,
        disciplines: Sequence[Discipline],
        objective_name: str,
        name: str = "",
        maximize_objective: bool = False,
        scenario_type: str = "MDO",
        formulation_name: str = "DisciplinaryOpt",
        formulation_options_model: BaseFormulationSettings | None = None,
        **formulation_options_dict: Any,  # noqa: ANN401
    ) -> None:
        # TODO @All: Check inputs/outputs
        self._disciplines = disciplines
        self.scenario = create_scenario(
            disciplines=disciplines,
            objective_name=objective_name,
            design_space=self.design_space,
            name=name,
            scenario_type=scenario_type,
            maximize_objective=maximize_objective,
            formulation_settings_model=formulation_options_model,
            formulation_name=formulation_name,
            **formulation_options_dict,
        )

    def create_random_scenario(
        self,
        disciplines: Sequence[Discipline],
        objective_name: str,
        objective_statistic_name: str,
        statistic_estimation_settings: BaseUMDOFormulationSettings,
        objective_statistic_parameters: Mapping[str, Any] | None = None,
        name: str = "",
        maximize_objective: bool = False,
        scenario_type: str = "MDO",
        formulation_name: str = "DisciplinaryOpt",
        formulation_options_model: BaseFormulationSettings | None = None,
        **formulation_options_dict: Any,  # noqa: ANN401
    ) -> None:
        """Create an uncertain scenario.

        Args:
            disciplines: List of disciplines.
            objective_name: Variable to be optimized
            objective_statistic_name: Name of the statistic applied to the objective.
            statistic_estimation_settings: Settings of the statistics estimation.
            objective_statistic_parameters: Settings of the objective statistics.
            name: Name of the scenario.
            maximize_objective: Whether this is a minimiaztion or maximization scenario.
            scenario_type: Whether this is a DOE or an MDO scenario.
            formulation_name: Name of the underlying formulation.
            formulation_options_model: Formulation settings as a pydantic model.
            **formulation_options_dict: Formulation settings, these arguments are
                ignored when ``settings_model`` is not ``None``.

        """
        # TODO @All: Check inputs/outputs
        self._disciplines = disciplines
        if scenario_type.upper() == "DOE":
            self.scenario = UDOEScenario(
                disciplines=disciplines,
                objective_name=objective_name,
                design_space=self.design_space,
                uncertain_space=self.parameter_space,
                objective_statistic_name=objective_statistic_name,
                statistic_estimation_settings=statistic_estimation_settings,
                objective_statistic_parameters=objective_statistic_parameters or {},
                formulation_name=formulation_name,
                name=name,
                formulation_settings_model=formulation_options_model,
                maximize_objective=maximize_objective,
                **formulation_options_dict,
            )

        elif scenario_type.upper() == "MDO":
            self.scenario = UMDOScenario(
                disciplines=disciplines,
                objective_name=objective_name,
                design_space=self.design_space,
                uncertain_space=self.parameter_space,
                objective_statistic_name=objective_statistic_name,
                statistic_estimation_settings=statistic_estimation_settings,
                objective_statistic_parameters=objective_statistic_parameters or {},
                formulation_name=formulation_name,
                name=name,
                formulation_settings_model=formulation_options_model,
                maximize_objective=maximize_objective,
                **formulation_options_dict,
            )

        else:
            msg = f"Unkown scenario type '{scenario_type}'. Options are: 'DOE', 'MDO'."
            raise ValueError(msg)

    def add_constraints(
        self,
        constraints: Sequence[Constraint | RandomConstraint],
    ) -> None:
        if self.scenario is not None:
            for constraint in constraints:
                if type(constraint) is Constraint:
                    self.scenario.add_constraint(
                        output_name=constraint.output_name,
                        constraint_type=constraint.constraint_type,
                        value=constraint.value,
                        positive=constraint.positive,
                    )
                elif type(constraint) is RandomConstraint:
                    self.scenario.add_constraint(
                        output_name=constraint.output_name,
                        statistic_name=constraint.statistic_name,
                        constraint_type=constraint.constraint_type,
                        value=constraint.value,
                        positive=constraint.positive,
                        **constraint.statistic_parameters,
                    )
                else:
                    msg = f"Unknown constraint type: {type(constraint)}."
                    raise TypeError(msg)

    def add_observables(self, observables: Sequence[str]) -> None:
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        for o in observables:
            self.scenario.add_observable(o)

    def execute(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.execute(*args, **kwargs)

    def get_optim_variable_names(self) -> Sequence[str]:
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.get_optim_variable_names()

    def get_result(self, *args, **kwargs) -> ScenarioResult | None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.get_result(*args, **kwargs)

    def post_process(self, *args, **kwargs) -> BasePost:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.post_process(*args, **kwargs)

    def print_execution_metrics(self) -> None:
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.print_execution_metrics()

    def save_optimization_history(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.save_optimization_history(*args, **kwargs)

    def set_algorithm(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.set_algorithm(*args, **kwargs)

    def set_differentiation_method(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.set_differentiation_method(*args, **kwargs)

    def set_optimization_history_backup(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.set_optimization_history_backup(*args, **kwargs)

    def to_dataset(self, *args, **kwargs) -> Dataset:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.to_dataset(*args, **kwargs)

    def xdsmize(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        self.scenario.xdsmize(*args, **kwargs)

    def n2_plot(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None or self._disciplines is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        generate_n2_plot(self._disciplines, *args, **kwargs)

    @property
    def optimization_result(self) -> OptimizationResult | None:
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.optimization_result

    @property
    def formulation(self) -> BaseFormulation | None:
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.formulation
       
    @property
    def formulation(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.formulation
    
    @property
    def execution_statistics(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        if self.scenario is None:
            msg = f"'{type(self).__name__}' not initialized."
            raise RuntimeError(msg)
        return self.scenario.execution_statistics

class MFMADSScenario(MADSScenario):
    def __init__(
            self,
            scenario:list[MADSScenario],
            formulation_name:None,
            name:None,
            **kwargs
    )-> None:
        self.formulation_name = formulation_name
        self.name = name
        self.scenario_MDO = []
        
        
        # check that scenario is ot TYPE{MDOScenario}
        for item in scenario:
            if isinstance(item.scenario,MDOScenario):
                self.scenario_MDO.append(item.scenario)
            else:
                print("MADSScenario should be an instance of MDOScenario")
        
        # set mulit-fidelity scenario
        self.scenario = MFMDOScenario(self.scenario_MDO, formulation_name = formulation_name, name=name, **kwargs)