from collections.abc import Mapping
from typing import Generic, TypeVar

import numpy as np
from gemseo.uncertainty.distributions.base_distribution_settings import (
    BaseDistribution_Settings,
)
from gemseo.uncertainty.distributions.openturns.normal_settings import (
    OTNormalDistribution_Settings,
)
from gemseo.uncertainty.distributions.openturns.triangular_settings import (
    OTTriangularDistribution_Settings,
)
from numpy.typing import NDArray

N = TypeVar("N", NDArray[np.int32], NDArray[np.float64])
V = TypeVar("V", np.float64, np.int32, NDArray[np.int32], NDArray[np.float64])
ValueType = np.int32 | NDArray[np.int32] | float | np.float64 | NDArray[np.float64]


class BaseVariable(Generic[V, N]):
    def __init__(
        self,
        name: str,
        value: V,
        value_np: N,
        is_array: bool,
        cpacs: Mapping[str, str],
    ) -> None:
        self.name = name
        self.value_np: N = value_np
        self.is_array = is_array
        self.cpacs = cpacs

        # 'Ghost' attribute, needed to parametrize an instance -> V
        self._value_type: V = value

    @property
    def value(self) -> V:
        return self.cast_value(self.value_np)

    @value.setter
    def value(self, val: ValueType) -> None:
        self.value_np[:] = np.ravel(val)

    def cast_value(self, val: N) -> V:
        if self.is_array:
            return np.asarray(val)  # type: ignore[return-value, ty:invalid-return-type]
        return val[0]


class Variable(BaseVariable[V, N]):
    def __init__(
        self,
        name: str,
        value: ValueType,
        lb: ValueType | None = None,
        ub: ValueType | None = None,
        cpacs: Mapping[str, str] | None = None,
    ) -> None:
        # Cast value to numpy type
        _value: V
        if is_array := isinstance(value, np.ndarray):
            _value = np.ravel(value)  # type: ignore[assignment, ty:invalid-assignment]
        elif type(value) is float:
            _value = np.float64(value)  # type: ignore[assignment, ty:invalid-assignment]
        elif type(value) is int:
            _value = np.int32(value)  # type: ignore[assignment, ty:invalid-assignment]
        else:
            _value = value  # type: ignore[assignment, ty:invalid-assignment]

        value_np: N = np.ravel(_value)

        super().__init__(
            name=name,
            value=_value,
            value_np=value_np,
            is_array=is_array,
            cpacs=cpacs or {},
        )

        self.lb_np: N = -np.inf * np.ones_like(value_np) if lb is None else np.ravel(lb)
        self.ub_np: N = np.inf * np.ones_like(value_np) if ub is None else np.ravel(ub)

    @property
    def lb(self) -> V:
        return self.cast_value(self.lb_np)

    @lb.setter
    def lb(self, val: ValueType) -> None:
        self.lb_np = np.ravel(val)

    @property
    def ub(self) -> V:
        return self.cast_value(self.ub_np)

    @ub.setter
    def ub(self, val: ValueType) -> None:
        self.ub_np = np.ravel(val)


VariableInt = Variable[np.int32, NDArray[np.int32]]
VariableFloat = Variable[np.float64, NDArray[np.float64]]
VariableIntNP = Variable[NDArray[np.int32], NDArray[np.int32]]
VariableFloatNP = Variable[NDArray[np.float64], NDArray[np.float64]]


MADSNormalDistribution = OTNormalDistribution_Settings
MADSTriangularDistribution = OTTriangularDistribution_Settings

S = TypeVar("S", bound=BaseDistribution_Settings)


class RandomVariable(BaseVariable[V, N]):
    def __init__(
        self,
        name: str,
        distribution: S,
        cpacs: Mapping[str, str] | None = None,
    ) -> None:
        if type(distribution) is MADSNormalDistribution:
            value = distribution.mu
        elif type(distribution) is MADSTriangularDistribution:
            value = distribution.mode
        else:
            msg = f"Unknown statistical distribution '{type(distribution)}'"
            raise TypeError(msg)

        self.distribution = distribution

        _value: V
        if is_array := isinstance(value, np.ndarray):
            _value = np.ravel(value)  # type: ignore[assignment, ty:invalid-assignment]
        elif type(value) is float:
            _value = np.float64(value)  # type: ignore[assignment, ty:invalid-assignment]
        elif type(value) is int:
            _value = np.int32(value)  # type: ignore[assignment, ty:invalid-assignment]
        else:
            _value = value  # type: ignore[assignment, ty:invalid-assignment]

        value_np = np.ravel(value)

        super().__init__(
            name=name,
            value=_value,
            value_np=value_np,
            is_array=is_array,
            cpacs=cpacs or {},
        )


RandomVariableInt = RandomVariable[np.int32, NDArray[np.int32]]
RandomVariableFloat = RandomVariable[np.float64, NDArray[np.float64]]
RandomVariableIntNP = RandomVariable[NDArray[np.int32], NDArray[np.int32]]
RandomVariableFloatNP = RandomVariable[NDArray[np.float64], NDArray[np.float64]]


class InnerVariable(BaseVariable[V, N]):
    def __init__(
        self,
        name: str,
        value: ValueType,
    ) -> None:
        _value: V
        if is_array := isinstance(value, np.ndarray):
            _value = np.ravel(value)  # type: ignore[assignment, ty:invalid-assignment]
        elif type(value) is float:
            _value = np.float64(value)  # type: ignore[assignment, ty:invalid-assignment]
        elif type(value) is int:
            _value = np.int32(value)  # type: ignore[assignment, ty:invalid-assignment]
        else:
            _value = value  # type: ignore[assignment, ty:invalid-assignment]

        value_np: N = np.ravel(_value)

        super().__init__(
            name=name,
            value=_value,
            value_np=value_np,
            is_array=is_array,
            cpacs={},
        )


InnerVariableInt = InnerVariable[np.int32, NDArray[np.int32]]
InnerVariableFloat = InnerVariable[np.float64, NDArray[np.float64]]
InnerVariableIntNP = InnerVariable[NDArray[np.int32], NDArray[np.int32]]
InnerVariableFloatNP = InnerVariable[NDArray[np.float64], NDArray[np.float64]]
