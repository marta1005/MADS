"""Design space utilities for MultiADS.

This module provides CPACS integration for importing aircraft configurations
and creating design spaces for optimization.
"""

from multiads.design_space.cpacs_design_space import CPACSDesignSpace
from multiads.design_space.cpacs_importer import CPACSImporter
from multiads.design_space.cpacs_mapping import CPACSMapping
from multiads.design_space.cpacs_path_template import CPACSPathTemplate
from multiads.design_space.cpacs_structure_data import CPACSStructureData
from multiads.design_space.cpacs_variable_set import CPACSVariableSet
from multiads.design_space.path_templates_cpacs35 import CPACS_TEMPLATES
from multiads.design_space.schema_validator import SchemaValidator
from multiads.design_space.tigl_bridge import TiGLBridge

__all__ = [
    "CPACS_TEMPLATES",
    "CPACSDesignSpace",
    "CPACSImporter",
    "CPACSMapping",
    "CPACSPathTemplate",
    "CPACSStructureData",
    "CPACSVariableSet",
    "SchemaValidator",
    "TiGLBridge",
]
